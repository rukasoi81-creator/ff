/* BASE : Skyzopwdia 
Script Create By : Zlynzee

Tq To
//- ChatGpt
//- Dan Gelap Nya Malam
*/