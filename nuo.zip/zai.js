const util = require("util");
const chalk = require("chalk");
const fs = require("fs");
const path = require("path")
const FormData = require("form-data")
const axios = require("axios");
const fetch = require("node-fetch");
const ssh2 = require("ssh2");
const { exec, spawn, execSync } = require('child_process');
const {
    default: makeWASocket,
    makeCacheableSignalKeyStore,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeInMemoryStore,
    getContentType,
    jidDecode,
    MessageRetryMap,
    proto,
    delay, 
    Browsers
} = require("@whiskeysockets/baileys");
const LoadDataBase = require("./source/LoadDatabase.js");

//###############################//

module.exports = async (m, sock) => {
try {
await LoadDataBase(sock, m)
const isCmd = m?.body?.startsWith(m.prefix)
const prefix = '.';
const quoted = m.quoted ? m.quoted : m
const mime = quoted?.msg?.mimetype || quoted?.mimetype || null
const args = m.body.trim().split(/ +/).slice(1)
const qmsg = (m.quoted || m)
const text = q = args.join(" ")
const command = isCmd ? m.body.slice(m.prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = m.prefix + command
const groupMetadata = m?.isGroup ? await sock.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = m?.isGroup ? groupMetadata.participants?.map(p => {
    let admin = null;
    if (p.admin === 'superadmin') admin = 'superadmin';
    if (p.admin === 'admin') admin = 'admin';
    return {
        jid: p.jid || null,
        admin
    };
}) || [] : [];
const botNumber = await sock.user.id.split(":")[0]+"@s.whatsapp.net"
const groupAdmins = participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .map(p => p.jid);
const isOwner = global.owner+"@s.whatsapp.net" == m.sender || m.sender == botNumber || db.settings.developer.includes(m.sender)
const isAdmin = m?.isGroup ? groupAdmins.includes(m.sender) : false;
const isBotAdmin = m?.isGroup ? groupAdmins.includes(`${Nezubot}@s.whatsapp.net`) : false;
const isReseller = db.settings.reseller.includes(m.sender)
  m.isGroup = m.chat.endsWith('g.us');
  m.metadata = {};
  m.isAdmin = false;
  m.isBotAdmin = false;
  if (m.isGroup) {
    let meta = await global.groupMetadataCache.get(m.chat)
    if (!meta) meta = await sock.groupMetadata(m.chat).catch(_ => {})
    m.metadata = meta;
    const p = meta?.participants || [];
    m.isAdmin = p?.some(i => (i.id === m.sender || i.jid === m.sender) && i.admin !== null);
    m.isBotAdmin = p?.some(i => (i.id === botNumber || i.jid == botNumber) && i.admin !== null);
  } 
 
let premium = JSON.parse(fs.readFileSync('./Database/PremiumUser.json'));
let energy = JSON.parse(fs.readFileSync('./Database/Energy.json'));
let uang = JSON.parse(fs.readFileSync('./Database/Uang.json'));
let games = JSON.parse(fs.readFileSync('./Database/Games.json', 'utf-8') || '{}');
let groupSettings = {};
try {
    groupSettings = JSON.parse(fs.readFileSync('./Database/GroupSettings.json', 'utf-8'));
} catch {
    groupSettings = {};
}   
const primbon = require('primbon-scraper')  
const uguu = require("./lib/uggu")
const remini = require("./lib/remini")
const bannedGroups = JSON.parse(fs.readFileSync('./Database/BannedGroups.json', 'utf-8') || '[]');   
const isPremium = premium.includes(m.sender);
const userEnergy = energy[m.sender] || 0;
const userMoney = uang[m.sender] || 0;
const pakasir = require("./lib/pakasir")

global.pakasirPending = {} // cache memory biar cepat

function loadPakasirOrders() {
  try {
    const raw = JSON.parse(fs.readFileSync("./Database/pakasir-orders.json"))
    global.pakasirPending = raw?.pending || {}
  } catch {
    global.pakasirPending = {}
  }
}

function savePakasirOrders() {
  fs.writeFileSync(
    "./Database/pakasir-orders.json",
    JSON.stringify({ pending: global.pakasirPending }, null, 2)
  )
}

loadPakasirOrders()

setInterval(async () => {
  const pendingIds = Object.keys(global.pakasirPending || {})
  if (!pendingIds.length) return

  for (const order_id of pendingIds) {
    const ord = global.pakasirPending[order_id]
    if (!ord) continue

    try {
      const detail = await pakasir.transactionDetail({
        project: global.pakasir_slug,
        api_key: global.pakasir_apikey,
        order_id,
        amount: ord.amount
      })

      const status = detail?.transaction?.status
      if (status !== "completed") continue

      const jid = ord.user
      if (!global.db.users[jid]) global.db.users[jid] = {}

      // ✅ SUKSES: LIMIT
      if (ord.type === "limit") {
        if (!global.db.users[jid].limit) global.db.users[jid].limit = 0
        global.db.users[jid].limit += ord.limit

        await sock.sendMessage(jid, {
          text:
            `✅ PEMBAYARAN BERHASIL!\n\n` +
            `• Produk: LIMIT\n` +
            `• Order ID: ${order_id}\n` +
            `• Limit +${ord.limit}\n` +
            `• Total Limit: ${global.db.users[jid].limit}\n` +
            `• Amount: Rp${ord.amount}\n\n` +
            `Terima kasih!`
        })
      }

      // ✅ SUKSES: PREMIUM
      if (ord.type === "premium") {
        global.db.users[jid].premium = true

        await sock.sendMessage(jid, {
          text:
            `✅ PEMBAYARAN BERHASIL!\n\n` +
            `• Produk: PREMIUM\n` +
            `• Order ID: ${order_id}\n` +
            `• Status: Premium Aktif ✅\n` +
            `• Amount: Rp${ord.amount}\n\n` +
            `Sekarang kamu punya akses premium!`
        })
      }

      // hapus pending
      delete global.pakasirPending[order_id]
      fs.writeFileSync(
        "./Database/pakasir-orders.json",
        JSON.stringify({ pending: global.pakasirPending }, null, 2)
      )
    } catch (e) {
      // kalau error, skip (biar cek lagi nanti)
      console.error("[AUTO CHECK PAKASIR ERROR]", e?.message || e)
    }
  }
}, 5000)
//###############################//

if (isCmd) {
console.log(chalk.cyan('╭───────────────────────────────────╮'));
console.log(chalk.cyan('│') + chalk.white(' 📩 Message Info                   ') + chalk.cyan('│'));
console.log(chalk.cyan('├───────────────────────────────────┤'));
console.log(chalk.cyan('│') + chalk.white(' Sender  : ') + chalk.green(m.chat.split('@')[0]) + chalk.cyan('         │'));
console.log(chalk.cyan('│') + chalk.white(' Command : ') + chalk.magenta(cmd) + chalk.cyan('                │'));
console.log(chalk.cyan('│') + chalk.white(' Time    : ') + chalk.yellow(new Date().toLocaleTimeString('id-ID')) + chalk.cyan('     │'));
console.log(chalk.cyan('╰───────────────────────────────────╯\n'));
}

//###############################//

if (!isCmd && m.body) {
const responder = db.settings.respon.find(v => v.id.toLowerCase() == m.body.toLowerCase())
if (responder && responder.response) {
console.log(chalk.green('✓ ') + chalk.white('Auto Response triggered: ') + chalk.cyan(m.body));
await m.reply(responder.response)
}}

//###############################//

const FakeChannel = {
  key: {
    remoteJid: 'status@broadcast',
    fromMe: false,
    participant: '0@s.whatsapp.net'
  },
  message: {
    newsletterAdminInviteMessage: {
      newsletterJid: '123@newsletter',
      caption: `Powered By ${global.namaOwner}.`,
      inviteExpiration: 0
    }
  }
}

//###############################//

const FakeSticker = {
        key: {
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
        },
        message: {
            stickerPackMessage: {
                stickerPackId: "\000",
                name: `Powered By ${global.namaOwner}.`,
                publisher: "kkkk"
            }
        }
    }


//###############################//

const RPG_DB = path.join("./Database", "RPGRoleplay.json")
if (!fs.existsSync("./Database")) fs.mkdirSync("./Database")
if (!fs.existsSync(RPG_DB)) fs.writeFileSync(RPG_DB, JSON.stringify({ users: {}, guilds: {} }, null, 2))

let RPG = JSON.parse(fs.readFileSync(RPG_DB))

function saveRPG() {
  fs.writeFileSync(RPG_DB, JSON.stringify(RPG, null, 2))
}

function rupiah(n) {
  n = Number(n) || 0
  return "Rp" + n.toLocaleString("id-ID")
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n))
}

function msToTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const ss = s % 60
  if (h) return `${h}j ${m}m ${ss}d`
  if (m) return `${m}m ${ss}d`
  return `${ss}d`
}

function ensureUser(jid, name) {
  if (!RPG.users[jid]) {
    RPG.users[jid] = {
      name: name || "User",
      level: 1,
      exp: 0,
      need: 120,

      money: 10000,
      bank: 0,

      energy: 100,
      maxEnergy: 100,

      hp: 100,
      maxHp: 100,

      job: null,
      jobLevel: 1,

      house: null,
      houseLevel: 0,

      vehicle: null,
      vehicleLevel: 0,
      fuel: 0,
      maxFuel: 0,

      stats: { atk: 5, def: 5, luck: 1, cha: 1 },

      inventory: {
        food: 0,
        medkit: 0,
        material: 0,
        ticket: 0
      },

      reputation: 0,
      marriedTo: null,

      jailUntil: 0,
      debt: 0,

      last: {
        daily: 0,
        work: 0,
        rest: 0,
        training: 0,
        hunt: 0,
        dungeon: 0,
        crime: 0,
        interest: 0,
        event: 0,
        travel: 0
      }
    }
    saveRPG()
  }
  return RPG.users[jid]
}

function isJailed(u) {
  return Date.now() < (u.jailUntil || 0)
}

function rankName(level) {
  if (level >= 40) return "Legend"
  if (level >= 25) return "Master"
  if (level >= 15) return "Elite"
  if (level >= 7) return "Warrior"
  return "Beginner"
}

function addExp(u, amount) {
  u.exp += amount
  let leveled = 0
  while (u.exp >= u.need) {
    u.exp -= u.need
    u.level += 1
    u.need = Math.floor(u.need * 1.15) + 30
    u.maxHp += 10
    u.hp = u.maxHp
    u.maxEnergy += 2
    u.energy = clamp(u.energy + 5, 0, u.maxEnergy)
    u.stats.atk += 1
    u.stats.def += 1
    if (u.level % 5 === 0) u.stats.luck += 1
    leveled++
  }
  return leveled
}

const JOBS = [
  { name: "Driver Ojek", min: 1500, max: 3200, energy: 10, cd: 10 * 60 * 1000 },
  { name: "Kurir Paket", min: 2000, max: 3800, energy: 11, cd: 10 * 60 * 1000 },
  { name: "Penjual Gorengan", min: 1800, max: 4200, energy: 9, cd: 9 * 60 * 1000 },
  { name: "Montir", min: 2800, max: 5200, energy: 12, cd: 12 * 60 * 1000 },
  { name: "Petani", min: 1600, max: 4800, energy: 10, cd: 11 * 60 * 1000 },
  { name: "Polisi", min: 3200, max: 6000, energy: 13, cd: 12 * 60 * 1000 },
  { name: "Developer", min: 4200, max: 9000, energy: 14, cd: 13 * 60 * 1000 }
]

const HOUSES = [
  { id: "Kontrakan", price: 25000, bonusEnergy: 5, maxStorage: 10 },
  { id: "Rumah Kayu", price: 60000, bonusEnergy: 8, maxStorage: 15 },
  { id: "Rumah Bata", price: 150000, bonusEnergy: 12, maxStorage: 25 },
  { id: "Ruko", price: 350000, bonusEnergy: 15, maxStorage: 40 },
  { id: "Villa", price: 800000, bonusEnergy: 20, maxStorage: 70 }
]

const VEHICLES = [
  { id: "Sepeda", price: 15000, maxFuel: 0, bonusPay: 1.02 },
  { id: "Motor", price: 60000, maxFuel: 40, bonusPay: 1.10 },
  { id: "Mobil", price: 250000, maxFuel: 90, bonusPay: 1.18 },
  { id: "Pickup", price: 450000, maxFuel: 120, bonusPay: 1.25 },
  { id: "Sport", price: 900000, maxFuel: 130, bonusPay: 1.35 }
]

const SHOP = {
  food: { price: 1200, desc: "Tambah +15 Energy" },
  medkit: { price: 5000, desc: "Tambah +40 HP" },
  material: { price: 2500, desc: "Bahan upgrade rumah/kendaraan" },
  ticket: { price: 8000, desc: "Tiket dungeon tambahan" },
  fuel: { price: 2000, desc: "Tambah +20 Fuel (butuh kendaraan bermesin)" }
}

const CITIES = ["Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Bali", "Medan", "Makassar"]

async function sendRPG(sock, m, titleText, bodyText, resultText) {
  await sock.sendMessage(m.chat, {
    text: resultText,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: titleText,
        body: bodyText,
        thumbnailUrl: global.thumbrpg,
        sourceUrl: global.linkChannel,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}

const deletedMessages = new Map();

setInterval(async () => {
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    
    for (let [chatId, settings] of Object.entries(groupSettings)) {
        if (settings.autoClose && settings.autoOpen) {
            try {
                const metadata = await sock.groupMetadata(chatId);
                const isBotAdmin = metadata.participants.some(p => 
                    p.id === sock.user.id && p.admin
                );
                
                if (!isBotAdmin) continue;
                
                // Tutup grup
                if (currentTime === settings.autoClose) {
                    await sock.groupSettingUpdate(chatId, 'announcement');
                    await sock.sendMessage(chatId, {
                        text: `🔒 *GRUP OTOMATIS DITUTUP*\n\n` +
                             `⏰ Waktu: ${currentTime}\n` +
                             `📢 Grup akan dibuka kembali jam ${settings.autoOpen}\n\n` +
                             `Hanya admin yang bisa kirim pesan.`
                    });
                }
                
                // Buka grup
                if (currentTime === settings.autoOpen) {
                    await sock.groupSettingUpdate(chatId, 'not_announcement');
                    await sock.sendMessage(chatId, {
                        text: `🔓 *GRUP OTOMATIS DIBUKA*\n\n` +
                             `⏰ Waktu: ${currentTime}\n` +
                             `📢 Semua member bisa kirim pesan!\n\n` +
                             `Selamat beraktivitas! 🎉`
                    });
                }
            } catch (err) {
                console.error('Auto Close/Open Error:', err);
            }
        }
    }
}, 60000); // Cek setiap 1 menit    
   
let dbai = {}
  try {
    dbai = JSON.parse(fs.readFileSync("./Database/set-ai.json"))
  } catch {
    dbai = { autachatai: {} }
  }

  const isAuto = dbai?.autachatai?.[m.sender] === true

  if (!isCmd && m.body && !m.isGroup && !m.isBaileys) {
  const fs = require("fs")
  const axios = require("axios")

  let dbai = { autachatai: {} }
  if (fs.existsSync("./Database/set-ai.json")) {
    try {
      dbai = JSON.parse(fs.readFileSync("./Database/set-ai.json"))
    } catch {
      dbai = { autachatai: {} }
    }
  }

  const isAuto = dbai?.autachatai?.[m.sender] === true

  if (isAuto) {
    // charge energy tiap 1 balasan (non-premium)
    if (!isPremium) {
      if (!energy[m.sender]) energy[m.sender] = 0

      if (energy[m.sender] < 1) {
        await sock.sendMessage(
          m.chat,
          { text: "⚠️ Energy tidak cukup! (butuh 1 ⚡ untuk AutoChatAI)" },
          { quoted: m }
        )
      } else {
        energy[m.sender] -= 1
        fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))

        await sock.sendPresenceUpdate("composing", m.chat)
        await delay(Math.floor(Math.random() * 600) + 300)
        await sock.sendPresenceUpdate("paused", m.chat)

        let aiText = ""
        try {
          const api = `https://apiz.rafzsoffc.cloud/ai/deepai?apikey=zlynzeeapi&ask=${encodeURIComponent(m.body.trim())}`
          const { data } = await axios.get(api, { timeout: 120000 })
          aiText = data?.result || ""
        } catch {
          aiText = ""
        }

        if (aiText) {
          await sock.sendMessage(m.chat, { text: aiText }, { quoted: m })
        }
      }
    } else {
      // premium gratis
      await sock.sendPresenceUpdate("composing", m.chat)
      await delay(Math.floor(Math.random() * 600) + 300)
      await sock.sendPresenceUpdate("paused", m.chat)

      let aiText = ""
      try {
        const api = `https://apiz.rafzsoffc.cloud/ai/deepai?apikey=zlynzeeapi&ask=${encodeURIComponent(m.body.trim())}`
        const { data } = await axios.get(api, { timeout: 120000 })
        aiText = data?.result || ""
      } catch {
        aiText = ""
      }

      if (aiText) {
        await sock.sendMessage(m.chat, { text: aiText }, { quoted: m })
      }
    }
  }
}
               
if (!isCmd && m.isGroup && groupSettings[m.chat]?.antivirtex && !isAdmin) {
    const virtexPatterns = [
        /[\u0300-\u036F\u1AB0-\u1AFF\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]{10,}/g, // Combining marks spam
        /[\u0E00-\u0E7F]{50,}/g, // Thai character spam
        /[\u0600-\u06FF]{100,}/g, // Arabic spam
        /[\uD800-\uDFFF]{20,}/g, // Surrogate pairs spam
        /(ꦾ|ꦿ|⃟){10,}/g, // Indonesian bug
        /(\u200B|\u200C|\u200D|\uFEFF){10,}/g // Zero-width spam
    ];
    
    const isVirtex = virtexPatterns.some(pattern => pattern.test(m.body));
    
    if (isVirtex || m.body.length > 10000) {
        if (isBotAdmin) {
            await sock.sendMessage(m.chat, { delete: m.key });
            await sock.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            await sock.sendMessage(m.chat, {
                text: `🛡️ VIRTEX TERDETEKSI!\n\n@${m.sender.split('@')[0]} dikick karena kirim bug/virtex!\n\n⚠️ Grup ini dilindungi antivirtex!`,
                mentions: [m.sender]
            });
        }
    }
}

if (global.db.settings.onlygc && !m.isGroup && !isOwner) {
 return 
      }

if (!isCmd && m.isGroup && groupSettings[m.chat]?.antilink2 && !isAdmin) {
    const linkRegex = /(https?:\/\/|www\.)/gi;
    if (linkRegex.test(m.body)) {
        if (isBotAdmin) {
            await sock.sendMessage(m.chat, { delete: m.key });
            await sock.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            await sock.sendMessage(m.chat, {
                text: `🚫 @${m.sender.split('@')[0]} dikick karena kirim link!\n\n⚠️ Antilink 2 aktif di grup ini!`,
                mentions: [m.sender]
            });
        }
    }
}

if (!isCmd && m.isGroup && groupSettings[m.chat]?.antilink1 && !isAdmin) {
    const linkRegex = /(https?:\/\/|www\.)/gi;
    if (linkRegex.test(m.body)) {
        if (isBotAdmin) {
            await sock.sendMessage(m.chat, { delete: m.key });
            await sock.sendMessage(m.chat, {
                text: `⚠️ Link terdeteksi!\n@${m.sender.split('@')[0]}, pesan kamu dihapus karena mengandung link!`,
                mentions: [m.sender]
            });
        }
    }
}

if (m.isGroup && bannedGroups.includes(m.chat) && isCmd) {
    return; 
}    
    
if (!isCmd && m.body && m.isGroup && games[m.chat]?.lagu) {
    const game = games[m.chat].lagu;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    const correctArtist = game.artis.toLowerCase();
    
    if (game.answered) return;
    
    // Bisa jawab judul saja atau judul + artis
    if (userAnswer === correctAnswer || userAnswer.includes(correctAnswer)) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Judul: *${correctAnswer.toUpperCase()}*\n` +
                 `Artis: *${correctArtist.toUpperCase()}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.tebaklagu* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].lagu;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.lirik) {
    const game = games[m.chat].lirik;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    // Toleransi jawaban (minimal 70% kesamaan)
    const similarity = userAnswer.includes(correctAnswer) || correctAnswer.includes(userAnswer);
    
    if (userAnswer === correctAnswer || similarity) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Lirik lengkap:\n*${game.soal} ${correctAnswer}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.tebaklirik* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].lirik;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.gambar) {
    const game = games[m.chat].gambar;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer.toUpperCase()}*\n` +
                 `Penjelasan: ${game.deskripsi}\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.tebakgambar* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].gambar;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!global.mode_public && !isOwner && !isPremium && isCmd) {
    return;
}    
    
if (!isCmd && m.body && m.isGroup && games[m.chat]?.bendera) {
    const game = games[m.chat].bendera;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer.toUpperCase()}*\n` +
                 `Bendera: ${game.bendera}\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.tebakbendera* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].bendera;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.math) {
    const game = games[m.chat].math;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toUpperCase();
    const correctAnswer = game.jawaban.toUpperCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer}. ${game.pilihan[correctAnswer]}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.math* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].math;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.lengkapi) {
    const game = games[m.chat].lengkapi;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    // Toleransi jawaban (bisa pakai includes atau exact match)
    if (userAnswer === correctAnswer || correctAnswer.includes(userAnswer)) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Kalimat lengkap:\n*${game.soal} ${correctAnswer.toUpperCase()}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.lengkapikalimat* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].lengkapi;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.quiz) {
    const game = games[m.chat].quiz;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toUpperCase();
    const correctAnswer = game.jawaban.toUpperCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer}. ${game.pilihan[correctAnswer]}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.quiz* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].quiz;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.ibukota) {
    const game = games[m.chat].ibukota;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer.toUpperCase()}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.tebakibukota* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].ibukota;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.family100) {
    const game = games[m.chat].family100;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    
    // Cek apakah jawaban ada di list
    const jawabanIndex = game.jawaban.findIndex(j => j === userAnswer);
    
    if (jawabanIndex !== -1 && !game.answered.includes(userAnswer)) {
        game.answered.push(userAnswer);
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `✅ *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} menemukan jawaban!\n` +
                 `Jawaban: *${userAnswer.toUpperCase()}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `🎯 Ditemukan: ${game.answered.length}/${game.jawaban.length}\n` +
                 `${game.answered.length === game.jawaban.length ? '🎉 *SEMUA JAWABAN DITEMUKAN!*' : ''}`,
            mentions: [m.sender]
        });
        
        // Kalau semua jawaban sudah ditemukan
        if (game.answered.length === game.jawaban.length) {
            setTimeout(() => {
                delete games[m.chat].family100;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }, 3000);
        }
        
    } else if (game.answered.includes(userAnswer)) {
        await sock.sendMessage(m.chat, {
            text: `⚠️ Jawaban *${userAnswer.toUpperCase()}* sudah ditemukan!`,
        });
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.ceklontong) {
    const game = games[m.chat].ceklontong;
    
    if (!m.quoted || m.quoted.key?.id !== game.gameMessageId) return;
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer.toUpperCase()}*\n` +
                 `Penjelasan: ${game.deskripsi}\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.ceklontong* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].ceklontong;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (!isCmd && m.body && m.isGroup && games[m.chat]?.asahotak) {
    const game = games[m.chat].asahotak;
    
    if (!m.quoted || m.quoted.key.id !== game.gameMessageId) {
        return; // Bukan reply ke pesan game
    }
    
    const userAnswer = m.body.trim().toLowerCase();
    const correctAnswer = game.jawaban.toLowerCase();
    
    if (game.answered) return;
    
    if (userAnswer === correctAnswer) {
        game.answered = true;
        
        if (!energy[m.sender]) energy[m.sender] = 0;
        energy[m.sender] += 1;
        
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        
        await sock.sendMessage(m.chat, {
            text: `🏆 *BENAR!*\n\n` +
                 `@${m.sender.split('@')[0]} adalah pemenang!\n` +
                 `Jawaban: *${correctAnswer.toUpperCase()}*\n` +
                 `⚡ Energy: +1 (Total: ${energy[m.sender]})\n\n` +
                 `⏱️ Waktu: ${Math.floor((Date.now() - game.startTime) / 1000)} detik\n\n` +
                 `Ketik *.asahotak* untuk main lagi!`,
            mentions: [m.sender]
        });
        
        delete games[m.chat].asahotak;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
    } else {
        await sock.sendMessage(m.chat, {
            text: `❌ @${m.sender.split('@')[0]}, jawaban salah!\nCoba lagi!`,
            mentions: [m.sender]
        });
    }
}

if (global.db.groups[m.chat]?.antilink === true) {
    const textMessage = m.text || ""
    const groupInviteLinkRegex = /(https?:\/\/)?(www\.)?chat\.whatsapp\.com\/[A-Za-z0-9]+(\?[^\s]*)?/gi
    const links = textMessage.match(groupInviteLinkRegex)
    if (links && !isOwner && !m.isAdmin && m.isBotAdmin) {
        const senderJid = m.sender
        const messageId = m.key.id
        const participantToDelete = m.key.participant || m.sender
        await sock.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: messageId,
                participant: participantToDelete
            }
        })
        await sleep(800)
        await sock.groupParticipantsUpdate(m.chat, [senderJid], "remove")
    }
}

//###############################//

if (global.db.groups[m.chat]?.antilink2 === true) {
    const textMessage = m.text || ""
    const groupInviteLinkRegex = /(https?:\/\/)?(www\.)?chat\.whatsapp\.com\/[A-Za-z0-9]+(\?[^\s]*)?/gi
    const links = textMessage.match(groupInviteLinkRegex)
    if (links && !isOwner && !m.isAdmin && m.isBotAdmin) {
        const messageId = m.key.id
        const participantToDelete = m.key.participant || m.sender
        await sock.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: messageId,
                participant: participantToDelete
            }
        })
    }
}

//###############################//

switch (command) {
case "menu": {
let status = "User";
if (isOwner) status = "Owner";
else if (isPremium) status = "Premium";

const teks = `
Haii @${m.sender.split("@")[0]} 👋
Selamat ${ucapan()}

*# Bot - Information*
- Botmode: ${sock.public ? "Public" : "Self"}
- Runtime: ${runtime(process.uptime())}
- Developer: @${global.owner}
- Energy: ${userEnergy} ⚡
- Money: $${userMoney} 💰
- Status: ${status}

dapetin energy? .claimreward

Silahkan pilih menu di bawah ini!
`;

let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                header: {
                    hasMediaAttachment: true, 
                    ...(await prepareWAMessageMedia({ image: { url: global.thumbnail } }, { upload: sock.waUploadToServer })),
                }, 
                body: { text: teks },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Menu Utama ⬇️",
                                sections: [
                                    {
                                        title: "Pilih Menu",
                                        rows: [
                                            {
                                                title: "All Menu",
                                                description: "Menampilkan Semua Menu Bot",
                                                id: ".mainmenu"
                                            },
                                            {
                                                title: "Sticker Menu",
                                                description: "Menu untuk membuat sticker",
                                                id: ".stickermenu"
                                            },
                                            {
                                                title: "Download Menu",
                                                description: "Menu untuk download media",
                                                id: ".downloadmenu"
                                            },
                                            {
                                                title: "RPG Menu",
                                                description: "Menu permainan RPG",
                                                id: ".rpgmenu"
                                            },
                                            {
                                                title: "Primbon Menu",
                                                description: "Menu ramalan primbon",
                                                id: ".primbonmenu"
                                            },
                                            {
                                                title: "Group Menu",
                                               description: "Menu untuk manage grup",
                                                id: ".groupmenu"
                                            },
                                            {
                                                title: "Game Menu",
                                                description: "Menu permainan seru",
                                                id: ".gamemenu"
                                            },
                                            {
                                                title: "Tools Menu",
                                                description: "Berbagai alat & utilitas bot",
                                                id: ".toolsmenu"
                                            },
                                            {
                                                title: "AI Menu",
                                                description: "Fitur AI chat & bantuan",
                                                id: ".autochatai"
                                            },
                                            {
                                                title: "Create Image Menu",
                                                description: "Buat gambar dari teks",
                                                id: ".createimagemenu"
                                            },
                                            {
                                                title: "Tools Image Menu",
                                                description: "Tools edit/convert gambar",
                                                id: ".toolsimagemenu"
                                            },
                                            {
                                                title: "Shop Menu",
                                                description: "Toko item, premium, dll",
                                                id: ".shopmenu"
                                            },
                                            {
                                                title: "Owner Menu",
                                                description: "Menu khusus owner bot",
                                                id: ".ownermenu"
                                            }
                                        ]
                                    }
                                ]
                            })
                        }
                    ]
                },
                contextInfo: {
                    mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
                }
            }
        }
    }
}, { userJid: m.sender, quoted: FakeSticker });

await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break

case "toolsmenu": {
    const hour = new Date().getHours()
    let ucapan
    if (hour < 10) ucapan = "pagi 🌅"
    else if (hour < 15) ucapan = "siang ☀️"
    else if (hour < 18) ucapan = "sore 🌇"
    else ucapan = "malam 🌙"

    const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU TOOLS*
┏━━━━━━━━━━⟢
┃ .cekdns <domain>
┃ .cekhost <url>
┃ .fakemail
┃ .cekinboxmail <id>
┃ .mapskordinator <lokasi>
┃ .proxy <url>
┃ .ssurl <url>|<phone/desktop>
┃ .shortlink <url>|<type>
┃ .ceknik <id nik>
┗━━━━━━━━━━━━⟢`

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia(
                            { image: { url: global.thumb } },
                            { upload: sock.waUploadToServer }
                        ))
                    },
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` },
                            { name: "cta_url", buttonParamsJson: `{"display_text":"📢 Join Channel","url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A","merchant_url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A"}` }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "120363420619530273@newsletter",
                            serverMessageId: 1,
                            newsletterName: "Click Saluran"
                        }
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break

case "rpgmenu":
case "menurpg": {
  const resultText = `🎮 *RPG ROLEPLAY MENU*

🔰 BASIC
• .joinrpg
• .status / .profile
• .inv
• .daily
• .leaderboard

💼 JOB
• .joblist
• .job <nama job>
• .work
• .overtime
• .resign
• .promotion

🏪 SHOP & ITEM
• .shop
• .buy <item> <jumlah>
• .use <food|medkit>

🏠 PROPERTY
• .houselist
• .buyhouse <nama>
• .sellhouse
• .upgradehouse
• .furniture

🚗 VEHICLE
• .vehiclelist
• .buyvehicle <nama>
• .sellvehicle
• .upgradevehicle
• .fuel <jumlah>

🏦 BANK
• .bank
• .deposit <jumlah>
• .withdraw <jumlah>
• .loan <jumlah>
• .paydebt <jumlah>

🏋️ STATS
• .training
• .gym
• .meditation
• .upgrade <atk|def|luck|cha>

⚔️ ACTION
• .hunt
• .dungeon
• .crime
• .jail
• .escape

🌆 LIFE
• .city
• .travel <nama kota>
• .event
• .reputation
• .marry @tag
• .divorce
• .guildcreate <nama>
• .guildjoin <nama>
• .guildleave
• .guild
`
  await sendRPG(sock, m, "🎮 RPG MENU", "50+ fitur aktif", resultText)
}
break

case "toolsimagemenu": {
  const hour = new Date().getHours()
  let ucapan
  if (hour < 10) ucapan = "pagi 🌅"
  else if (hour < 15) ucapan = "siang ☀️"
  else if (hour < 18) ucapan = "sore 🌇"
  else ucapan = "malam 🌙"

  const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU TOOLS IMAGE*
┏━━━━━━━━━━⟢
┃ .smeme <atas|bawah>
┃ .blurface
┃ .compres
┃ .image2jpg
┃ .image2png
┃ .upscale <2/4>
┃ .convphoto <template|style>
┃ .faceswap
┃ .removebg
┃ .hd <2-8>
┃ .remini <2-8>
┗━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ Reply foto untuk semua fitur di atas
│ Khusus .faceswap: reply Foto 2 (Foto 2 harus reply Foto 1)
╰━━━━━━━━━━━━━━━━━━━╯`

  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia(
              { image: { url: global.thumb } },
              { upload: sock.waUploadToServer }
            ))
          },
          body: { text: teks },
          nativeFlowMessage: {
            buttons: [
              { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` },
              { name: "cta_url", buttonParamsJson: `{"display_text":"📢 Join Channel","url":"${global.linkChannel}","merchant_url":"${global.linkChannel}"}` }
            ]
          },
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363420619530273@newsletter",
              serverMessageId: 1,
              newsletterName: "Click Saluran"
            }
          }
        }
      }
    }
  }, { userJid: m.sender, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break        

case "createimagemenu": {
  const hour = new Date().getHours()
  let ucapan
  if (hour < 10) ucapan = "pagi 🌅"
  else if (hour < 15) ucapan = "siang ☀️"
  else if (hour < 18) ucapan = "sore 🌇"
  else ucapan = "malam 🌙"

  const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU CREATE IMAGE*
┏━━━━━━━━━━⟢
┃ .cfoto1 <teks>
┃ .cfoto2 <teks>
┃ .cfoto3 <teks>
┃ .cfoto4 <teks>
┃ .cfoto5 <teks>
┃ .cfoto6 <teks>
┃ .cfoto7 <teks>
┃ .cfoto8 <teks>
┃ .cfoto9 <teks>
┃ .cfoto10 <teks>
┃ .iqc <time|battery|pesan|provider>
┃ .aifreebox <prompt>
┗━━━━━━━━━━━━⟢`

  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia(
              { image: { url: global.thumb } },
              { upload: sock.waUploadToServer }
            ))
          },
          body: { text: teks },
          nativeFlowMessage: {
            buttons: [
              { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` },
              { name: "cta_url", buttonParamsJson: `{"display_text":"📢 Join Channel","url":"${global.linkChannel}","merchant_url":"${global.linkChannel}"}` }
            ]
          },
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363420619530273@newsletter",
              serverMessageId: 1,
              newsletterName: "Click Saluran"
            }
          }
        }
      }
    }
  }, { userJid: m.sender, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break        
 
case "aifreebox": {
  const axios = require("axios")

  const slugs = [
    "ai-blonde-models-generator",
    "ai-anime-profile-picture-generator",
    "ai-claymation-image-generator",
    "ai-dynamic-toon-sketch-designer",
    "ai-black-anime-girl-generator",
    "ai-demon-slayer-wallpaper-generator",
    "ai-anime-character-generator",
    "ai-old-cartoon-characters-generator",
    "ai-clashart-image-generator",
    "ai-shinobiverse-image-generator",
    "ai-2d-pixel-games-art-generator",
    "ai-simpleline-character-creator",
    "ai-quirkycartoon-generator",
    "ai-stickman-poster-t-shirt-designs-generator",
    "ai-fat-cartoon-characters-generator",
    "ai-zelda-wallpaper-generator",
    "ai-pixel-art-generator"
  ]

  if (!text) return m.reply("❌ Contoh:\n.aifreebox buatkan gambar kucing\natau\n.aifreebox ai-anime-profile-picture-generator|buatkan gambar kucing")

  // kalau user cuma kasih prompt -> tampilkan pilihan slug
  if (!text.includes("|")) {
    const prompt = text.trim()

    const rows = slugs.map(s => ({
      title: s,
      description: "Pilih slug untuk generate",
      id: `${prefix}aifreebox ${s}|${prompt}`
    }))

    const pickText = `Pilih *slug* untuk AI Freebox (Aspect 16:9)\n\nPrompt:\n${prompt}`

    let msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia(
                { image: { url: global.thumb } },
                { upload: sock.waUploadToServer }
              ))
            },
            body: { text: pickText },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "Pilih Slug ⬇️",
                    sections: [
                      { title: "AI Freebox Slug", rows }
                    ]
                  })
                },
                { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` }
              ]
            },
            contextInfo: { mentionedJid: [m.sender] }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  // format: slug|prompt
  let [slugRaw, promptRaw] = text.split("|")
  let slug = (slugRaw || "").trim()
  let prompt = (promptRaw || "").trim()

  // kalau kebalik (prompt|slug)
  if (!slugs.includes(slug) && slugs.includes(prompt)) {
    const tmp = slug
    slug = prompt
    prompt = tmp
  }

  if (!slugs.includes(slug)) {
    // kalau slug salah, munculin pilihan lagi
    const rows = slugs.map(s => ({
      title: s,
      description: "Pilih slug yang valid",
      id: `${prefix}aifreebox ${s}|${prompt || "buatkan gambar keren"}`
    }))

    let msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia(
                { image: { url: global.thumb } },
                { upload: sock.waUploadToServer }
              ))
            },
            body: { text: `❌ Slug tidak valid.\nPilih salah satu slug di bawah ini.` },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "Pilih Slug ⬇️",
                    sections: [{ title: "AI Freebox Slug", rows }]
                  })
                }
              ]
            }
          }
        }
      }
    }, { userJid: m.sender, quoted: m })

    return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  if (!prompt) return m.reply("❌ Prompt kosong.\nContoh:\n.aifreebox " + slug + "|buatkan gambar kucing")

  try {
    const api =
      `https://apiz.rafzsoffc.cloud/imagecreator/aifreebox?apikey=zlynzeeapi` +
      `&prompt=${encodeURIComponent(prompt)}` +
      `&slug=${encodeURIComponent(slug)}` +
      `&aspectRatio=16%3A9`

    const { data } = await axios.get(api, { timeout: 180_000 })
    const imgUrl = data?.result?.imageUrl
    if (!data?.status || !imgUrl) return m.reply("❌ Gagal generate gambar (API error).")

    const img = await axios.get(imgUrl, { responseType: "arraybuffer", timeout: 180_000 })
    const buf = Buffer.from(img.data)

    await sock.sendMessage(
      m.chat,
      { image: buf, caption: `✅ AI Freebox (16:9)\nSlug: ${slug}\nPrompt: ${prompt}` },
      { quoted: m }
    )
  } catch (e) {
    m.reply("❌ Gagal generate gambar, coba lagi nanti.")
  }
}
break        
        
case "iqc": {
  if (!text || !text.includes("|"))
    return m.reply("❌ Format salah!\nContoh:\n.iqc 14:41|41|Annjng|Ngawi")

  let [time, battery, messageText, provider] = text.split("|").map(v => (v || "").trim())
  if (!time || !battery || !messageText || !provider)
    return m.reply("❌ Isi semua!\n.iqc time|battery|message|provider")

  try {
    const api =
      `https://apiz.rafzsoffc.cloud/imagecreator/iqc?apikey=zlynzeeapi` +
      `&time=${encodeURIComponent(time)}` +
      `&battery=${encodeURIComponent(battery)}` +
      `&messageText=${encodeURIComponent(messageText)}` +
      `&provider=${encodeURIComponent(provider)}`

    const res = await axios.get(api, { responseType: "arraybuffer" })
    const buf = Buffer.from(res.data)

    await sock.sendMessage(m.chat, { image: buf, caption: "✅ IQC berhasil dibuat!" }, { quoted: m })
  } catch (e) {
    m.reply("❌ Gagal buat IQC, coba lagi.")
  }
}
break        
        
case "cfoto1":
case "cfoto2":
case "cfoto3":
case "cfoto4":
case "cfoto5":
case "cfoto6":
case "cfoto7":
case "cfoto8":
case "cfoto9":
case "cfoto10": {
  if (!text) return m.reply("❌ Masukkan text!\nContoh: .cfoto1 vreden")

  const map = {
    cfoto1: "glitchtext",
    cfoto2: "writetext",
    cfoto3: "advancedglow",
    cfoto4: "cartoonstyle",
    cfoto5: "royaltext",
    cfoto6: "effectclouds",
    cfoto7: "galaxystyle",
    cfoto8: "luxurygold",
    cfoto9: "blackpinklogo",
    cfoto10: "flag3dtext"
  }

  const cmd = command.toLowerCase()
  const type = map[cmd]
  if (!type) return m.reply("❌ Tipe tidak ditemukan!")

  try {
    const api = `https://api.vreden.my.id/api/v1/maker/ephoto/${type}?text=${encodeURIComponent(text.trim())}`
    const { data } = await axios.get(api)

    const imgUrl = data?.result
    if (!imgUrl) return m.reply("❌ Gagal generate gambar (result kosong).")

    const buf = await uguu.getBuffer(imgUrl)
    await sock.sendMessage(m.chat, { image: buf, caption: `✅ Selesai: ${cmd}\nText: ${text.trim()}` }, { quoted: m })
  } catch (e) {
    m.reply("❌ Error generate gambar, coba lagi.")
  }
}
break        
        
case "joinrpg": {
  if (RPG.users[m.sender]) {
    await sendRPG(sock, m, "🎮 JOIN RPG", "Akun sudah ada", "❌ Kamu sudah punya akun RPG.\nKetik .status untuk lihat profil.")
    break
  }
  ensureUser(m.sender, m.pushName)
  const u = RPG.users[m.sender]
  const resultText = `🎉 *SELAMAT DATANG DI RPG ROLEPLAY!*

👤 Nama: ${u.name}
🏷 Rank: ${rankName(u.level)}
💰 Uang awal: ${rupiah(u.money)}
⚡ Energy: ${u.energy}/${u.maxEnergy}
❤️ HP: ${u.hp}/${u.maxHp}

Langkah awal:
1) .joblist → lihat 7 job
2) .job <nama job> → pilih kerja
3) .work → cari uang
4) .shop → beli item
5) .houselist → beli rumah

⚠️ RPG ini roleplay: kerja, upgrade hidup, beli rumah & kendaraan.`
  saveRPG()
  await sendRPG(sock, m, "🎉 JOIN RPG", "Akun dibuat dari nol", resultText)
}
break

case "status":
case "profile": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const resultText = `👤 *RPG PROFILE*

Nama: ${u.name}
🏷 Rank: ${rankName(u.level)}
Level: ${u.level}
EXP: ${u.exp}/${u.need}

❤️ HP: ${u.hp}/${u.maxHp}
⚡ Energy: ${u.energy}/${u.maxEnergy}

💼 Job: ${u.job || "-"} (Lv.${u.jobLevel})
💰 Cash: ${rupiah(u.money)}
🏦 Bank: ${rupiah(u.bank)}
💳 Utang: ${rupiah(u.debt)}

🏠 Rumah: ${u.house ? `${u.house} (Lv.${u.houseLevel})` : "-"}
🚗 Kendaraan: ${u.vehicle ? `${u.vehicle} (Lv.${u.vehicleLevel})` : "-"}
⛽ Fuel: ${u.maxFuel ? `${u.fuel}/${u.maxFuel}` : "-"}

⚔️ ATK: ${u.stats.atk}  🛡 DEF: ${u.stats.def}
🍀 LUCK: ${u.stats.luck}  😎 CHA: ${u.stats.cha}

⭐ Reputasi: ${u.reputation}
💍 Menikah: ${u.marriedTo ? "Ya" : "Tidak"}`
  await sendRPG(sock, m, "👤 PROFILE", `Rank ${rankName(u.level)}`, resultText)
}
break

case "inv":
case "inventory": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const resultText = `🎒 *INVENTORY*

🍔 Food: ${u.inventory.food}
🩹 Medkit: ${u.inventory.medkit}
🧱 Material: ${u.inventory.material}
🎫 Ticket: ${u.inventory.ticket}

💰 Cash: ${rupiah(u.money)}
🏦 Bank: ${rupiah(u.bank)}`
  await sendRPG(sock, m, "🎒 INVENTORY", "Lihat itemmu", resultText)
}
break

case "daily": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const now = Date.now()
  const cd = 24 * 60 * 60 * 1000
  const left = cd - (now - u.last.daily)
  if (left > 0) {
    await sendRPG(sock, m, "🎁 DAILY", "Cooldown aktif", `⏳ Daily belum siap.\nTunggu: ${msToTime(left)}`)
    break
  }

  const bonusMoney = 15000 + (u.level * 500)
  const bonusFood = 2
  u.money += bonusMoney
  u.inventory.food += bonusFood
  u.energy = clamp(u.energy + 20, 0, u.maxEnergy)
  u.last.daily = now

  saveRPG()
  const resultText = `🎁 *DAILY CLAIM*

💰 Cash +${rupiah(bonusMoney)}
🍔 Food +${bonusFood}
⚡ Energy +20

Sekarang:
Cash: ${rupiah(u.money)}
Energy: ${u.energy}/${u.maxEnergy}`
  await sendRPG(sock, m, "🎁 DAILY", `+${rupiah(bonusMoney)}`, resultText)
}
break

case "leaderboard":
case "toprpg": {
  if (!RPG.users[m.sender]) return m.reply("❌ Ketik .joinrpg dulu")

  const list = Object.entries(RPG.users)
    .sort((a, b) => (b[1].level - a[1].level) || (b[1].money - a[1].money))
    .slice(0, 10)

  let teks = "🏆 *LEADERBOARD RPG (TOP 10)*\n\n"
  list.forEach(([jid, u], i) => {
    teks += `${i + 1}. ${u.name}\n   Lv.${u.level} (${rankName(u.level)}) • Cash ${rupiah(u.money)}\n`
  })

  await sendRPG(sock, m, "🏆 LEADERBOARD", "Top player RPG", teks.trim())
}
break

case "joblist": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  let teks = "💼 *DAFTAR 7 JOB RPG*\n\n"
  JOBS.forEach((j, i) => {
    teks += `${i + 1}. ${j.name}\n   Gaji: ${rupiah(j.min)} - ${rupiah(j.max)} | Energy: -${j.energy} | CD: ${Math.floor(j.cd/60000)} menit\n\n`
  })
  teks += "Pilih: .job <nama job>\nContoh: .job Driver Ojek"

  await sendRPG(sock, m, "💼 JOB LIST", "Pilih pekerjaanmu", teks.trim())
}
break

case "job": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!text) return m.reply("Contoh: .job Driver Ojek")

  const job = JOBS.find(j => j.name.toLowerCase() === text.trim().toLowerCase())
  if (!job) {
    await sendRPG(sock, m, "💼 JOB", "Tidak ditemukan", "❌ Job tidak ditemukan.\nKetik .joblist untuk lihat daftar job.")
    break
  }

  u.job = job.name
  u.jobLevel = 1
  saveRPG()

  const resultText = `✅ *JOB DIPILIH*

Kamu sekarang bekerja sebagai:
💼 ${u.job} (Lv.${u.jobLevel})

Mulai kerja:
• .work
• .overtime (bonus gaji, biaya energy lebih besar)`
  await sendRPG(sock, m, "✅ JOB", u.job, resultText)
}
break

case "resign": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.job) {
    await sendRPG(sock, m, "💼 RESIGN", "Kamu belum bekerja", "❌ Kamu belum punya job.\nKetik .joblist lalu pilih job.")
    break
  }
  u.job = null
  u.jobLevel = 1
  saveRPG()
  await sendRPG(sock, m, "💼 RESIGN", "Berhenti kerja", "✅ Kamu resign.\nKetik .joblist untuk pilih job baru.")
}
break

case "promotion": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.job) return m.reply("❌ Pilih job dulu (.joblist)")
  const cost = 30000 * u.jobLevel
  if (u.money < cost) {
    await sendRPG(sock, m, "📈 PROMOTION", "Uang kurang", `❌ Uang kurang.\nButuh: ${rupiah(cost)}\nCash kamu: ${rupiah(u.money)}`)
    break
  }
  u.money -= cost
  u.jobLevel += 1
  u.stats.cha += 1
  saveRPG()
  await sendRPG(sock, m, "📈 PROMOTION", `Job Lv.${u.jobLevel}`, `✅ Promosi berhasil!\n💼 ${u.job} sekarang Lv.${u.jobLevel}\n😎 CHA +1\n💰 Biaya: ${rupiah(cost)}`)
}
break

case "work": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (isJailed(u)) {
    await sendRPG(sock, m, "⛓️ JAIL", "Kamu sedang dipenjara", `❌ Kamu masih di penjara.\nSisa: ${msToTime(u.jailUntil - Date.now())}`)
    break
  }
  if (!u.job) return m.reply("❌ Pilih job dulu (.joblist)")

  const job = JOBS.find(j => j.name === u.job)
  const now = Date.now()
  const left = job.cd - (now - u.last.work)
  if (left > 0) {
    await sendRPG(sock, m, "💼 WORK", "Cooldown aktif", `⏳ Kamu masih capek.\nTunggu: ${msToTime(left)}`)
    break
  }
  if (u.energy < job.energy) {
    await sendRPG(sock, m, "⚡ ENERGY", "Tidak cukup", `❌ Energy tidak cukup.\nButuh: ${job.energy}\nEnergy kamu: ${u.energy}/${u.maxEnergy}\nGunakan: .rest / .use food`)
    break
  }

  let base = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min
  let mult = 1 + (u.jobLevel - 1) * 0.06
  let vehicleMult = 1
  if (u.vehicle) {
    const v = VEHICLES.find(x => x.id === u.vehicle)
    if (v) vehicleMult = v.bonusPay + (u.vehicleLevel * 0.02)
  }
  let pay = Math.floor(base * mult * vehicleMult)

  u.money += pay
  u.energy -= job.energy
  u.last.work = now

  const leveled = addExp(u, 20 + Math.floor(pay / 1500))
  if (leveled) u.reputation += 1

  saveRPG()

  let extra = leveled ? `\n\n🆙 Level Up x${leveled}!\nSekarang Lv.${u.level} (${rankName(u.level)})` : ""
  const resultText = `💼 *KERJA SELESAI*

Job: ${u.job} (Lv.${u.jobLevel})
Gaji: +${rupiah(pay)}
Energy: -${job.energy}

Cash sekarang: ${rupiah(u.money)}
⚡ Energy: ${u.energy}/${u.maxEnergy}${extra}`
  await sendRPG(sock, m, "💼 WORK", `+${rupiah(pay)}`, resultText)
}
break

case "overtime": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.job) return m.reply("❌ Pilih job dulu (.joblist)")
  if (isJailed(u)) return

  const now = Date.now()
  const cd = 20 * 60 * 1000
  const left = cd - (now - (u.last.overtime || 0))
  if (left > 0) {
    await sendRPG(sock, m, "⏳ OVERTIME", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  const costE = 18
  if (u.energy < costE) {
    await sendRPG(sock, m, "⚡ ENERGY", "Tidak cukup", `Butuh ${costE} energy.\nEnergy kamu: ${u.energy}/${u.maxEnergy}`)
    break
  }

  const job = JOBS.find(j => j.name === u.job)
  const base = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min
  const pay = Math.floor(base * 1.6 * (1 + (u.jobLevel - 1) * 0.06))

  u.money += pay
  u.energy -= costE
  u.last.overtime = now

  addExp(u, 35)
  saveRPG()

  await sendRPG(sock, m, "💼 OVERTIME", `+${rupiah(pay)}`, `🔥 *OVERTIME SELESAI*\n\nJob: ${u.job}\nBonus Gaji: +${rupiah(pay)}\nEnergy: -${costE}\nCash: ${rupiah(u.money)}`)
}
break

case "rest": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const now = Date.now()
  const cd = 5 * 60 * 1000
  const left = cd - (now - u.last.rest)
  if (left > 0) {
    await sendRPG(sock, m, "😴 REST", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  let bonus = 30 + Math.floor(Math.random() * 25)
  if (u.house) {
    const h = HOUSES.find(x => x.id === u.house)
    if (h) bonus += Math.floor(h.bonusEnergy / 2) + u.houseLevel
  }
  u.energy = clamp(u.energy + bonus, 0, u.maxEnergy)
  u.hp = clamp(u.hp + 10, 0, u.maxHp)
  u.last.rest = now
  saveRPG()

  await sendRPG(sock, m, "😴 REST", `+${bonus} Energy`, `😴 *ISTIRAHAT SELESAI*\n\n⚡ Energy +${bonus}\n❤️ HP +10\nSekarang: ${u.energy}/${u.maxEnergy} energy`)
}
break

case "shop": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const resultText = `🏪 *SHOP RPG*

1) food — ${rupiah(SHOP.food.price)} (${SHOP.food.desc})
2) medkit — ${rupiah(SHOP.medkit.price)} (${SHOP.medkit.desc})
3) material — ${rupiah(SHOP.material.price)} (${SHOP.material.desc})
4) ticket — ${rupiah(SHOP.ticket.price)} (${SHOP.ticket.desc})
5) fuel — ${rupiah(SHOP.fuel.price)} (${SHOP.fuel.desc})

Cara beli:
.buy <item> <jumlah>
Contoh:
.buy food 2
.buy material 5`
  await sendRPG(sock, m, "🏪 SHOP", "Beli item roleplay", resultText)
}
break

case "buy": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const args = text.trim().split(/\s+/)
  const item = (args[0] || "").toLowerCase()
  const qty = clamp(parseInt(args[1] || "1"), 1, 999)

  if (!SHOP[item]) {
    await sendRPG(sock, m, "🛒 BUY", "Item tidak ada", "❌ Item tidak tersedia.\nKetik .shop untuk daftar item.")
    break
  }

  if (item === "fuel" && (!u.vehicle || u.maxFuel <= 0)) {
    await sendRPG(sock, m, "⛽ FUEL", "Butuh kendaraan", "❌ Kamu butuh kendaraan bermesin (Motor/Mobil/dll) untuk membeli fuel.\nKetik .vehiclelist")
    break
  }

  const cost = SHOP[item].price * qty
  if (u.money < cost) {
    await sendRPG(sock, m, "🛒 BUY", "Uang kurang", `❌ Uang kurang.\nButuh: ${rupiah(cost)}\nCash kamu: ${rupiah(u.money)}`)
    break
  }

  u.money -= cost

  if (item === "fuel") {
    u.fuel = clamp(u.fuel + (20 * qty), 0, u.maxFuel)
  } else {
    u.inventory[item] = (u.inventory[item] || 0) + qty
  }

  saveRPG()
  await sendRPG(sock, m, "🛒 BUY", `-${rupiah(cost)}`, `✅ Pembelian berhasil!\nItem: ${item} x${qty}\nBiaya: ${rupiah(cost)}\nCash: ${rupiah(u.money)}`)
}
break

case "use": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const item = (text || "").toLowerCase().trim()
  if (!["food", "medkit"].includes(item)) {
    await sendRPG(sock, m, "🧾 USE", "Item tidak valid", "Contoh:\n.use food\n.use medkit")
    break
  }

  if ((u.inventory[item] || 0) < 1) {
    await sendRPG(sock, m, "🧾 USE", "Item habis", `❌ ${item} kamu habis.\nKetik .shop untuk beli.`)
    break
  }

  u.inventory[item] -= 1
  let info = ""
  if (item === "food") {
    const add = 15
    u.energy = clamp(u.energy + add, 0, u.maxEnergy)
    info = `⚡ Energy +${add}\nSekarang: ${u.energy}/${u.maxEnergy}`
  } else {
    const add = 40
    u.hp = clamp(u.hp + add, 0, u.maxHp)
    info = `❤️ HP +${add}\nSekarang: ${u.hp}/${u.maxHp}`
  }

  saveRPG()
  await sendRPG(sock, m, "🧾 USE", item.toUpperCase(), `✅ Kamu menggunakan ${item}.\n\n${info}`)
}
break

case "houselist": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  let teks = "🏠 *DAFTAR RUMAH*\n\n"
  HOUSES.forEach((h, i) => {
    teks += `${i + 1}. ${h.id}\n   Harga: ${rupiah(h.price)} | Bonus Energy: +${h.bonusEnergy}\n\n`
  })
  teks += "Beli: .buyhouse <nama>\nContoh: .buyhouse Rumah Bata"

  await sendRPG(sock, m, "🏠 HOUSE LIST", "Beli rumah & upgrade hidup", teks.trim())
}
break

case "buyhouse": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!text) return m.reply("Contoh: .buyhouse Rumah Bata")
  if (u.house) {
    await sendRPG(sock, m, "🏠 BUY HOUSE", "Kamu sudah punya rumah", `❌ Kamu sudah punya rumah: ${u.house}\nGunakan .upgradehouse atau .sellhouse`)
    break
  }

  const h = HOUSES.find(x => x.id.toLowerCase() === text.toLowerCase())
  if (!h) {
    await sendRPG(sock, m, "🏠 BUY HOUSE", "Tidak ditemukan", "❌ Rumah tidak ditemukan.\nKetik .houselist")
    break
  }

  if (u.money < h.price) {
    await sendRPG(sock, m, "🏠 BUY HOUSE", "Uang kurang", `Butuh ${rupiah(h.price)}.\nCash kamu: ${rupiah(u.money)}`)
    break
  }

  u.money -= h.price
  u.house = h.id
  u.houseLevel = 1
  u.maxEnergy += h.bonusEnergy
  u.energy = clamp(u.energy + 10, 0, u.maxEnergy)

  saveRPG()
  await sendRPG(sock, m, "🏠 PROPERTY", "Rumah berhasil dibeli", `✅ Kamu membeli *${h.id}*!\nHarga: ${rupiah(h.price)}\nBonus max energy: +${h.bonusEnergy}\nCash: ${rupiah(u.money)}\nMax Energy: ${u.maxEnergy}`)
}
break

case "sellhouse": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.house) {
    await sendRPG(sock, m, "🏠 SELL HOUSE", "Tidak punya rumah", "❌ Kamu belum punya rumah.\nKetik .houselist")
    break
  }

  const h = HOUSES.find(x => x.id === u.house)
  const sell = Math.floor((h ? h.price : 0) * (0.55 + (u.houseLevel * 0.05)))
  u.money += sell

  if (h) u.maxEnergy = Math.max(100, u.maxEnergy - h.bonusEnergy)
  u.energy = clamp(u.energy, 0, u.maxEnergy)
  u.house = null
  u.houseLevel = 0

  saveRPG()
  await sendRPG(sock, m, "🏠 SELL HOUSE", `+${rupiah(sell)}`, `✅ Rumah terjual.\nCash +${rupiah(sell)}\nCash sekarang: ${rupiah(u.money)}`)
}
break

case "upgradehouse": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.house) return m.reply("❌ Kamu belum punya rumah")

  const costMat = 10 + (u.houseLevel * 8)
  const costMoney = 20000 + (u.houseLevel * 30000)
  if (u.inventory.material < costMat || u.money < costMoney) {
    await sendRPG(sock, m, "🔧 UPGRADE HOUSE", "Resource kurang",
      `Butuh:\n🧱 Material: ${costMat}\n💰 Cash: ${rupiah(costMoney)}\n\nKamu punya:\n🧱 ${u.inventory.material}\n💰 ${rupiah(u.money)}`
    )
    break
  }

  u.inventory.material -= costMat
  u.money -= costMoney
  u.houseLevel += 1
  u.maxEnergy += 2
  u.maxHp += 5
  u.hp = u.maxHp

  saveRPG()
  await sendRPG(sock, m, "🔧 UPGRADE HOUSE", `Lv.${u.houseLevel}`, `✅ Upgrade rumah berhasil!\n🏠 ${u.house} sekarang Lv.${u.houseLevel}\nMax Energy +2\nMax HP +5`)
}
break

case "furniture": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.house) return m.reply("❌ Kamu butuh rumah dulu (.houselist)")

  const resultText = `🛋️ *FURNITURE (ROLEPLAY)*

Furniture memberi efek kecil:
• Sofa (cha +1) — butuh material 10 + cash 25.000
• Meja Kerja (atk +1) — butuh material 12 + cash 35.000
• Rak Obat (maxHp +10) — butuh material 15 + cash 50.000

Gunakan:
.furniturebuy sofa
.furniturebuy meja
.furniturebuy rak`
  await sendRPG(sock, m, "🛋️ FURNITURE", "Upgrade gaya hidup", resultText)
}
break

case "furniturebuy": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.house) return m.reply("❌ Kamu butuh rumah dulu")

  const key = (text || "").toLowerCase().trim()
  const data = {
    sofa: { mat: 10, money: 25000, apply: () => (u.stats.cha += 1), note: "😎 CHA +1" },
    meja: { mat: 12, money: 35000, apply: () => (u.stats.atk += 1), note: "⚔️ ATK +1" },
    rak:  { mat: 15, money: 50000, apply: () => (u.maxHp += 10, u.hp = u.maxHp), note: "❤️ MaxHP +10" }
  }[key]

  if (!data) {
    await sendRPG(sock, m, "🛋️ FURNITURE", "Pilihan salah", "Contoh:\n.furniturebuy sofa\n.furniturebuy meja\n.furniturebuy rak")
    break
  }

  if (u.inventory.material < data.mat || u.money < data.money) {
    await sendRPG(sock, m, "🛋️ FURNITURE", "Resource kurang",
      `Butuh:\n🧱 ${data.mat} material\n💰 ${rupiah(data.money)}\n\nKamu punya:\n🧱 ${u.inventory.material}\n💰 ${rupiah(u.money)}`
    )
    break
  }

  u.inventory.material -= data.mat
  u.money -= data.money
  data.apply()
  saveRPG()
  await sendRPG(sock, m, "🛋️ FURNITURE", "Pembelian sukses", `✅ Furniture terpasang.\n${data.note}`)
}
break

case "vehiclelist": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  let teks = "🚗 *DAFTAR KENDARAAN*\n\n"
  VEHICLES.forEach((v, i) => {
    teks += `${i + 1}. ${v.id}\n   Harga: ${rupiah(v.price)} | Bonus gaji: ${(v.bonusPay * 100 - 100).toFixed(0)}%\n\n`
  })
  teks += "Beli: .buyvehicle <nama>\nContoh: .buyvehicle Motor"

  await sendRPG(sock, m, "🚗 VEHICLE LIST", "Kendaraan bantu kerja", teks.trim())
}
break

case "buyvehicle": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!text) return m.reply("Contoh: .buyvehicle Motor")
  if (u.vehicle) {
    await sendRPG(sock, m, "🚗 BUY VEHICLE", "Sudah punya", `❌ Kamu sudah punya: ${u.vehicle}\nGunakan .upgradevehicle atau .sellvehicle`)
    break
  }

  const v = VEHICLES.find(x => x.id.toLowerCase() === text.toLowerCase())
  if (!v) {
    await sendRPG(sock, m, "🚗 BUY VEHICLE", "Tidak ditemukan", "❌ Kendaraan tidak ditemukan.\nKetik .vehiclelist")
    break
  }
  if (u.money < v.price) {
    await sendRPG(sock, m, "🚗 BUY VEHICLE", "Uang kurang", `Butuh ${rupiah(v.price)}.\nCash kamu: ${rupiah(u.money)}`)
    break
  }

  u.money -= v.price
  u.vehicle = v.id
  u.vehicleLevel = 1
  u.maxFuel = v.maxFuel
  u.fuel = v.maxFuel ? Math.min(20, v.maxFuel) : 0

  saveRPG()
  await sendRPG(sock, m, "🚗 VEHICLE", "Kendaraan dibeli", `✅ Kamu membeli *${v.id}*!\nHarga: ${rupiah(v.price)}\nCash: ${rupiah(u.money)}\nFuel: ${u.maxFuel ? `${u.fuel}/${u.maxFuel}` : "-"}`)
}
break

case "sellvehicle": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.vehicle) return m.reply("❌ Kamu belum punya kendaraan")

  const v = VEHICLES.find(x => x.id === u.vehicle)
  const sell = Math.floor((v ? v.price : 0) * (0.55 + (u.vehicleLevel * 0.05)))

  u.money += sell
  u.vehicle = null
  u.vehicleLevel = 0
  u.fuel = 0
  u.maxFuel = 0

  saveRPG()
  await sendRPG(sock, m, "🚗 SELL VEHICLE", `+${rupiah(sell)}`, `✅ Kendaraan terjual.\nCash +${rupiah(sell)}\nCash: ${rupiah(u.money)}`)
}
break

case "upgradevehicle": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.vehicle) return m.reply("❌ Kamu belum punya kendaraan")

  const costMat = 8 + (u.vehicleLevel * 6)
  const costMoney = 25000 + (u.vehicleLevel * 45000)

  if (u.inventory.material < costMat || u.money < costMoney) {
    await sendRPG(sock, m, "🔧 UPGRADE VEHICLE", "Resource kurang",
      `Butuh:\n🧱 ${costMat} material\n💰 ${rupiah(costMoney)}\n\nKamu punya:\n🧱 ${u.inventory.material}\n💰 ${rupiah(u.money)}`
    )
    break
  }

  u.inventory.material -= costMat
  u.money -= costMoney
  u.vehicleLevel += 1
  if (u.maxFuel) u.maxFuel += 10
  u.stats.luck += (u.vehicleLevel % 3 === 0 ? 1 : 0)

  saveRPG()
  await sendRPG(sock, m, "🔧 UPGRADE VEHICLE", `Lv.${u.vehicleLevel}`, `✅ Upgrade kendaraan berhasil!\n🚗 ${u.vehicle} sekarang Lv.${u.vehicleLevel}\n⛽ MaxFuel ${u.maxFuel || 0}`)
}
break

case "fuel": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.vehicle || !u.maxFuel) return m.reply("❌ Kamu butuh kendaraan bermesin dulu")

  const add = clamp(parseInt(text || "0"), 1, 999)
  const cost = SHOP.fuel.price * add

  if (u.money < cost) {
    await sendRPG(sock, m, "⛽ FUEL", "Uang kurang", `Butuh ${rupiah(cost)}.\nCash kamu: ${rupiah(u.money)}`)
    break
  }

  u.money -= cost
  u.fuel = clamp(u.fuel + (20 * add), 0, u.maxFuel)
  saveRPG()

  await sendRPG(sock, m, "⛽ FUEL", `-${rupiah(cost)}`, `✅ Isi fuel berhasil.\nFuel: ${u.fuel}/${u.maxFuel}\nCash: ${rupiah(u.money)}`)
}
break

case "bank": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")

  const now = Date.now()
  const cd = 24 * 60 * 60 * 1000
  const left = cd - (now - u.last.interest)
  let interestText = ""
  if (left <= 0 && u.bank > 0) {
    const interest = Math.floor(u.bank * 0.01)
    u.bank += interest
    u.last.interest = now
    saveRPG()
    interestText = `\n\n💹 Bunga harian +${rupiah(interest)} (1%)`
  }

  const resultText = `🏦 *BANK ACCOUNT*

💰 Cash: ${rupiah(u.money)}
🏦 Bank: ${rupiah(u.bank)}
💳 Utang: ${rupiah(u.debt)}${interestText}

Perintah:
.deposit <jumlah>
.withdraw <jumlah>
.loan <jumlah>
.paydebt <jumlah>`
  await sendRPG(sock, m, "🏦 BANK", "Simpan uang & bunga", resultText)
}
break

case "deposit": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const amount = Math.floor(Number(text || 0))
  if (!amount || amount < 1000) return m.reply("Contoh: .deposit 5000")
  if (u.money < amount) return m.reply("❌ Cash kurang")

  u.money -= amount
  u.bank += amount
  saveRPG()

  await sendRPG(sock, m, "🏦 DEPOSIT", `+${rupiah(amount)}`, `✅ Deposit berhasil.\n🏦 Bank: ${rupiah(u.bank)}\n💰 Cash: ${rupiah(u.money)}`)
}
break

case "withdraw": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const amount = Math.floor(Number(text || 0))
  if (!amount || amount < 1000) return m.reply("Contoh: .withdraw 5000")
  if (u.bank < amount) return m.reply("❌ Saldo bank kurang")

  u.bank -= amount
  u.money += amount
  saveRPG()

  await sendRPG(sock, m, "🏦 WITHDRAW", `+${rupiah(amount)}`, `✅ Withdraw berhasil.\n🏦 Bank: ${rupiah(u.bank)}\n💰 Cash: ${rupiah(u.money)}`)
}
break

case "loan": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const amount = Math.floor(Number(text || 0))
  if (!amount || amount < 10000) return m.reply("Contoh: .loan 50000")
  if (u.debt > 0) return m.reply("❌ Kamu masih punya utang. Bayar dulu dengan .paydebt")

  const fee = Math.floor(amount * 0.10)
  u.money += amount
  u.debt = amount + fee
  saveRPG()

  await sendRPG(sock, m, "💳 LOAN", `+${rupiah(amount)}`, `✅ Pinjaman cair.\nCash +${rupiah(amount)}\nBiaya admin 10%: ${rupiah(fee)}\nTotal utang: ${rupiah(u.debt)}`)
}
break

case "paydebt": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const amount = Math.floor(Number(text || 0))
  if (!amount || amount < 1000) return m.reply("Contoh: .paydebt 5000")
  if (u.debt <= 0) return m.reply("✅ Kamu tidak punya utang.")
  if (u.money < amount) return m.reply("❌ Cash kurang.")

  const pay = Math.min(amount, u.debt)
  u.money -= pay
  u.debt -= pay
  saveRPG()

  await sendRPG(sock, m, "💳 PAY DEBT", `-${rupiah(pay)}`, `✅ Pembayaran utang.\nSisa utang: ${rupiah(u.debt)}\nCash: ${rupiah(u.money)}`)
}
break

case "training": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (isJailed(u)) return

  const now = Date.now()
  const cd = 60 * 60 * 1000
  const left = cd - (now - u.last.training)
  if (left > 0) {
    await sendRPG(sock, m, "💪 TRAINING", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  const costE = 20
  if (u.energy < costE) {
    await sendRPG(sock, m, "⚡ ENERGY", "Tidak cukup", `Butuh ${costE} energy.\nEnergy kamu: ${u.energy}/${u.maxEnergy}`)
    break
  }

  const pick = ["atk", "def", "luck", "cha"]
  const trained = pick[Math.floor(Math.random() * pick.length)]
  const inc = trained === "luck" ? 1 : (Math.floor(Math.random() * 3) + 1)

  u.energy -= costE
  u.stats[trained] += inc
  u.last.training = now
  addExp(u, 40)

  saveRPG()

  const resultText = `💪 *TRAINING BERHASIL*

Stat dilatih: ${trained.toUpperCase()}
Peningkatan: +${inc}

⚡ Energy: ${u.energy}/${u.maxEnergy}
⭐ EXP bertambah, cek .status`
  await sendRPG(sock, m, "💪 TRAINING", `+${inc} ${trained.toUpperCase()}`, resultText)
}
break

case "gym": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const costE = 25
  if (u.energy < costE) return m.reply("❌ Energy kurang")
  u.energy -= costE
  u.stats.atk += 2
  u.stats.def += 1
  addExp(u, 25)
  saveRPG()
  await sendRPG(sock, m, "🏋️ GYM", "+ATK/DEF", `🏋️ *GYM SELESAI*\nATK +2\nDEF +1\nEnergy -${costE}`)
}
break

case "meditation": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const costE = 15
  if (u.energy < costE) return m.reply("❌ Energy kurang")
  u.energy -= costE
  u.stats.cha += 1
  u.stats.luck += (Math.random() < 0.25 ? 1 : 0)
  addExp(u, 20)
  saveRPG()
  await sendRPG(sock, m, "🧘 MEDITATION", "Mind & Luck", `🧘 *MEDITASI SELESAI*\nCHA +1\nChance LUCK +1 (25%)\nEnergy -${costE}`)
}
break

case "upgrade": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const stat = (text || "").toLowerCase().trim()
  if (!["atk", "def", "luck", "cha"].includes(stat)) return m.reply("Contoh: .upgrade atk")

  const costMat = 8
  const costMoney = 15000
  if (u.inventory.material < costMat || u.money < costMoney) {
    await sendRPG(sock, m, "🧬 UPGRADE STAT", "Resource kurang", `Butuh ${costMat} material + ${rupiah(costMoney)}.\nKamu punya ${u.inventory.material} material & ${rupiah(u.money)}.`)
    break
  }

  u.inventory.material -= costMat
  u.money -= costMoney
  u.stats[stat] += 1
  saveRPG()

  await sendRPG(sock, m, "🧬 UPGRADE STAT", `+1 ${stat.toUpperCase()}`, `✅ Upgrade berhasil.\n${stat.toUpperCase()} +1\nCash: ${rupiah(u.money)}`)
}
break

case "crime": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const now = Date.now()
  const cd = 45 * 60 * 1000
  const left = cd - (now - u.last.crime)
  if (left > 0) {
    await sendRPG(sock, m, "😈 CRIME", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }
  if (u.energy < 20) return m.reply("❌ Energy kurang")

  u.energy -= 20
  u.last.crime = now

  const chance = 0.45 + (u.stats.luck * 0.02) + (u.stats.cha * 0.01)
  const success = Math.random() < clamp(chance, 0.15, 0.85)

  if (!success) {
    u.jailUntil = Date.now() + (20 * 60 * 1000)
    u.reputation = Math.max(0, u.reputation - 2)
    saveRPG()
    await sendRPG(sock, m, "🚔 CRIME", "Tertangkap!", `🚔 *AKSI GAGAL*\nKamu tertangkap polisi!\n⛓️ Masuk penjara 20 menit.\nReputasi -2`)
    break
  }

  const loot = 8000 + Math.floor(Math.random() * 15000)
  u.money += loot
  u.reputation += 1
  addExp(u, 35)
  saveRPG()

  await sendRPG(sock, m, "😈 CRIME", `+${rupiah(loot)}`, `😈 *CRIME BERHASIL*\nCash +${rupiah(loot)}\nReputasi +1\nEnergy tersisa: ${u.energy}/${u.maxEnergy}`)
}
break

case "jail": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!isJailed(u)) {
    await sendRPG(sock, m, "⛓️ JAIL", "Kamu bebas", "✅ Kamu tidak sedang dipenjara.")
    break
  }
  await sendRPG(sock, m, "⛓️ JAIL", "Masih ditahan", `⛓️ Kamu masih di penjara.\nSisa: ${msToTime(u.jailUntil - Date.now())}`)
}
break

case "escape": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!isJailed(u)) return m.reply("✅ Kamu tidak sedang dipenjara.")

  const chance = 0.25 + (u.stats.luck * 0.03)
  const success = Math.random() < clamp(chance, 0.05, 0.70)

  if (!success) {
    u.jailUntil += 10 * 60 * 1000
    saveRPG()
    await sendRPG(sock, m, "⛓️ ESCAPE", "Gagal kabur", `❌ Kamu gagal kabur.\nHukuman bertambah 10 menit.\nSisa: ${msToTime(u.jailUntil - Date.now())}`)
    break
  }

  u.jailUntil = 0
  u.reputation = Math.max(0, u.reputation - 1)
  saveRPG()
  await sendRPG(sock, m, "🏃 ESCAPE", "Berhasil kabur", "✅ Kamu berhasil kabur dari penjara!\nReputasi -1")
}
break

case "hunt": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (isJailed(u)) return

  const now = Date.now()
  const cd = 25 * 60 * 1000
  const left = cd - (now - u.last.hunt)
  if (left > 0) {
    await sendRPG(sock, m, "🐺 HUNT", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  const costE = 18
  if (u.energy < costE) return m.reply("❌ Energy kurang")
  u.energy -= costE
  u.last.hunt = now

  const monsterLv = Math.max(1, Math.floor(u.level / 3) + 1)
  const dmg = Math.floor(Math.random() * 18) + 8
  u.hp = clamp(u.hp - dmg, 0, u.maxHp)

  const gold = 6000 + (monsterLv * 1200) + Math.floor(Math.random() * 5000)
  const mat = (Math.random() < 0.35) ? 1 : 0
  const food = (Math.random() < 0.25) ? 1 : 0

  if (u.hp <= 0) {
    u.hp = 1
    u.reputation = Math.max(0, u.reputation - 1)
    saveRPG()
    await sendRPG(sock, m, "💀 HUNT", "Kalah berburu", `💀 Kamu kalah saat berburu.\nHP disisakan 1.\nReputasi -1`)
    break
  }

  u.money += gold
  if (mat) u.inventory.material += mat
  if (food) u.inventory.food += food
  addExp(u, 45)

  saveRPG()
  await sendRPG(sock, m, "🐺 HUNT", `+${rupiah(gold)}`, `🐺 *HUNT BERHASIL*\nDamage diterima: ${dmg}\nCash +${rupiah(gold)}\n${mat ? "🧱 Material +1\n" : ""}${food ? "🍔 Food +1\n" : ""}❤️ HP: ${u.hp}/${u.maxHp}\n⚡ Energy: ${u.energy}/${u.maxEnergy}`)
}
break

case "dungeon": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (isJailed(u)) return

  const now = Date.now()
  const cd = 2 * 60 * 60 * 1000
  const left = cd - (now - u.last.dungeon)
  if (left > 0) {
    await sendRPG(sock, m, "🏰 DUNGEON", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  const costE = 30
  if (u.energy < costE) return m.reply("❌ Energy kurang")
  if (u.inventory.ticket < 1) {
    await sendRPG(sock, m, "🎫 TICKET", "Tidak ada", "❌ Kamu butuh Ticket untuk masuk dungeon.\nBeli di .shop lalu .buy ticket 1")
    break
  }

  u.energy -= costE
  u.inventory.ticket -= 1
  u.last.dungeon = now

  const winChance = 0.55 + (u.stats.atk * 0.01) + (u.stats.luck * 0.02) - (u.level * 0.003)
  const win = Math.random() < clamp(winChance, 0.20, 0.85)

  if (!win) {
    u.hp = clamp(u.hp - 45, 1, u.maxHp)
    saveRPG()
    await sendRPG(sock, m, "🏰 DUNGEON", "Gagal clear", `💀 Dungeon gagal.\n❤️ HP -45\nHP sekarang: ${u.hp}/${u.maxHp}\nTicket terpakai: 1`)
    break
  }

  const loot = 30000 + (u.level * 1500) + Math.floor(Math.random() * 25000)
  const mat = 3 + Math.floor(Math.random() * 3)
  u.money += loot
  u.inventory.material += mat
  addExp(u, 120)
  u.reputation += 2

  saveRPG()
  await sendRPG(sock, m, "🏰 DUNGEON", `+${rupiah(loot)}`, `🏰 *DUNGEON CLEARED!*\nCash +${rupiah(loot)}\n🧱 Material +${mat}\n⭐ Reputasi +2\nTicket terpakai: 1`)
}
break

case "city": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const current = u.city || "Jakarta"
  const resultText = `🌆 *CITY*

Kota kamu sekarang: ${current}

Daftar kota:
${CITIES.map(x => "• " + x).join("\n")}

Pindah kota:
.travel <nama kota>
Contoh:
.travel Bali`
  await sendRPG(sock, m, "🌆 CITY", "Roleplay kota", resultText)
}
break

case "travel": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!text) return m.reply("Contoh: .travel Bali")
  const dest = CITIES.find(x => x.toLowerCase() === text.toLowerCase())
  if (!dest) return m.reply("❌ Kota tidak ditemukan. Ketik .city")

  const now = Date.now()
  const cd = 20 * 60 * 1000
  const left = cd - (now - u.last.travel)
  if (left > 0) {
    await sendRPG(sock, m, "🚕 TRAVEL", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }

  const cost = 8000
  const costE = 10
  if (u.money < cost) return m.reply("❌ Uang kurang buat travel")
  if (u.energy < costE) return m.reply("❌ Energy kurang")

  u.money -= cost
  u.energy -= costE
  u.city = dest
  u.last.travel = now
  u.reputation += 1
  saveRPG()

  await sendRPG(sock, m, "🚕 TRAVEL", dest, `🚕 Kamu pindah ke *${dest}*.\nBiaya: ${rupiah(cost)}\nEnergy -${costE}\nReputasi +1`)
}
break

case "event": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const now = Date.now()
  const cd = 30 * 60 * 1000
  const left = cd - (now - u.last.event)
  if (left > 0) {
    await sendRPG(sock, m, "🎲 EVENT", "Cooldown aktif", `Tunggu: ${msToTime(left)}`)
    break
  }
  u.last.event = now

  const roll = Math.random()
  let textEvent = ""
  if (roll < 0.25) {
    const gain = 3000 + Math.floor(Math.random() * 8000)
    u.money += gain
    textEvent = `🍀 Kamu menemukan peluang kecil.\nCash +${rupiah(gain)}`
  } else if (roll < 0.50) {
    const loss = 2000 + Math.floor(Math.random() * 7000)
    u.money = Math.max(0, u.money - loss)
    textEvent = `🚧 Kamu kena kejadian tak terduga (tilang/biaya).\nCash -${rupiah(loss)}`
  } else if (roll < 0.75) {
    u.inventory.material += 1
    textEvent = `🧱 Kamu menemukan material.\nMaterial +1`
  } else {
    u.energy = clamp(u.energy + 10, 0, u.maxEnergy)
    textEvent = `☕ Kamu dapat istirahat bonus.\nEnergy +10`
  }

  saveRPG()
  await sendRPG(sock, m, "🎲 EVENT", "Kejadian random kota", `🎲 *EVENT KOTA*\n\n${textEvent}\n\nCash: ${rupiah(u.money)}\nEnergy: ${u.energy}/${u.maxEnergy}`)
}
break

case "reputation": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  await sendRPG(sock, m, "⭐ REPUTATION", `Skor ${u.reputation}`, `⭐ *REPUTASI*\n\nReputasi: ${u.reputation}\n\nNaikkan dengan:\n• work / overtime\n• dungeon clear\n• travel\n\nTurun dengan:\n• crime gagal\n• hunt kalah`)
}
break

case "marry": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (u.marriedTo) return m.reply("❌ Kamu sudah menikah.")
  const target = m.mentionedJid?.[0]
  if (!target) return m.reply("Contoh: .marry @tag")

  const t = RPG.users[target]
  if (!t) return m.reply("❌ Target belum joinrpg.")
  if (t.marriedTo) return m.reply("❌ Target sudah menikah.")

  const cost = 50000
  if (u.money < cost) return m.reply(`❌ Biaya nikah ${rupiah(cost)}.`)

  u.money -= cost
  u.marriedTo = target
  t.marriedTo = m.sender
  u.reputation += 2
  t.reputation += 2

  saveRPG()
  await sendRPG(sock, m, "💍 MARRIAGE", "Selamat!", `💍 *MENIKAH BERHASIL*\n\n${u.name} 💞 ${t.name}\nBiaya: ${rupiah(cost)}\nReputasi +2`)
}
break

case "divorce": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.marriedTo) return m.reply("❌ Kamu belum menikah.")

  const partner = u.marriedTo
  const p = RPG.users[partner]
  u.marriedTo = null
  if (p && p.marriedTo === m.sender) p.marriedTo = null
  u.reputation = Math.max(0, u.reputation - 1)
  if (p) p.reputation = Math.max(0, p.reputation - 1)

  saveRPG()
  await sendRPG(sock, m, "💔 DIVORCE", "Hubungan berakhir", "💔 Perceraian diproses.\nReputasi -1")
}
break

case "guildcreate": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const name = (text || "").trim()
  if (!name) return m.reply("Contoh: .guildcreate NightCity")
  if (RPG.guilds[name]) return m.reply("❌ Nama guild sudah dipakai.")

  const cost = 75000
  if (u.money < cost) return m.reply(`❌ Biaya buat guild ${rupiah(cost)}.`)

  u.money -= cost
  RPG.guilds[name] = { owner: m.sender, members: [m.sender], level: 1, points: 0 }
  u.guild = name

  saveRPG()
  await sendRPG(sock, m, "🛡️ GUILD", "Guild dibuat", `✅ Guild *${name}* dibuat.\nBiaya: ${rupiah(cost)}\nKetik .guild untuk lihat info.`)
}
break

case "buypremium": {
  const fs = require("fs")
  const pakasir = require("./lib/pakasir")

  const PRICE_PREMIUM = 15000

  if (!global.pakasir_apikey || !global.pakasir_slug) {
    return m.reply("❌ Pakasir belum diset!\nIsi global.pakasir_apikey dan global.pakasir_slug di settings.js")
  }

  const order_id = `PREMIUM-${Date.now()}-${m.sender.split("@")[0]}`

  try {
    const res = await pakasir.createQris({
      project: global.pakasir_slug,
      api_key: global.pakasir_apikey,
      order_id,
      amount: PRICE_PREMIUM
    })

    const pay = res?.payment
    if (!pay?.payment_number) return m.reply("❌ Gagal membuat QRIS (payment_number kosong).")

    if (!global.pakasirPending) global.pakasirPending = {}
    global.pakasirPending[order_id] = {
      type: "premium",
      user: m.sender,
      amount: PRICE_PREMIUM,
      createdAt: Date.now()
    }

    fs.writeFileSync(
      "./Database/pakasir-orders.json",
      JSON.stringify({ pending: global.pakasirPending }, null, 2)
    )

    const qrBuf = await pakasir.qrisToBuffer(pay.payment_number)

    await sock.sendMessage(m.chat, {
      image: qrBuf,
      caption:
        `⭐ *BELI PREMIUM*\n\n` +
        `• Order ID: ${order_id}\n` +
        `• Harga: Rp${PRICE_PREMIUM}\n` +
        `• Fee: Rp${pay.fee}\n` +
        `• Total: Rp${pay.total_payment}\n` +
        `• Expired: ${pay.expired_at}\n\n` +
        `Scan QR untuk bayar.\n` +
        `Jika sukses premium aktif otomatis ✅\n` +
        `Batal: *.batalorder ${order_id}*`
    }, { quoted: m })
  } catch (e) {
    console.error("[BUYPREMIUM ERROR]", e?.message || e)
    m.reply(`❌ Gagal membuat pembayaran premium.\nAlasan: ${e?.message || "Unknown error"}`)
  }
}
break        
 
case "shopmenu": {
  const hour = new Date().getHours()
  let ucapan
  if (hour < 10) ucapan = "pagi 🌅"
  else if (hour < 15) ucapan = "siang ☀️"
  else if (hour < 18) ucapan = "sore 🌇"
  else ucapan = "malam 🌙"

  const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU SHOP*
┏━━━━━━━━━━⟢
┃ .buylimit <jumlah>
┃ .buypremium
┃ .batalorder <id>
┗━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ 1 Limit = 150p
│ Premium = Rp15.000
│ Pembayaran via QRIS (Pakasir)
╰━━━━━━━━━━━━━━━━━━━╯`

  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia(
              { image: { url: global.thumb } },
              { upload: sock.waUploadToServer }
            ))
          },
          body: { text: teks },
          nativeFlowMessage: {
            buttons: [
              { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` },
              { name: "cta_url", buttonParamsJson: `{"display_text":"📢 Join Channel","url":"${global.linkChannel}","merchant_url":"${global.linkChannel}"}` }
            ]
          },
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363420619530273@newsletter",
              serverMessageId: 1,
              newsletterName: "Click Saluran"
            }
          }
        }
      }
    }
  }, { userJid: m.sender, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break        
        
case "guildjoin": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  const name = (text || "").trim()
  if (!name) return m.reply("Contoh: .guildjoin NightCity")
  const g = RPG.guilds[name]
  if (!g) return m.reply("❌ Guild tidak ditemukan.")
  if (u.guild) return m.reply("❌ Kamu sudah di guild. Keluar dulu: .guildleave")
  if (g.members.includes(m.sender)) return m.reply("✅ Kamu sudah member.")

  g.members.push(m.sender)
  u.guild = name
  saveRPG()

  await sendRPG(sock, m, "🛡️ GUILD", "Join guild", `✅ Kamu join guild *${name}*.\nMember sekarang: ${g.members.length}`)
}
break

case "guildleave": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.guild) return m.reply("❌ Kamu belum masuk guild.")

  const g = RPG.guilds[u.guild]
  if (g) {
    g.members = g.members.filter(x => x !== m.sender)
    if (g.owner === m.sender) {
      if (g.members.length) g.owner = g.members[0]
      else delete RPG.guilds[u.guild]
    }
  }
  u.guild = null
  saveRPG()

  await sendRPG(sock, m, "🛡️ GUILD", "Keluar guild", "✅ Kamu keluar dari guild.")
}
break

case "guild": {
  const u = RPG.users[m.sender]
  if (!u) return m.reply("❌ Ketik .joinrpg dulu")
  if (!u.guild || !RPG.guilds[u.guild]) {
    await sendRPG(sock, m, "🛡️ GUILD", "Belum punya guild", "Kamu belum punya guild.\nBuat: .guildcreate <nama>\nJoin: .guildjoin <nama>")
    break
  }
  const g = RPG.guilds[u.guild]
  const ownerName = RPG.users[g.owner]?.name || "Unknown"
  const resultText = `🛡️ *GUILD INFO*

Nama: ${u.guild}
Owner: ${ownerName}
Level: ${g.level}
Points: ${g.points}
Member: ${g.members.length}

Perintah:
• .guildleave
• (opsional nanti) guild war / raid`
  await sendRPG(sock, m, "🛡️ GUILD", u.guild, resultText)
}
break

case "downloadmenu": {
// Ambil waktu untuk ucapan
const hour = new Date().getHours();
let ucapan;
if (hour < 10) ucapan = "pagi 🌅";
else if (hour < 15) ucapan = "siang ☀️";
else if (hour < 18) ucapan = "sore 🌇";
else ucapan = "malam 🌙";

const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

Selamat malam 🌙 @⁨off⁩

乂  *MENU DOWNLOADER*
┏━━━━━━━━━━⟢
┃ .capcut <url> Ⓛ
┃ .fb <url> Ⓛ
┃ .tiktok <url> Ⓛ
┃ .spotify <url> Ⓛ
┃ .ig Ⓛ
┃ .boxep Ⓛ
┃ .ig <url>
┃ .dlit <platform> <url> Ⓛ
┃ .mediafire <url> Ⓛ
┃ .pindl <url> Ⓛ
┃ .play <judul> Ⓛ
┃ .song <judul> Ⓛ Ⓟ
┃ .sfiledl <url> Ⓛ
┃ .videy <url> Ⓛ
┃ .ytmp3 <url> Ⓛ
┃ .ytmp44
┃ .yts <query> Ⓛ
┃ .ytmp4 <url> Ⓛ
┃ .lahelu <url>
┗━━━━━━━━━━━━⟢`;

// Kirim pesan dengan gambar dan forward channel
let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                header: {
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({ 
                        image: { url: global.thumb } 
                    }, { upload: sock.waUploadToServer }))
                },
                body: { text: teks },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: `{"display_text":"📱 Menu Utama","id":".menu"}`
                        },
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"📢 Join Channel","url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A","merchant_url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A"}`
                        }
                    ]
                },
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363420619530273@newsletter",
                        serverMessageId: 1,
                        newsletterName: "Click Saluran"
                    }
                }
            }
        }
    }
}, { userJid: m.sender, quoted: m });

await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break        

case "ownermenu":
case "ownerm": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    const hour = new Date().getHours();
    let ucapan;
    if (hour < 10) ucapan = "pagi 🌅";
    else if (hour < 15) ucapan = "siang ☀️";
    else if (hour < 18) ucapan = "sore 🌇";
    else ucapan = "malam 🌙";

    const teks = `Selamat ${ucapan} Owner 👑

乂  *OWNER MENU*
┏━━━━━━━━━━━━━━━━━⟢
┃  📊 BOT SETTINGS
┃  ├ .public / .self
┃  ├ .onlygc
┃  ├ .mode
┃  └ .setjeda
┃  
┃  👤 USER MANAGEMENT
┃  ├ .addprem
┃  ├ .delprem
┃  └ .listprem
┃  
┃  👥 GROUP MANAGEMENT
┃  ├ .bannedgc
┃  ├ .unbangc
┃  ├ .promote
┃  ├ .demote
┃  └ .grup
┃  
┃  🛡️ GROUP PROTECTION
┃  ├ .antilink1
┃  ├ .antilink2
┃  ├ .antibot
┃  ├ .antivirtex
┃  └ .antidelete
┃  
┃  📢 BROADCAST
┃  ├ .jpm / .jpmht
┃  ├ .jpmch
┃  ├ .stopjpm
┃  ├ .pushkontak
┃  └ .stoppush
┃  
┃  ⚙️ OTHER SETTINGS
┃  ├ .addrespon
┃  ├ .delrespon
┃  ├ .listrespon
┃  ├ .bljpm
┃  ├ .delbl
┃  └ .backup
┃  
┃  🌐 PANEL CONTROL
┃  ├ .subdomain
┃  └ .installpanel
┃  
┃  🔧 UTILITIES
┃  ├ .ht
┃  ├ .kick
┃  ├ .savekontak
┃  ├ .save
┃  ├ .tourl
┃  └ .tourl2
┗━━━━━━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ © ${global.namaOwner || "Zlynzee"}
╰━━━━━━━━━━━━━━━━━━━╯`;

    // Kirim sebagai interactive message
    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({ 
                            image: { url: global.thumb } 
                        }, { upload: sock.waUploadToServer }))
                    },
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{"display_text":"📱 Menu Utama","id":".menu"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"📢 Join Channel","url":"${global.linkChannel}","merchant_url":"${global.linkChannel}"}`
                            }
                        ]
                    },
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "120363420619530273@newsletter",
                            serverMessageId: 1,
                            newsletterName: "Owner Menu"
                        }
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break        
        
 case "stickermenu": {
const hour = new Date().getHours();
let ucapan;
if (hour < 10) ucapan = "pagi 🌅";
else if (hour < 15) ucapan = "siang ☀️";
else if (hour < 18) ucapan = "sore 🌇";
else ucapan = "malam 🌙";

const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU STICKER*
┏━━━━━━━━━━⟢
┃ .brat <text>
┃ .bratvid <text>
┃ .sticker
┃ .smeme teks atas|teks bawah
┃ .swm <packname>|<author>
┃ .qc <text>
┃ .bratip <text>
┗━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ Ⓛ = Limit  Ⓟ = Premium  Ⓞ = Owner
╰━━━━━━━━━━━━━━━━━━━╯`;

// Kirim pesan dengan gambar dan forward channel
let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                header: {
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({ 
                        image: { url: global.thumb } 
                    }, { upload: sock.waUploadToServer }))
                },
                body: { text: teks },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: `{"display_text":"📱 Menu Utama","id":".menu"}`
                        },
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Click disini","url":"${global.idchannel}","merchant_url":"${global.idchannel}"}`
                        }
                    ]
                },
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363420619530273@newsletter",
                        serverMessageId: 1,
                        newsletterName: "Click disini"
                    }
                }
            }
        }
    }
}, { userJid: m.sender, quoted: m });

await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break      
 
case "primbonmenu":
case "primbon": {
    const hour = new Date().getHours();
    let ucapan;
    if (hour < 10) ucapan = "pagi 🌅";
    else if (hour < 15) ucapan = "siang ☀️";
    else if (hour < 18) ucapan = "sore 🌇";
    else ucapan = "malam 🌙";

    const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU PRIMBON*
┏━━━━━━━━━━━━━━━⟢
┃ 📛 .artinama <nama> Ⓛ
┃ 🌙 .mimpi <mimpi> Ⓛ
┃ 💞 .jodoh <nama1>|<nama2> Ⓛ
┃ ❤️ .tanggaljadi <dd-mm-yyyy> Ⓛ
┃ 🎭 .watakartis <nama>|<tgl> Ⓛ
┃ 💑 .ramalanjodoh <n1>|<tgl1>|<n2>|<tgl2> Ⓛ
┃ 💰 .rejeki <dd-mm-yyyy> Ⓛ
┃ 📅 .harib <dd-mm-yyyy> Ⓛ
┃ ⛔ .harilarangan <dd-mm-yyyy> Ⓛ
┃ 🧠 .kecocokannama <nama>|<tgl> Ⓛ
┗━━━━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ Ⓛ = Limit (1 Energy)  Ⓟ = Premium  Ⓞ = Owner
╰━━━━━━━━━━━━━━━━━━━╯

📌 *Catatan*
• Gunakan tanda | sesuai format
• Tanggal: dd-mm-yyyy
• Semua fitur berbasis Primbon Jawa
• Bersifat ramalan & kepercayaan`;

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia(
                            { image: { url: global.thumb } },
                            { upload: sock.waUploadToServer }
                        ))
                    },
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{"display_text":"📱 Menu Utama","id":".menu"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"📢 Join Channel","url":"${global.linkChannel}","merchant_url":"${global.linkChannel}"}`
                            }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "120363420619530273@newsletter",
                            serverMessageId: 1,
                            newsletterName: "Powered By Skyzopedia"
                        }
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break
        
//###############################//

case "autochatai": {
  if (m.isGroup) return m.reply("❌ Fitur ini khusus PM!")

  const arg = (text || "").toLowerCase()
  if (!["on", "off"].includes(arg))
    return m.reply("Format:\n.autochatai on\n.autachatai off")

  let dbai = {}
  try {
    dbai = JSON.parse(fs.readFileSync("./Database/set-ai.json"))
  } catch {
    dbai = { autachatai: {} }
  }

  if (!dbai.autachatai) dbai.autachatai = {}
  dbai.autachatai[m.sender] = arg === "on"

  fs.writeFileSync("./Database/set-ai.json", JSON.stringify(dbai, null, 2))

  m.reply(`✅ Auto Chat AI PM: ${arg === "on" ? "AKTIF" : "NONAKTIF"}`)
}
break
        
case "addrespon": {
if (!isOwner) return m.reply(mess.owner)
if (!text || !text.includes("|")) return m.reply(`*Contoh :* ${cmd} cmd|response`)
let [ id, response ] = text.split("|")
id = id.toLowerCase()
const res = db.settings.respon
if (res.find(v => v.id.toLowerCase() == id)) return m.reply(`Cmd ${id} sudah terdaftar dalam listrespon\nGunakan Cmd lain!`)
db.settings.respon.push({
id, 
response
})
return m.reply(`*Sukses Menambah Listrespon ✅*

- Cmd: ${id}
- Response: ${response}`)
}
break

//###############################//

case "listrespon": {
if (db.settings.respon.length < 1) return m.reply("Tidak ada listrespon.")
let teks = ""
for (let i of db.settings.respon) {
teks += `\n- *Cmd:* ${i.id}
- *Response:* ${i.response}\n`
}
return m.reply(teks)
}
break

//###############################//

case "delrespon": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh :* ${cmd} cmdnya`)
if (text.toLowerCase() == "all") {
db.settings.respon = []
return m.reply(`Berhasil menghapus semua Cmd Listrespon ✅`)
}
let res = db.settings.respon.find(v => v.id == text.toLowerCase())
if (!res) return m.reply(`Cmd Respon Tidak Ditemukan!\nKetik *.listrespon* Untuk Melihat Semua Cmd Listrespon`)
const posi = db.settings.respon.indexOf(res)
db.settings.respon.splice(posi, 1)
return m.reply(`Berhasil menghapus Cmd Listrespon *${text}* ✅`)
}
break

//###############################//

case "bljpm": case "bl": {
if (!isOwner) return m.reply(mess.owner);
let rows = []
const a = await sock.groupFetchAllParticipating()
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `ID - ${u.id}`, 
id: `.bljpm-response ${u.id}|${name}`
})
}
await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Salah Grup Chat\n`
}, { quoted: m })
}
break

//###############################//

case "bljpm-response": {
if (!isOwner) return m.reply(mess.owner)
if (!text || !text.includes("|")) return
const [ id, grupName ] = text.split("|")
if (db.settings.bljpm.includes(id)) return m.reply(`Grup ${grupName} sudah terdaftar dalam Blacklist Jpm`)
db.settings.bljpm.push(id)
return m.reply(`Berhasil Blacklist Grup ${grupName} Dari Jpm`)
}
break

//###############################//

case "delbl":
case "delbljpm": {
    if (!isOwner) return m.reply(mess.owner);

    if (db.settings.bljpm.length < 1) 
        return m.reply("Tidak ada data blacklist grup.");

    const groups = await sock.groupFetchAllParticipating();
    const Data = Object.values(groups);

    let rows = [];
    // opsi hapus semua
    rows.push({
        title: "🗑️ Hapus Semua",
        description: "Hapus semua grup dari blacklist",
        id: `.delbl-response all`
    });

    for (let id of db.settings.bljpm) {
        let name = "Unknown";
        // cari nama grup dari daftar grup aktif
        let grup = Data.find(g => g.id === id);
        if (grup) name = grup.subject || "Unknown";

        rows.push({
            title: name,
            description: `ID Grup - ${id}`,
            id: `.delbl-response ${id}|${name}`
        });
    }

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { 
                        text: `Pilih Grup Untuk Dihapus Dari Blacklist\n\nTotal Blacklist: ${db.settings.bljpm.length}` 
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "Daftar Blacklist Grup",
                                    sections: [
                                        {
                                            title: "Blacklist Terdaftar",
                                            rows: rows
                                        }
                                    ]
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "delbl-response": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return;

    if (text === "all") {
        db.settings.bljpm = [];
        return m.reply("✅ Semua data blacklist grup berhasil dihapus.");
    }

    if (text.includes("|")) {
        const [id, grupName] = text.split("|");
        if (!db.settings.bljpm.includes(id)) 
            return m.reply(`❌ Grup *${grupName}* tidak ada dalam blacklist.`);

        db.settings.bljpm = db.settings.bljpm.filter(g => g !== id);
        return m.reply(`✅ Grup *${grupName}* berhasil dihapus dari blacklist.`);
    }
}
break;

case "swm": {
    // Cek apakah ada gambar yang dikirim atau di-reply
    const quotedMime = m.quoted?.msg?.mimetype || m.quoted?.mimetype;
    const isImage = quotedMime?.includes('image') || mime?.includes('image');
    
    if (!isImage) {
        return m.reply(`Kirim/Reply foto dengan caption: ${cmd} Packname|Author`);
    }
    
    if (!text || !text.includes('|')) {
        return m.reply(`Format: ${cmd} Packname|Author\nContoh: ${cmd} MyStickerPack|MyName`);
    }
    
    // Potong energy
    if (!isPremium) {
        if (!energy[m.sender]) energy[m.sender] = 0;
        if (energy[m.sender] < 1) {
            return m.reply(`⚠️ Energy tidak cukup!\n⚡ Energy: ${energy[m.sender]}\n💎 Dibutuhkan: 1 Energy\n✨ Upgrade ke Premium untuk unlimited akses!`);
        }
        energy[m.sender] -= 1;
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
    }
    
    try {
        const [packname, author] = text.split('|').map(s => s.trim());
        
        // Ambil dari quoted atau dari message langsung
        const mediaObj = m.quoted || m;
        const mediaPath = await sock.downloadAndSaveMediaMessage(mediaObj);
        
        await sock.sendStimg(m.chat, mediaPath, m, {
            packname: packname,
            author: author,
            categories: ['🤖', '🎨']
        });
        
        fs.unlinkSync(mediaPath);
        
    } catch (err) {
        console.error('SWM Error:', err);
        m.reply(`❌ Gagal membuat sticker dengan metadata: ${err.message}`);
    }
}
break
 
case "smeme": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1)
      return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan caption:\nsmeme teks atas|teks bawah")

  if (!text.includes("|"))
    return m.reply("❌ Format salah\nContoh:\nsmeme teks atas|teks bawah")

  let [top, bottom] = text.split("|")
  top = encodeURIComponent(top.trim())
  bottom = encodeURIComponent(bottom.trim())

  const imgBuffer = await m.quoted.download()

  const form = new FormData()
  form.append("files[]", imgBuffer, {
    filename: "image.jpg",
    contentType: "image/jpeg"
  })

  const upload = await axios.post("https://uguu.se/upload", form, {
    headers: form.getHeaders()
  })

  if (!upload.data?.files?.[0])
    return m.reply("❌ Gagal upload gambar")

  const imgUrl = upload.data.files[0].url

  const memeUrl =
    `https://api.memegen.link/images/custom/${top}/${bottom}.png?background=${encodeURIComponent(imgUrl)}`

  const memeImg = await axios.get(memeUrl, {
    responseType: "arraybuffer"
  })

  if (!isPremium) {
    energy[m.sender] -= 1
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2))
  }

  await sock.sendStimg(
    m.chat,
    memeImg.data,
    m,
    {
      packname: global.packname || "Smeme Generator",
      author: global.author || "Skyzopedia"
    }
  )
}
break
 
case "cekkhodam": {
    if (!text) return m.reply(`Contoh: ${cmd} Ahmad`);
    
    if (!isPremium) {
        if (!energy[m.sender]) energy[m.sender] = 0;
        if (energy[m.sender] < 1) return m.reply(`⚠️ Energy tidak cukup!`);
        energy[m.sender] -= 1;
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
    }
    
    const khodamList = [
        '🐯 Macan Putih', '🐉 Naga Hitam', '🦅 Elang Jawa',
        '🐍 Ular Naga', '🦁 Singa Barong', '🐺 Serigala Putih',
        '🐴 Kuda Sembrani', '👼 Malaikat Pelindung', '👹 Jin Ifrit',
        '🦇 Kelelawar Malam', '🐊 Buaya Putih', '🦚 Merak Emas',
        '🐅 Harimau Sumatera', '🦌 Rusa Bercahaya', '🦊 Rubah Putih',
        '❌ Kosong (Tidak Ada Khodam)'
    ];
    
    const random = khodamList[Math.floor(Math.random() * khodamList.length)];
    
    let replyText = `*🔮 CEK KHODAM*\n\n`;
    replyText += `👤 Nama: ${text}\n`;
    replyText += `✨ Khodam: ${random}\n\n`;
    
    if (random.includes('Kosong')) {
        replyText += `❌ Maaf, kamu tidak memiliki khodam pendamping.`;
    } else {
        replyText += `🌟 Khodam yang menjaga dan melindungimu!`;
    }
    
    m.reply(replyText);
}
break;

case "antilink1": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['on', 'off'].includes(status)) {
        return m.reply(`Contoh: ${prefix}antilink1 on/off`);
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].antilink1 = status === 'on';
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Antilink 1 berhasil di${status === 'on' ? 'aktifkan' : 'nonaktifkan'}!\n\n${status === 'on' ? '⚠️ Pesan dengan link akan otomatis dihapus' : '✅ Link diperbolehkan'}`);
}
break;        
   
case "antilink2": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['on', 'off'].includes(status)) {
        return m.reply(`Contoh: ${prefix}antilink2 on/off`);
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].antilink2 = status === 'on';
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Antilink 2 berhasil di${status === 'on' ? 'aktifkan' : 'nonaktifkan'}!\n\n${status === 'on' ? '⚠️ Yang kirim link akan dikick otomatis!' : '✅ Link diperbolehkan'}`);
}
break;        
 
case "buylimit": {
  const fs = require("fs")
  const pakasir = require("./lib/pakasir")

  const PRICE_PER_LIMIT = 150

  // ✅ kalau kosong, suruh isi jumlah (JANGAN BUAT QR)
  if (!text || !text.trim()) {
    return m.reply(
      "🧾 *BELI LIMIT*\n\n" +
      "Harga: 1 limit = 150p\n\n" +
      "Contoh:\n" +
      ".buylimit 1\n" +
      ".buylimit 10\n\n" +
      "Ketik jumlahnya dulu ya."
    )
  }

  let qty = parseInt(text.trim())
  if (isNaN(qty) || qty < 1) {
    return m.reply("❌ Jumlah limit harus angka!\nContoh: .buylimit 5")
  }
  if (qty > 1000) qty = 1000

  if (!global.pakasir_apikey || !global.pakasir_slug) {
    return m.reply("❌ Pakasir belum diset!\nIsi global.pakasir_apikey dan global.pakasir_slug di settings.js")
  }

  const amount = qty * PRICE_PER_LIMIT
  const order_id = `LIMIT-${Date.now()}-${m.sender.split("@")[0]}`

  try {
    const res = await pakasir.createQris({
      project: global.pakasir_slug,
      api_key: global.pakasir_apikey,
      order_id,
      amount
    })

    const pay = res?.payment
    if (!pay?.payment_number) {
      console.error("[BUY LIMIT] payment_number kosong:", res)
      return m.reply("❌ Gagal membuat QRIS (payment_number kosong).")
    }

    // simpan pending order
    global.pakasirPending[order_id] = {
  type: "limit",
  user: m.sender,
  limit: qty,
  amount: amount,
  createdAt: Date.now()
}

    fs.writeFileSync(
      "./Database/pakasir-orders.json",
      JSON.stringify({ pending: global.pakasirPending }, null, 2)
    )

    const qrBuf = await pakasir.qrisToBuffer(pay.payment_number)

    await sock.sendMessage(m.chat, {
      image: qrBuf,
      caption:
        `🧾 *PEMBAYARAN LIMIT (QRIS)*\n\n` +
        `• Order ID: ${order_id}\n` +
        `• Beli: ${qty} Limit\n` +
        `• Harga: Rp${amount}\n` +
        `• Fee: Rp${pay.fee}\n` +
        `• Total: Rp${pay.total_payment}\n` +
        `• Expired: ${pay.expired_at}\n\n` +
        `Scan QR di atas untuk bayar.\n` +
        `Batal: *.batalorder ${order_id}*`
    }, { quoted: m })

  } catch (e) {
    console.error("[BUY LIMIT ERROR]", e?.message || e)
    m.reply(
      "❌ Gagal membuat pembayaran.\n" +
      `Alasan: ${e?.message || "Unknown error"}`
    )
  }
}
break
    
case "batalorder": {  
  if (!text) return m.reply("❌ Contoh:\n.batalorder LIMIT-xxxxx")

  const order_id = text.trim()

  if (!global.pakasirPending || !global.pakasirPending[order_id]) {
    return m.reply("❌ Order tidak ditemukan / sudah selesai / tidak pending.")
  }

  const ord = global.pakasirPending[order_id]
  if (ord.user !== m.sender && !isOwner) {
    return m.reply("❌ Kamu tidak punya akses membatalkan order ini.")
  }

  try {
    await pakasir.cancelTransaction({
      project: global.pakasir_slug,
      api_key: global.pakasir_apikey,
      order_id,
      amount: ord.amount
    })

    delete global.pakasirPending[order_id]
    fs.writeFileSync(
      "./Database/pakasir-orders.json",
      JSON.stringify({ pending: global.pakasirPending }, null, 2)
    )

    m.reply(`✅ Order dibatalkan!\nOrder ID: ${order_id}`)
  } catch (e) {
    m.reply("❌ Gagal cancel order. Coba lagi.")
  }
}
break        
        
case "antibot": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['on', 'off'].includes(status)) {
        return m.reply(`Contoh: ${prefix}antibot on/off`);
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].antibot = status === 'on';
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Antibot berhasil di${status === 'on' ? 'aktifkan' : 'nonaktifkan'}!\n\n${status === 'on' ? '🤖 Bot lain akan dikick otomatis!' : '✅ Bot lain diperbolehkan'}`);
}
break;        

case "addprem": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    let targetUser;
    
    if (m.quoted && m.quoted.sender) {
        targetUser = m.quoted.sender;
    } else {
        return m.reply(`❌ Reply pesan user yang mau di addprem!\nContoh: reply pesan user lalu ketik ${prefix}addprem`);
    }
    
    let premium = JSON.parse(fs.readFileSync('./Database/PremiumUser.json'));
    
    if (premium.includes(targetUser)) {
        return m.reply(`❌ User sudah premium!`);
    }
    
    premium.push(targetUser);
    
    fs.writeFileSync('./Database/PremiumUser.json', JSON.stringify(premium, null, 2));
    
    m.reply(`✅ Berhasil addprem!`);
}
break

case "hd":
case "remini": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .hd (atau .remini)\nOpsional: .hd 8")

  let scale = parseInt((text || "8").trim())
  if (isNaN(scale)) scale = 8
  if (scale < 2) scale = 2
  if (scale > 8) scale = 8

  try {
    // 1) upload WA image -> uguu
    const imgUrl = await uguu.uploadFromMessage(m.quoted)

    // 2) request HD
    const { downloadUrl, scale: scaleTxt, info } = await remini.enhance(imgUrl, scale)

    // 3) download result
    const outBuf = await uguu.getBuffer(downloadUrl)

    // 4) energy -1 non-premium
    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    // 5) send image
    await sock.sendMessage(
      m.chat,
      { image: outBuf, caption: `✅ HD selesai!\n• Scale: ${scaleTxt}\n• Info: ${info}` },
      { quoted: m }
    )
  } catch (e) {
    m.reply("❌ Gagal enhance HD. Coba lagi nanti.")
  }
}
break        
        
case "delprem": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    let targetUser;
    
    if (m.quoted && m.quoted.sender) {
        targetUser = m.quoted.sender;
    } else {
        return m.reply(`❌ Reply pesan user yang mau di delprem!\nContoh: reply pesan user lalu ketik ${prefix}delprem`);
    }
    
    let premium = JSON.parse(fs.readFileSync('./Database/PremiumUser.json'));
    
    if (!premium.includes(targetUser)) {
        return m.reply(`❌ User tidak ditemukan di premium list!`);
    }
    
    premium = premium.filter(user => user !== targetUser);
    
    fs.writeFileSync('./Database/PremiumUser.json', JSON.stringify(premium, null, 2));
    
    m.reply(`✅ Berhasil delprem!`);
}
break

case "listprem": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    let premium = JSON.parse(fs.readFileSync('./Database/PremiumUser.json'));
    
    if (premium.length === 0) {
        return m.reply("📭 Premium list kosong!");
    }
    
    let listText = `📋 *PREMIUM LIST*\n\n`;
    listText += `Total: ${premium.length} user\n\n`;
    
    premium.forEach((user, index) => {
        const number = user.split('@')[0];
        listText += `${index + 1}. ${number}\n`;
    });
    
    m.reply(listText);
}
break
                 
case "public": {
    if (!isOwner) return;
    
    let path = require.resolve("./settings.js");
    let data = fs.readFileSync(path, "utf-8");
    
    global.mode_public = true;
    sock.public = true;
    
    let newData = data.replace(/global\.mode_public\s*=\s*(true|false)/, "global.mode_public = true");
    fs.writeFileSync(path, newData, "utf-8");
    
    return m.reply("✅ Mode berhasil diubah menjadi *Public*");
}
break

case "self": {
    if (!isOwner) return;
    
    let path = require.resolve("./settings.js");
    let data = fs.readFileSync(path, "utf-8");
    
    global.mode_public = false;
    sock.public = false;
    
    let newData = data.replace(/global\.mode_public\s*=\s*(true|false)/, "global.mode_public = false");
    fs.writeFileSync(path, newData, "utf-8");
    
    return m.reply("✅ Mode berhasil diubah menjadi *Self*");
}
break

case "botmode":
case "mode": {
    const currentMode = global.mode_public ? "PUBLIC" : "SELF";
    
    const teks = `🤖 *BOT MODE*\n\n` +
                `Mode saat ini: *${currentMode}*\n\n` +
                `Perintah untuk mengubah mode:\n` +
                `${prefix}public - Ubah ke mode public\n` +
                `${prefix}self - Ubah ke mode self`;
    
    m.reply(teks);
}
break        
        
case "antivirtex": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['on', 'off'].includes(status)) {
        return m.reply(`Contoh: ${prefix}antivirtex on/off`);
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].antivirtex = status === 'on';
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Antivirtex berhasil di${status === 'on' ? 'aktifkan' : 'nonaktifkan'}!\n\n${status === 'on' ? '🛡️ Bug/Virtex akan dihapus & pelaku dikick!' : '✅ Proteksi dinonaktifkan'}`);
}
break;        

 case "antidelete": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['on', 'off'].includes(status)) {
        return m.reply(`Contoh: ${prefix}antidelete on/off`);
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].antidelete = status === 'on';
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Antidelete berhasil di${status === 'on' ? 'aktifkan' : 'nonaktifkan'}!\n\n${status === 'on' ? '🔍 Bot akan kirim ulang pesan yang dihapus' : '✅ Antidelete dinonaktifkan'}`);
}
break;      
 
case "promote": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    let users = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
        ? m.quoted.sender 
        : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    
    if (!users) return m.reply("❌ Tag atau reply orangnya!");
    
    try {
        await sock.groupParticipantsUpdate(m.chat, [users], 'promote');
        m.reply(`✅ Berhasil promote @${users.split('@')[0]} menjadi admin!`, null, { mentions: [users] });
    } catch (err) {
        console.error('Promote Error:', err);
        m.reply("❌ Gagal promote! Pastikan bot adalah admin.");
    }
}
break;        
 
case "demote": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    let users = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
        ? m.quoted.sender 
        : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    
    if (!users) return m.reply("❌ Tag atau reply orangnya!");
    
    try {
        await sock.groupParticipantsUpdate(m.chat, [users], 'demote');
        m.reply(`✅ Berhasil demote @${users.split('@')[0]} menjadi member!`, null, { mentions: [users] });
    } catch (err) {
        console.error('Demote Error:', err);
        m.reply("❌ Gagal demote! Pastikan bot adalah admin.");
    }
}
break;        

case "grup":
case "group": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    const status = text?.toLowerCase();
    if (!status || !['open', 'close'].includes(status)) {
        return m.reply(`Contoh:\n${prefix}grup open\n${prefix}grup close`);
    }
    
    try {
        await sock.groupSettingUpdate(m.chat, status === 'open' ? 'not_announcement' : 'announcement');
        m.reply(`✅ Grup berhasil di${status === 'open' ? 'buka' : 'tutup'}!\n\n${status === 'open' ? '🔓 Semua member bisa kirim pesan' : '🔒 Hanya admin yang bisa kirim pesan'}`);
    } catch (err) {
        console.error('Grup Error:', err);
        m.reply("❌ Gagal mengubah setting grup!");
    }
}
break;        
  
case "closegcauto":
case "autogc": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin!");
    if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin!");
    
    if (!text) return m.reply(`Contoh: ${prefix}closegcauto 00:00 | 06:00\n\nFormat: Jam Tutup | Jam Buka`);
    
    const [closeTime, openTime] = text.split('|').map(t => t.trim());
    
    if (!closeTime || !openTime) {
        return m.reply(`❌ Format salah!\nContoh: ${prefix}closegcauto 00:00 | 06:00`);
    }
    
    // Validasi format waktu
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
    if (!timeRegex.test(closeTime) || !timeRegex.test(openTime)) {
        return m.reply("❌ Format waktu salah! Gunakan format HH:MM (24 jam)");
    }
    
    if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
    groupSettings[m.chat].autoClose = closeTime;
    groupSettings[m.chat].autoOpen = openTime;
    
    fs.writeFileSync('./Database/GroupSettings.json', JSON.stringify(groupSettings, null, 2));
    
    m.reply(`✅ Auto Close/Open berhasil diatur!\n\n🔒 Tutup: ${closeTime}\n🔓 Buka: ${openTime}\n\n⏰ Bot akan otomatis tutup/buka grup sesuai jadwal!`);
}
break;        
        
case "ceklontong":
case "caklontong": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/caklontong');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].ceklontong = {
            soal: gameData.soal,
            jawaban: gameData.jawaban.toLowerCase(),
            deskripsi: gameData.deskripsi,
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🤔 *GAME CAK LONTONG*\n\n` +
                 `📝 *Soal:* ${gameData.soal}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan jawaban\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Reply dengan jawaban!`
        }, { quoted: m });
        
        games[m.chat].ceklontong.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.ceklontong && !games[m.chat].ceklontong.answered) {
                const jawaban = games[m.chat].ceklontong.jawaban;
                const deskripsi = games[m.chat].ceklontong.deskripsi;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban.toUpperCase()}*\n` +
                         `Penjelasan: ${deskripsi}\n\n` +
                         `Ketik *.ceklontong* untuk main lagi!`
                });
                
                delete games[m.chat].ceklontong;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Ceklontong Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "bannedgc": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    if (!m.isGroup) {
        return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    let bannedGroups = JSON.parse(fs.readFileSync('./Database/BannedGroups.json', 'utf-8') || '[]');
    
    if (bannedGroups.includes(m.chat)) {
        return m.reply("❌ Grup ini sudah di banned!");
    }
    
    bannedGroups.push(m.chat);
    
    fs.writeFileSync('./Database/BannedGroups.json', JSON.stringify(bannedGroups, null, 2));
    
    m.reply(`✅ Grup ini berhasil di banned!\n\nMember tidak dapat menggunakan bot di grup ini.`);
}
break

case "unbangc":
case "unbannedgc": {
    if (!isOwner) return m.reply("❌ Owner only!");
    
    if (!m.isGroup) {
        return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    let bannedGroups = JSON.parse(fs.readFileSync('./Database/BannedGroups.json', 'utf-8') || '[]');
    
    if (!bannedGroups.includes(m.chat)) {
        return m.reply("❌ Grup ini belum di banned!");
    }
    
    bannedGroups = bannedGroups.filter(group => group !== m.chat);
    
    fs.writeFileSync('./Database/BannedGroups.json', JSON.stringify(bannedGroups, null, 2));
    
    m.reply(`✅ Grup ini berhasil di unbanned!\n\nMember dapat menggunakan bot kembali.`);
}
break        
        
case "family100": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/family100');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        const jawabanList = gameData.jawaban.map(j => j.toLowerCase());
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].family100 = {
            soal: gameData.soal,
            jawaban: jawabanList,
            answered: [],
            startedBy: m.sender,
            startTime: Date.now(),
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `👨‍👩‍👧‍👦 *GAME FAMILY 100*\n\n` +
                 `📝 *Soal:* ${gameData.soal}\n\n` +
                 `🎯 *Tebak 4 jawaban yang benar!*\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan jawaban\n` +
                 `• Setiap jawaban benar: +1 Energy\n` +
                 `• Waktu: 60 detik\n\n` +
                 `⏰ Tebak jawabannya!`
        }, { quoted: m });
        
        games[m.chat].family100.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.family100) {
                const jawaban = games[m.chat].family100.jawaban;
                const answered = games[m.chat].family100.answered;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban yang benar:\n` +
                         `${jawaban.map(j => `• ${j.toUpperCase()}`).join('\n')}\n\n` +
                         `✅ Ditemukan: ${answered.length}/4\n` +
                         `Ketik *.family100* untuk main lagi!`
                });
                
                delete games[m.chat].family100;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 60000);
        
    } catch (error) {
        console.error('Family100 Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "promote": {
  if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner!")
  if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin dulu!")

  // ambil target: reply atau mention
  let target = m.quoted?.sender || m.mentionedJid?.[0]
  if (!target) return m.reply("❌ Reply user / tag user yang mau dipromote!")

  await sock.groupParticipantsUpdate(m.chat, [target], "promote")

  await sock.sendMessage(m.chat, {
    text: `✅ Berhasil promote @${target.split("@")[0]} jadi admin!`,
    mentions: [target]
  }, { quoted: m })
}
break

case "demote": {
  if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner!")
  if (!isBotAdmin) return m.reply("❌ Bot harus jadi admin dulu!")

  // ambil target: reply atau mention
  let target = m.quoted?.sender || m.mentionedJid?.[0]
  if (!target) return m.reply("❌ Reply user / tag user yang mau didemote!")

  await sock.groupParticipantsUpdate(m.chat, [target], "demote")

  await sock.sendMessage(m.chat, {
    text: `✅ Berhasil demote @${target.split("@")[0]} jadi member!`,
    mentions: [target]
  }, { quoted: m })
}
break        
 
 case "blurface": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .blurface")

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/iloveimg/blurface?image=${encodeURIComponent(imgUrl)}`
    const outBuf = await uguu.apiToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ Blur Face selesai!")
  } catch (e) {
    m.reply("❌ Gagal proses blurface.")
  }
}
break      
 
case "compres": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .compres")

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/iloveimg/compress?image=${encodeURIComponent(imgUrl)}`
    const outBuf = await uguu.apiToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ Compress selesai!")
  } catch (e) {
    m.reply("❌ Gagal proses compress.")
  }
}
break        
        
case "image2jpg": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .image2jpg")

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/iloveimg/image2jpg?image=${encodeURIComponent(imgUrl)}`
    const outBuf = await uguu.apiToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ Convert ke JPG selesai!")
  } catch (e) {
    m.reply("❌ Gagal convert JPG.")
  }
}
break        
 
case "image2png": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .image2png")

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/iloveimg/image2png?image=${encodeURIComponent(imgUrl)}`
    const outBuf = await uguu.apiToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ Convert ke PNG selesai!")
  } catch (e) {
    m.reply("❌ Gagal convert PNG.")
  }
}
break        

case "upscale": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .upscale 2 / .upscale 4")

  let scale = parseInt((text || "2").trim())
  if (![2, 4].includes(scale)) scale = 2

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/iloveimg/upscale?image=${encodeURIComponent(imgUrl)}&scale=${scale}`
    const outBuf = await uguu.apiToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, `✅ Upscale x${scale} selesai!`)
  } catch (e) {
    m.reply("❌ Gagal upscale.")
  }
}
break        
 
case "convphoto": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto:\n.convphoto sketch_v2|manga_sketch")

  let template = "sketch_v2"
  let style = "manga_sketch"
  if (text && text.includes("|")) {
    const [a, b] = text.split("|").map(v => (v || "").trim())
    if (a) template = a
    if (b) style = b
  }

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://api.siputzx.my.id/api/imgedit/convphoto?image=${encodeURIComponent(imgUrl)}&template=${encodeURIComponent(template)}&style=${encodeURIComponent(style)}`

    // bisa image langsung, bisa JSON
    let outBuf = await uguu.apiToBuffer(api)
    const js = uguu.tryParseJsonBuffer(outBuf)
    if (js) {
      const outUrl = js.data || js.result || js.url
      if (!outUrl) return m.reply("❌ Gagal convphoto (output kosong).")
      outBuf = await uguu.getBuffer(outUrl)
    }

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, `✅ Convphoto ${template}/${style} selesai!`)
  } catch (e) {
    m.reply("❌ Gagal convphoto.")
  }
}
break        
 
 case "faceswap": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  const q2 = m.quoted
  if (!q2 || !/image/.test(q2.mtype))
    return m.reply("❌ Reply Foto 2.\n(Foto 2 harus reply Foto 1 dulu)")

  const q1 = q2.quoted
  if (!q1 || !/image/.test(q1.mtype))
    return m.reply("❌ Foto 2 harus reply ke Foto 1.\nLalu kamu reply Foto 2 dengan .faceswap")

  try {
    const url1 = await uguu.uploadFromMessage(q1)
    const url2 = await uguu.uploadFromMessage(q2)

    const api = `https://api.siputzx.my.id/api/imgedit/faceswap?image1=${encodeURIComponent(url1)}&image2=${encodeURIComponent(url2)}`
    const outBuf = await uguu.apiJsonToBuffer(api)

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ Faceswap selesai!")
  } catch (e) {
    m.reply("❌ Gagal faceswap.")
  }
}
break      
  
case "removebg": {
  if (!isPremium) {
    if (!energy[m.sender]) energy[m.sender] = 0
    if (energy[m.sender] < 1) return m.reply("⚠️ Energy tidak cukup!")
  }

  if (!m.quoted || !/image/.test(m.quoted.mtype))
    return m.reply("❌ Reply foto dengan perintah: .removebg")

  try {
    const imgUrl = await uguu.uploadFromMessage(m.quoted)
    const api = `https://apiz.rafzsoffc.cloud/imagecreator/removebg?apikey=zlynzeeapi&url=${encodeURIComponent(imgUrl)}`

    // bisa file langsung / bisa json (kita handle)
    let outBuf = await uguu.apiToBuffer(api)
    const js = uguu.tryParseJsonBuffer(outBuf)
    if (js) {
      const outUrl = js.data || js.result || js.url
      if (!outUrl) return m.reply("❌ Gagal removebg (output kosong).")
      outBuf = await uguu.getBuffer(outUrl)
    }

    if (!isPremium) {
      energy[m.sender] -= 1
      fs.writeFileSync("./Database/Energy.json", JSON.stringify(energy, null, 2))
    }

    await uguu.sendImage(sock, m.chat, outBuf, m, "✅ RemoveBG selesai!")
  } catch (e) {
    m.reply("❌ Gagal removebg.")
  }
}
break        
        
case "tebakibukota":
case "ibukota": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/ibukota');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].ibukota = {
            soal: gameData.soal,
            jawaban: gameData.jawaban.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🏛️ *GAME TEBAK IBU KOTA*\n\n` +
                 `📝 *Soal:* ${gameData.soal}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan jawaban\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Reply dengan jawaban!`
        }, { quoted: m });
        
        games[m.chat].ibukota.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.ibukota && !games[m.chat].ibukota.answered) {
                const jawaban = games[m.chat].ibukota.jawaban;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban.toUpperCase()}*\n\n` +
                         `Ketik *.tebakibukota* untuk main lagi!`
                });
                
                delete games[m.chat].ibukota;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Ibukota Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "quiz":
case "kuis": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/kuis');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].quiz = {
            soal: gameData.question,
            pilihan: gameData.choices,
            jawaban: gameData.correctAnswer,
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const pilihanText = Object.entries(gameData.choices)
            .map(([key, value]) => `${key}. ${value}`)
            .join('\n');
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🧠 *GAME QUIZ*\n\n` +
                 `📝 *Soal:* ${gameData.question}\n\n` +
                 `📋 *Pilihan:*\n${pilihanText}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan huruf (A/B/C)\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Pilih A, B, atau C!`
        }, { quoted: m });
        
        games[m.chat].quiz.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.quiz && !games[m.chat].quiz.answered) {
                const jawaban = games[m.chat].quiz.jawaban;
                const benar = gameData.choices[jawaban];
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban}. ${benar}*\n\n` +
                         `Ketik *.quiz* untuk main lagi!`
                });
                
                delete games[m.chat].quiz;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Quiz Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "cekdns": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.cekdns www.vreden.my.id")

  const api = `https://api.vreden.my.id/api/v1/tools/checkdns?domain=${encodeURIComponent(text.trim())}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal cek DNS.")

  const list = (data.result || []).slice(0, 10).map((x, i) => {
    const s = x.server || {}
    const d = x.dns_check || {}
    return `#${i+1} ${s.country || "-"} (${s.city || "-"})
IPv4: ${(d.ipv4 || []).join(", ") || "-"}
IPv6: ${(d.ipv6 || []).join(", ") || "-"}
TTL: ${d.ttl || "-"} | ${d.result || "-"}`
  }).join("\n\n")

  const out = `🧩 *CEK DNS*
Domain: ${text.trim()}

${list || "Tidak ada hasil."}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "cekhost": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.cekhost https://www.vreden.my.id")

  const api = `https://api.vreden.my.id/api/v1/tools/checkhost?domain=${encodeURIComponent(text.trim())}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal cek host.")

  const rid = data.result?.request_id || "-"
  const checks = data.result?.checks || []

  const list = checks.slice(0, 10).map((x, i) => {
    const s = x.server || {}
    const h = x.http_check || {}
    return `#${i+1} ${s.country || "-"} (${s.city || "-"})
Ping: ${h.ping || "-"}s | Code: ${h.status_code || "-"}
IP: ${h.ip_web || "-"} | ${h.result || "-"}`
  }).join("\n\n")

  const out = `🌐 *CEK HOST*
Target: ${text.trim()}
Request ID: ${rid}

${list || "Tidak ada hasil."}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "fakemail": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")

  const api = `https://api.vreden.my.id/api/v1/tools/fakemail/create`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal membuat fakemail.")

  const id = data.result?.id || "-"
  const exp = data.result?.expiresAt || "-"
  const addr = data.result?.addresses?.[0]?.address || "-"

  const out = `📩 *FAKEMAIL CREATED*
Address: ${addr}
ID: ${id}
Expires: ${exp}

Cek inbox:
.cekinboxmail ${id}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "cekinboxmail": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.cekinboxmail <id>")

  const api = `https://api.vreden.my.id/api/v1/tools/fakemail/inbox?id=${encodeURIComponent(text.trim())}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal cek inbox.")

  const addr = data.result?.addresses?.[0]?.address || "-"
  const mails = data.result?.mails || []

  const list = mails.length
    ? mails.slice(0, 10).map((x, i) => `#${i+1}
From: ${x.from || "-"}
Subject: ${x.subject || "-"}
Date: ${x.date || "-"}`).join("\n\n")
    : "📭 Inbox kosong."

  const out = `📬 *INBOX FAKEMAIL*
Address: ${addr}
Total: ${mails.length}

${list}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "mapskordinator": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.mapskordinator Semarang")

  const api = `https://api.vreden.my.id/api/v1/tools/maps/koordinator?location=${encodeURIComponent(text.trim())}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal ambil koordinat.")

  const r = data.result || {}
  const out = `🗺️ *MAPS KOORDINATOR*
Query: ${text.trim()}

Lat: ${r.lat}
Lon: ${r.lon}
Negara: ${r.negara} (${r.kode_negara})
Alamat: ${r.alamat}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "proxy": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.proxy https://ipwho.is/?lang=id-ID&region=fr")

  const api = `https://api.vreden.my.id/api/v1/tools/proxy?url=${encodeURIComponent(text.trim())}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal proxy request.")

  const s = data.result?.server || {}
  const c = data.result?.content || {}
  const out = `🛰️ *PROXY RESULT*
HTTP: ${data.result?.http_code || "-"}

Server:
• ${s.country || "-"} (${s.city || "-"})
• ISP: ${s.connection?.isp || "-"}
• ASN: ${s.connection?.asn || "-"}

Content:
• IP: ${c.ip || "-"}
• Country: ${c.country || "-"} (${c.country_code || "-"})
• Region: ${c.region || "-"}
• Timezone: ${c.timezone?.id || "-"} (${c.timezone?.utc || "-"})`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "ssurl": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.ssurl https://www.vreden.my.id|phone")

  const [u, t] = text.split("|").map(v => (v || "").trim())
  const type = (t || "phone").toLowerCase()
  if (!u) return m.reply("Contoh:\n.ssurl https://www.vreden.my.id|phone")

  const api = `https://api.vreden.my.id/api/v1/tools/screenshot?url=${encodeURIComponent(u)}&type=${encodeURIComponent(type)}`
  const img = await axios.get(api, { responseType: "arraybuffer" }).catch(() => null)
  if (!img?.data) return m.reply("❌ Gagal screenshot.")

  await sock.sendMessage(m.chat, {
    image: Buffer.from(img.data),
    caption: `📸 *SCREENSHOT URL*\nType: ${type}\nURL: ${u}`,
    contextInfo: { mentionedJid: [m.sender] }
  }, { quoted: m })
}
break

case "shortlink": {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
  if (!text) return m.reply("Contoh:\n.shortlink https://www.vreden.my.id|vurl")

  const [u, t] = text.split("|").map(v => (v || "").trim())
  const type = (t || "vurl").toLowerCase()
  if (!u) return m.reply("Contoh:\n.shortlink https://www.vreden.my.id|vurl")

  const api = `https://api.vreden.my.id/api/v1/tools/shortlink?url=${encodeURIComponent(u)}&type=${encodeURIComponent(type)}`
  const { data } = await axios.get(api).catch(() => ({ data: null }))
  if (!data?.status) return m.reply("❌ Gagal membuat shortlink.")

  const out = `🔗 *SHORTLINK*
Type: ${type}
Result: ${data.result}`

  await sock.sendMessage(m.chat, { text: out, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m })
}
break

case "onlygc": {
  if (!isOwner) return m.reply("❌ Khusus Owner")

  const arg = (text || "").toLowerCase()
  if (!["on", "off"].includes(arg))
    return m.reply("Format:\n.onlygc on\n.onlygc off")

  global.db.settings.onlygc = arg === "on"
  m.reply(`✅ Only Group Chat ${arg === "on" ? "AKTIF" : "NONAKTIF"}`)
}
break

case "lengkapikalimat": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/lengkapikalimat');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].lengkapi = {
            soal: gameData.soal,
            jawaban: gameData.jawaban.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `📝 *GAME LENGKAPI KALIMAT*\n\n` +
                 `📝 *Soal:* ${gameData.soal}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan kelanjutan kalimat\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Lengkapi kalimatnya!`
        }, { quoted: m });
        
        games[m.chat].lengkapi.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.lengkapi && !games[m.chat].lengkapi.answered) {
                const jawaban = games[m.chat].lengkapi.jawaban;
                const soal = games[m.chat].lengkapi.soal;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Kalimat lengkap:\n` +
                         `*${soal} ${jawaban.toUpperCase()}*\n\n` +
                         `Ketik *.lengkapikalimat* untuk main lagi!`
                });
                
                delete games[m.chat].lengkapi;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Lengkapi Error:', error);
        m.reply("❌ Error!");
    }
}
break

case 'ceknik':
case 'nik':
case 'ktp': {
  if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus Premium User!")
    if (!text) {
        return reply(`❌ Penggunaan: .ceknik <nomor_nik>\n\nContoh: .ceknik 3202285909840005\n\nNIK harus 16 digit angka!`);
    }
    
    try {
        await sock.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });
        
        const nik = text.trim();
        
        if (!/^\d{16}$/.test(nik)) {
            return reply('❌ NIK harus 16 digit angka!\nContoh: .ceknik 3202285909840005');
        }
        
        const url = `https://api.siputzx.my.id/api/tools/nik-checker?nik=${nik}`;
        
        const response = await axios.get(url);
        
        if (!response.data.status) {
            return reply('❌ NIK tidak valid atau tidak ditemukan!');
        }
        
        const data = response.data.data.data;
        const metadata = response.data.data.metadata;
        
        let nikText = `🆔 *DATA KTP DITEMUKAN*\n\n`;
        nikText += `🔢 *NIK:* ${response.data.data.nik}\n`;
        nikText += `📊 *Status:* ${response.data.data.status.toUpperCase()}\n`;
        nikText += `══════════════════\n\n`;
        
        nikText += `📛 *Nama:* ${data.nama}\n`;
        nikText += `⚥ *Jenis Kelamin:* ${data.kelamin}\n`;
        nikText += `🎂 *Tempat/Tgl Lahir:* ${data.tempat_lahir}\n`;
        nikText += `📅 *Usia:* ${data.usia}\n`;
        nikText += `🌟 *Zodiak:* ${data.zodiak}\n`;
        nikText += `📅 *Pasaran:* ${data.pasaran}\n`;
        nikText += `🎉 *Ultah Mendatang:* ${data.ultah_mendatang}\n\n`;
        
        nikText += `📍 *Alamat:*\n`;
        nikText += `🏛️ Provinsi: ${data.provinsi}\n`;
        nikText += `🏙️ Kabupaten: ${data.kabupaten}\n`;
        nikText += `🏘️ Kecamatan: ${data.kecamatan}\n`;
        nikText += `🏠 Kelurahan: ${data.kelurahan}\n`;
        nikText += `🗳️ TPS: ${data.tps}\n`;
        nikText += `🏠 Alamat Lengkap: ${data.alamat}\n\n`;
        
        if (data.koordinat.lat && data.koordinat.lon) {
            nikText += `🗺️ *Koordinat:*\n`;
            nikText += `Lat: ${data.koordinat.lat}\n`;
            nikText += `Lon: ${data.koordinat.lon}\n\n`;
        }
        
        nikText += `📋 *Metadata:*\n`;
        nikText += `🔍 Metode: ${metadata.metode_pencarian}\n`;
        nikText += `📍 Kode Wilayah: ${metadata.kode_wilayah}\n`;
        nikText += `🔢 Nomor Urut: ${metadata.nomor_urut}\n`;
        nikText += `👤 Kategori Usia: ${metadata.kategori_usia}\n`;
        nikText += `🏛️ Jenis Wilayah: ${metadata.jenis_wilayah}\n`;
        nikText += `⏰ Timestamp: ${new Date(metadata.timestamp).toLocaleString('id-ID')}\n\n`;
        
        nikText += `ℹ️ *Catatan:* Data berdasarkan NIK KTP Elektronik`;
        
        await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        await m.reply(nikText);
        
    } catch (error) {
        console.error('CekNIK error:', error.message);
        
        if (error.response?.status === 404) {
            await m.reply('❌ NIK tidak ditemukan atau API tidak merespon!');
        } else {
            await m.reply(`❌ Gagal mengecek NIK: ${error.message}`);
        }
    }
}
break;

case "math":
case "matematika": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/math');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].math = {
            soal: gameData.question,
            pilihan: gameData.choices,
            jawaban: gameData.correctAnswer,
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const pilihanText = Object.entries(gameData.choices)
            .map(([key, value]) => `${key}. ${value}`)
            .join('\n');
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🧮 *GAME MATEMATIKA*\n\n` +
                 `📝 *Soal:* ${gameData.question}\n\n` +
                 `📋 *Pilihan:*\n${pilihanText}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan huruf (A/B/C)\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Hitung dengan benar!`
        }, { quoted: m });
        
        games[m.chat].math.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.math && !games[m.chat].math.answered) {
                const jawaban = games[m.chat].math.jawaban;
                const benar = gameData.choices[jawaban];
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban}. ${benar}*\n\n` +
                         `Ketik *.math* untuk main lagi!`
                });
                
                delete games[m.chat].math;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Math Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "tebakbendera":
case "bendera": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/tebak/bendera');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].bendera = {
            bendera: gameData.flag,
            gambar: gameData.img,
            jawaban: gameData.name.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            image: { url: gameData.img },
            caption: `🇺🇳 *GAME TEBAK BENDERA*\n\n` +
                    `⚡ *Rules:*\n` +
                    `• Reply pesan ini dengan nama negara\n` +
                    `• Pemenang dapat +1 Energy\n` +
                    `• Waktu: 30 detik\n\n` +
                    `⏰ Bendera negara apa ini?`
        }, { quoted: m });
        
        games[m.chat].bendera.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.bendera && !games[m.chat].bendera.answered) {
                const jawaban = games[m.chat].bendera.jawaban;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban.toUpperCase()}*\n` +
                         `Kode bendera: ${gameData.flag}\n\n` +
                         `Ketik *.tebakbendera* untuk main lagi!`
                });
                
                delete games[m.chat].bendera;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Bendera Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "welcome": {
  if (!m.isGroup) return m.reply("❌ Khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner grup!")

  const arg = (text || "").toLowerCase().trim()
  if (!["on", "off"].includes(arg)) return m.reply("Format:\n.welcome on\n.welcome off")

  const db = JSON.parse(fs.readFileSync("./Database/set-database.json"))
  db.group ??= {}
  db.group[m.chat] ??= {}
  db.group[m.chat].welcome ??= { enabled: false, text: "@user 👋 Selamat datang di @group!" }

  db.group[m.chat].welcome.enabled = arg === "on"
  fs.writeFileSync("./Database/set-database.json", JSON.stringify(db, null, 2))

  m.reply(`✅ Welcome ${db.group[m.chat].welcome.enabled ? "ON" : "OFF"}`)
}
break

case "setwelcome": {
  if (!m.isGroup) return m.reply("❌ Khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner grup!")
  if (!text) return m.reply("Format:\n.setwelcome <teks>\nTag: @user/@tagnama, @group, @count")

  const db = JSON.parse(fs.readFileSync("./Database/set-database.json"))
  db.group ??= {}
  db.group[m.chat] ??= {}
  db.group[m.chat].welcome ??= { enabled: false, text: "@user 👋 Selamat datang di @group!" }

  db.group[m.chat].welcome.text = text
  fs.writeFileSync("./Database/set-database.json", JSON.stringify(db, null, 2))

  m.reply("✅ Set welcome tersimpan.")
}
break

case "goodbye": {
  if (!m.isGroup) return m.reply("❌ Khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner grup!")

  const arg = (text || "").toLowerCase().trim()
  if (!["on", "off"].includes(arg)) return m.reply("Format:\n.goodbye on\n.goodbye off")

  const db = JSON.parse(fs.readFileSync("./Database/set-database.json"))
  db.group ??= {}
  db.group[m.chat] ??= {}
  db.group[m.chat].goodbye ??= { enabled: false, text: "@user 👋 Si Anjing Udah Pergi Wok Wkkwk" }

  db.group[m.chat].goodbye.enabled = arg === "on"
  fs.writeFileSync("./Database/set-database.json", JSON.stringify(db, null, 2))

  m.reply(`✅ Goodbye ${db.group[m.chat].goodbye.enabled ? "ON" : "OFF"}`)
}
break

case "setgoodbye": {
  if (!m.isGroup) return m.reply("❌ Khusus grup!")
  if (!isAdmin && !isOwner) return m.reply("❌ Khusus admin/owner grup!")
  if (!text) return m.reply("Format:\n.setgoodbye <teks>\nTag: @user/@tagnama, @group, @count")

  const db = JSON.parse(fs.readFileSync("./Database/set-database.json"))
  db.group ??= {}
  db.group[m.chat] ??= {}
  db.group[m.chat].goodbye ??= { enabled: false, text: "@user 👋 Sampai jumpa!" }

  db.group[m.chat].goodbye.text = text
  fs.writeFileSync("./Database/set-database.json", JSON.stringify(db, null, 2))

  m.reply("✅ Set goodbye tersimpan.")
}
break

case "tebakgambar": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/tebak/gambar');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].gambar = {
            gambar: gameData.img,
            jawaban: gameData.jawaban.toLowerCase(),
            deskripsi: gameData.deskripsi,
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            image: { url: gameData.img },
            caption: `🖼️ *GAME TEBAK GAMBAR*\n\n` +
                    `⚡ *Rules:*\n` +
                    `• Reply pesan ini dengan jawaban\n` +
                    `• Pemenang dapat +1 Energy\n` +
                    `• Waktu: 45 detik\n\n` +
                    `⏰ Apa maksud gambar ini?`
        }, { quoted: m });
        
        games[m.chat].gambar.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.gambar && !games[m.chat].gambar.answered) {
                const jawaban = games[m.chat].gambar.jawaban;
                const deskripsi = games[m.chat].gambar.deskripsi;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban.toUpperCase()}*\n\n` +
                         `Penjelasan:\n${deskripsi}\n\n` +
                         `Ketik *.tebakgambar* untuk main lagi!`
                });
                
                delete games[m.chat].gambar;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 45000);
        
    } catch (error) {
        console.error('Gambar Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "tebaklirik":
case "lirik": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/tebak/lirik');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].lirik = {
            soal: gameData.soal,
            jawaban: gameData.jawaban.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🎵 *GAME TEBAK LIRIK*\n\n` +
                 `📝 *Lirik:* ${gameData.soal}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan kelanjutan lirik\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Lanjutkan liriknya!`
        }, { quoted: m });
        
        games[m.chat].lirik.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.lirik && !games[m.chat].lirik.answered) {
                const jawaban = games[m.chat].lirik.jawaban;
                const soal = games[m.chat].lirik.soal;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Lirik lengkap:\n` +
                         `*${soal} ${jawaban}*\n\n` +
                         `Ketik *.tebaklirik* untuk main lagi!`
                });
                
                delete games[m.chat].lirik;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('Lirik Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "groupmenu":
case "grupmenu": {
    if (!m.isGroup) return m.reply("❌ Fitur ini khusus grup!")

    const hour = new Date().getHours()
    let ucapan
    if (hour < 10) ucapan = "pagi 🌅"
    else if (hour < 15) ucapan = "siang ☀️"
    else if (hour < 18) ucapan = "sore 🌇"
    else ucapan = "malam 🌙"

    const teks = `Selamat ${ucapan} @${m.sender.split("@")[0]}

乂  *MENU GROUP*
┏━━━━━━━━━━⟢
┃ .promote Ⓐ
┃ .demote Ⓐ
┃ .grup open/close Ⓐ
┃ .antilink1 on/off Ⓐ
┃ .antilink2 on/off Ⓐ
┃ .antibot on/off Ⓐ
┃ .antivirtex on/off Ⓐ
┃ .antidelete on/off Ⓐ
┃ .closegcauto time|time Ⓐ
┃ .welcome on/off Ⓐ
┃ .setwelcome <teks> Ⓐ
┃ .goodbye on/off Ⓐ
┃ .setgoodbye <teks> Ⓐ
┗━━━━━━━━━━━━⟢

╭━━━━━━━━━━━━━━━━━━━╮
│ Ⓐ = Admin  Ⓞ = Owner
╰━━━━━━━━━━━━━━━━━━━╯`

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia(
                            { image: { url: global.thumb } },
                            { upload: sock.waUploadToServer }
                        ))
                    },
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "quick_reply", buttonParamsJson: `{"display_text":"📱 Menu Utama","id":"${prefix}menu"}` },
                            { name: "cta_url", buttonParamsJson: `{"display_text":"📢 Join Channel","url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A","merchant_url":"https://whatsapp.com/channel/0029VagRpl20gqRTmJVEGH0A"}` }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "120363420619530273@newsletter",
                            serverMessageId: 1,
                            newsletterName: "Click Saluran"
                        }
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break
        
case "tebaklagu":
case "lagu": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/tebak/lagu');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].lagu = {
            lagu: gameData.lagu,
            jawaban: gameData.judul.toLowerCase(),
            artis: gameData.artis.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            audio: { url: gameData.lagu },
            mimetype: 'audio/mp4',
            ptt: true,
            caption: `🎶 *GAME TEBAK LAGU*\n\n` +
                    `⚡ *Rules:*\n` +
                    `• Reply pesan ini dengan judul lagu\n` +
                    `• Pemenang dapat +1 Energy\n` +
                    `• Waktu: 45 detik\n\n` +
                    `⏰ Judul lagu apa ini?`
        }, { quoted: m });
        
        games[m.chat].lagu.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.lagu && !games[m.chat].lagu.answered) {
                const jawaban = games[m.chat].lagu.jawaban;
                const artis = games[m.chat].lagu.artis;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Judul: *${jawaban.toUpperCase()}*\n` +
                         `Artis: *${artis.toUpperCase()}*\n\n` +
                         `Ketik *.tebaklagu* untuk main lagi!`
                });
                
                delete games[m.chat].lagu;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 45000);
        
    } catch (error) {
        console.error('Lagu Error:', error);
        m.reply("❌ Error!");
    }
}
break

case "asahotak":
case "tebak": {
    if (!m.isGroup) return m.reply("❌ Game hanya bisa di grup!");
    
    try {
        const response = await fetch('https://api.vreden.my.id/api/v1/game/asahotak');
        const data = await response.json();
        
        if (!data.status) return m.reply("❌ Gagal ambil soal!");
        
        const gameData = data.result;
        
        if (!games[m.chat]) games[m.chat] = {};
        
        games[m.chat].asahotak = {
            soal: gameData.soal,
            jawaban: gameData.jawaban.toLowerCase(),
            startedBy: m.sender,
            startTime: Date.now(),
            answered: false,
            gameMessageId: null
        };
        
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        const gameMsg = await sock.sendMessage(m.chat, {
            text: `🧠 *GAME ASAH OTAK*\n\n` +
                 `📝 *Soal:* ${gameData.soal}\n\n` +
                 `⚡ *Rules:*\n` +
                 `• Reply pesan ini dengan jawaban\n` +
                 `• Pemenang dapat +1 Energy\n` +
                 `• Waktu: 30 detik\n\n` +
                 `⏰ Reply dengan jawaban!`
        }, { quoted: m });
        
        games[m.chat].asahotak.gameMessageId = gameMsg.key.id;
        fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
        
        setTimeout(async () => {
            if (games[m.chat]?.asahotak && !games[m.chat].asahotak.answered) {
                const jawaban = games[m.chat].asahotak.jawaban;
                
                await sock.sendMessage(m.chat, {
                    text: `⏰ *WAKTU HABIS!*\n\n` +
                         `Jawaban: *${jawaban.toUpperCase()}*\n` +
                         `Tidak ada yang benar 😢\n\n` +
                         `Ketik *.asahotak* untuk main lagi!`
                });
                
                delete games[m.chat].asahotak;
                fs.writeFileSync('./Database/Games.json', JSON.stringify(games, null, 2));
            }
        }, 30000);
        
    } catch (error) {
        console.error('AsahOtak Error:', error);
        m.reply("❌ Error!");
    }
}
break      
        
case "artinama": {
  if (!text) return m.reply("📛 Contoh:\n.artinama izo")

  const res = await primbon.artiNama(text)

  m.reply(`📛 *ARTI NAMA PRIMBON*

Nama yang dianalisis:
➤ ${text}

━━━━━━━━━━━━━━━
🧠 *Makna & Karakter*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Catatan*
━━━━━━━━━━━━━━━
Arti nama dipercaya memengaruhi
kepribadian, cara berpikir,
serta pembawaan diri seseorang.

Hasil ini bersifat kepercayaan,
bukan kepastian mutlak.`)
}
break

case "mimpi": {
  if (!text) return m.reply("🌙 Contoh:\n.mimpi hantu")

  const res = await primbon.tafsirMimpi(text)

  m.reply(`🌙 *TAFSIR MIMPI*

Mimpi yang dialami:
➤ ${text}

━━━━━━━━━━━━━━━
🔮 *Makna Mimpi*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Pesan*
━━━━━━━━━━━━━━━
Tafsir mimpi merupakan simbol
dan perlambang menurut primbon Jawa.

Gunakan sebagai bahan renungan.`)
}
break
 
case "jodoh": {
  const [a, b] = text.split("|")
  if (!a || !b) return m.reply("💞 Contoh:\n.jodoh acil|manda")

  const res = await primbon.Jodoh(a.trim(), b.trim())

  m.reply(`💞 *KECOCOKAN NAMA PASANGAN*

Pasangan yang dianalisis:
👤 ${a}
👤 ${b}

━━━━━━━━━━━━━━━
❤️ *Hasil Kecocokan*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Makna*
━━━━━━━━━━━━━━━
Kecocokan ini menggambarkan
potensi hubungan dan keharmonisan.

Hubungan tetap ditentukan oleh
komunikasi dan komitmen.`)
}
break        

case "tanggaljadi": {
  if (!text) return m.reply("❤️ Contoh:\n.tanggaljadi 01-07-2000")

  const res = await primbon.tanggaljadi(text)

  m.reply(`❤️ *RAMALAN TANGGAL JADIAN*

Tanggal yang dianalisis:
📆 ${text}

━━━━━━━━━━━━━━━
💘 *Hasil Ramalan*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Catatan*
━━━━━━━━━━━━━━━
Tanggal jadian dipercaya
mempengaruhi dinamika hubungan
dan keharmonisan pasangan.`)
}
break

case "watakartis": {
  const [nama, tgl] = text.split("|")
  if (!nama || !tgl)
    return m.reply("🎭 Contoh:\n.watakartis Michelle Ziudith|20-1-1995")

  const res = await primbon.watakartis(nama.trim(), tgl.trim())

  m.reply(`🎭 *WATAK & KARAKTER ARTIS*

Nama:
➤ ${nama}
Tanggal lahir:
📆 ${tgl}

━━━━━━━━━━━━━━━
🧠 *Watak & Karakter*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Catatan*
━━━━━━━━━━━━━━━
Watak dan karakter dihitung
berdasarkan perhitungan primbon Jawa.`)
}
break

case "ramalanjodoh": {
  const [n1, t1, n2, t2] = text.split("|")
  if (!n1 || !t1 || !n2 || !t2)
    return m.reply(
      "💑 Contoh:\n.ramalanjodoh joe|11-4-2003|putri|1-2-2005"
    )

  const res = await primbon.ramalanjodoh(
    n1.trim(), t1.trim(),
    n2.trim(), t2.trim()
  )

  m.reply(`💑 *RAMALAN JODOH LENGKAP*

Pasangan:
👤 ${n1} (${t1})
👤 ${n2} (${t2})

━━━━━━━━━━━━━━━
🔮 *Hasil Ramalan*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Renungan*
━━━━━━━━━━━━━━━
Ramalan jodoh bukan penentu mutlak.
Hubungan akan berjalan baik
dengan usaha dan saling pengertian.`)
}
break

case "rejeki": {
  if (!text) return m.reply("💰 Contoh:\n.rejeki 11-1-2000")

  const res = await primbon.rejekiweton(text)

  m.reply(`💰 *RAMALAN REJEKI (HOKI)*

Tanggal lahir:
📆 ${text}

━━━━━━━━━━━━━━━
💸 *Hasil Ramalan*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Pesan*
━━━━━━━━━━━━━━━
Rejeki tidak hanya berupa uang,
tetapi juga kesempatan,
kesehatan, dan keberuntungan hidup.`)
}
break

case "harib":
case "haribbaik": {
  if (!text) return m.reply("📅 Contoh:\n.harib 1-1-2000")

  const res = await primbon.haribaik(text)

  m.reply(`📅 *HARI BAIK PRIMBON*

Tanggal lahir:
📆 ${text}

━━━━━━━━━━━━━━━
🌟 *Hari Baik*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Kegunaan*
━━━━━━━━━━━━━━━
Biasanya digunakan untuk
pernikahan, usaha,
pindah rumah, dan acara penting.`)
}
break
 
case "harilarangan": {
  if (!text) return m.reply("⛔ Contoh:\n.harilarangan 1-1-2000")

  const res = await primbon.harilarangan(text)

  m.reply(`⛔ *HARI LARANGAN*

Tanggal lahir:
📆 ${text}

━━━━━━━━━━━━━━━
🚫 *Hari yang Perlu Dihindari*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Catatan*
━━━━━━━━━━━━━━━
Hari larangan dipercaya sebagai
hari yang kurang baik untuk
melakukan aktivitas penting.`)
}
break                      
 
case "kecocokannama": {
  const [nama, tgl] = text.split("|")
  if (!nama || !tgl)
    return m.reply("🧠 Contoh:\n.kecocokannama angel|18-5-2005")

  const res = await primbon.kecocokannama(nama.trim(), tgl.trim())

  m.reply(`🧠 *KECOCOKAN NAMA*

Nama:
➤ ${nama}
Tanggal lahir:
📆 ${tgl}

━━━━━━━━━━━━━━━
🔍 *Hasil Analisis*
━━━━━━━━━━━━━━━
${res}

━━━━━━━━━━━━━━━
📌 *Makna*
━━━━━━━━━━━━━━━
Analisis ini menggambarkan
potensi karakter dan kecocokan
nama menurut primbon Jawa.`)
}
break                                                                                                                                                                                                                                                              
case "tiktok": {
if (!text) return m.reply("Masukkan URL TikTok!\n\nContoh: .tiktok https://vt.tiktok.com/ZSxxx");

// Reload energy terbaru
if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

// Cek premium dan energy
if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh video TikTok...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://apiz.rafzsoffc.cloud/download/tiktok-v2?apikey=zlynzeeapi&url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh video TikTok!");
    
    const data = json.result.data;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*TIKTOK DOWNLOADER*

👤 Author: ${data.author.nickname} (@${data.author.unique_id})
📝 Title: ${data.title}

📊 Statistics:
❤️ Likes: ${data.digg_count.toLocaleString()}
💬 Comments: ${data.comment_count.toLocaleString()}
🔄 Shares: ${data.share_count.toLocaleString()}
👁️ Views: ${data.play_count.toLocaleString()}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    // Kirim video dengan button
    await sock.sendMessage(m.chat, {
        video: { url: data.play },
        caption: caption,
        contextInfo: {
            externalAdReply: {
                title: "TIKTOK DOWNLOADER",
                body: data.author.nickname,
                thumbnailUrl: data.cover,
                sourceUrl: text,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
    // Kirim button terpisah
    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "Pilih opsi di bawah ini:" },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{"display_text":"🎵 Download Audio","id":".ttmp3 ${text}"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"📺 Lihat di TikTok","url":"${text}","merchant_url":"${text}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });
    
    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video!");
}
}
break

case "bratvid": {
    if (!text) return m.reply(`*Contoh :* ${cmd} aku cinta kamu`);
    
    // Cek energy untuk non-premium
    if (!isPremium) {
        if (!energy[m.sender]) energy[m.sender] = 0;
        if (energy[m.sender] < 1) {
            return m.reply(`⚠️ Energy tidak cukup!\n⚡ Energy: ${energy[m.sender]}\n💎 Dibutuhkan: 1 Energy\n✨ Upgrade ke Premium untuk unlimited akses!`);
        }
        energy[m.sender] -= 1;
        fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
    }
    
    try {
        const words = text.split(' ');
        const frames = [];
        
        for (let i = 1; i <= words.length; i++) {
            const currentText = words.slice(0, i).join(' ');
            const frameUrl = `https://aqul-brat.hf.space/?text=${encodeURIComponent(currentText)}`;
            frames.push(frameUrl);
        }
        
        for (let i = 0; i < 5; i++) {
            frames.push(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}`);
        }
        
        const frameBuffers = [];
        for (const url of frames) {
            const response = await fetch(url);
            if (response.ok) {
                const buffer = await response.buffer();
                frameBuffers.push(buffer);
            }
        }
        
        if (frameBuffers.length === 0) throw new Error('Tidak ada frame');
        
        const tempDir = `./temp/bratvid_${Date.now()}`;
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        const framePaths = [];
        for (let i = 0; i < frameBuffers.length; i++) {
            const framePath = `${tempDir}/frame_${i.toString().padStart(3, '0')}.png`;
            fs.writeFileSync(framePath, frameBuffers[i]);
            framePaths.push(framePath);
        }
        
        const outputVideo = `${tempDir}/output.mp4`;
        
        await new Promise((resolve, reject) => {
            exec(`ffmpeg -framerate 3 -i "${tempDir}/frame_%03d.png" -c:v libx264 -pix_fmt yuv420p -vf "scale=512:512" "${outputVideo}"`, 
                (error) => {
                    if (error) reject(error);
                    else resolve();
                }
            );
        });
        
        await sock.sendStimg(m.chat, outputVideo, m, { 
            packname: "AsuNet", 
            author: m.pushName || "User"
        });
        
        // Cleanup
        for (const path of framePaths) fs.unlinkSync(path);
        fs.unlinkSync(outputVideo);
        fs.rmdirSync(tempDir);
        
    } catch (err) {
        console.error('Bratvid Error:', err);
        m.reply(`❌ Gagal membuat video sticker`);
        
        // Kembalikan energy jika gagal
        if (!isPremium) {
            energy[m.sender] += 1;
            fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
        }
    }
}
break
                           
case "ttmp3": {
if (!text) return m.reply("Masukkan URL TikTok!\n\nContoh: .ttmp3 https://vt.tiktok.com/ZSxxx");

// Reload energy terbaru
if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

// Cek premium dan energy
if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🎵 Sedang mengunduh audio TikTok...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://apiz.rafzsoffc.cloud/download/tiktok-v2?apikey=zlynzeeapi&url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh audio TikTok!");
    
    const data = json.result.data;
    const newEnergy = energy[m.sender] || 0;
    
    // Kirim audio
    await sock.sendMessage(m.chat, {
        audio: { url: data.music },
        mimetype: 'audio/mpeg',
        ptt: true,
        contextInfo: {
            externalAdReply: {
                title: data.music_info.title,
                body: data.music_info.author,
                thumbnailUrl: data.music_info.cover,
                sourceUrl: text,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
    if (!isPremium) {
        m.reply(`✅ Audio berhasil dikirim!\n\n⚡ Energy: ${currentEnergy} → ${newEnergy}`);
    }
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh audio!");
}
}
break
 


  case "qc":
case "qcstic": {
    if (!args[0]) return m.reply(`Contoh: ${cmd} halo dunia`);
    if (text.length > 80) return m.reply(`Maximal 80 karakter!`);
    
    try {
        const message = text;
        const backgroundColor = '#ffffff';
        const username = m.pushName || "User";
        
        // Dapatkan avatar user
        let avatar;
        try {
            avatar = await sock.profilePictureUrl(m.sender, "image");
        } catch {
            avatar = 'https://files.catbox.moe/nwvkbt.png';
        }
        
        const json = {
            type: 'quote',
            format: 'png',
            backgroundColor,
            width: 512,
            height: 768,
            scale: 2,
            messages: [{
                entities: [],
                avatar: true,
                from: {
                    id: 1,
                    name: username,
                    photo: {
                        url: avatar
                    }
                },
                text: message,
                replyMessage: {}
            }]
        };
        
        const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.data || !response.data.result || !response.data.result.image) {
            throw new Error('Response API tidak valid');
        }
        
        const buffer = Buffer.from(response.data.result.image, 'base64');
        
        // Kirim sebagai sticker dengan packname dan author tetap
        await sock.sendStimg(m.chat, buffer, m, {
            packname: "Zeuz",
            author: "gacor"
        });
        
    } catch (err) {
        console.error('QC Error:', err);
        m.reply(`❌ Gagal membuat quote sticker: ${err.message}`);
    }
}
break      
        
case "bratip": {
    if (!text) return m.reply(`*Contoh :* ${cmd} Hallo Aku Jawa!`);
    
    var media = await getBuffer(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}`);
    
    await sock.sendStimg(m.chat, media, m, {packname: "AfaIYah??"});
}
break        
        
case "capcut": {
if (!text) return m.reply("Masukkan URL CapCut!\n\nContoh: .capcut https://www.capcut.com/tv2/ZSxxx");

// Reload energy terbaru
if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

// Cek premium dan energy
if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh video CapCut...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://apiz.rafzsoffc.cloud/download/capcut?apikey=zlynzeeapi&url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh video CapCut!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*CAPCUT DOWNLOADER*

📝 Title: ${data.title}
👤 Author: ${data.author.name}
📅 Date: ${data.date}

📊 Statistics:
👥 Users: ${data.pengguna}
❤️ Likes: ${data.likes}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    // Kirim video
    await sock.sendMessage(m.chat, {
        video: { url: data.videoUrl },
        caption: caption,
        contextInfo: {
            externalAdReply: {
                title: "CAPCUT DOWNLOADER",
                body: data.author.name,
                thumbnailUrl: data.posterUrl,
                sourceUrl: text,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video CapCut!");
}
}
break        
        
case "claimreward": {
// Set timezone Jakarta
const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const currentTime = now.getTime();

// Inisialisasi claim data jika belum ada
if (!energy[m.sender + '_lastclaim']) energy[m.sender + '_lastclaim'] = 0;
if (!energy[m.sender]) energy[m.sender] = 0;

const lastClaimTime = energy[m.sender + '_lastclaim'];
const timeDiff = currentTime - lastClaimTime;
const cooldown = 24 * 60 * 60 * 1000; // 24 jam dalam milidetik

// Cek apakah sudah lewat 24 jam
if (timeDiff < cooldown) {
    const timeLeft = cooldown - timeDiff;
    const hoursLeft = Math.floor(timeLeft / (60 * 60 * 1000));
    const minutesLeft = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
    const secondsLeft = Math.floor((timeLeft % (60 * 1000)) / 1000);
    
    // Hitung waktu claim berikutnya
    const nextClaim = new Date(lastClaimTime + cooldown);
    const nextClaimStr = nextClaim.toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        dateStyle: 'full',
        timeStyle: 'short'
    });
    
    return m.reply(`⚠️ Kamu sudah claim hari ini!

⏰ Sisa waktu: ${hoursLeft} jam ${minutesLeft} menit ${secondsLeft} detik
📅 Claim berikutnya: ${nextClaimStr}
⚡ Energy saat ini: ${energy[m.sender]}`);
}

// Berikan 45 energy
const oldEnergy = energy[m.sender];
energy[m.sender] += 45;
energy[m.sender + '_lastclaim'] = currentTime;
fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));

// Waktu claim berikutnya
const nextClaim = new Date(currentTime + cooldown);
const nextClaimStr = nextClaim.toLocaleString('id-ID', { 
    timeZone: 'Asia/Jakarta',
    dateStyle: 'full',
    timeStyle: 'short'
});

m.reply(`✅ *CLAIM BERHASIL!*

🎁 Reward: +45 Energy ⚡
💰 Energy: ${oldEnergy} → ${energy[m.sender]}

📅 Claim berikutnya: ${nextClaimStr}
🕐 Waktu sekarang: ${now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'full', timeStyle: 'medium' })}`);
}
break
        
//###############################//

case "payment":
case "pay": {
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                    hasMediaAttachment: true, 
                    ...(await prepareWAMessageMedia({ image: { url: global.qris } }, { upload: sock.waUploadToServer })),
                    }, 
                    body: { 
                        text: `*Daftar Payment ${namaOwner} 🔖*`
                    },
                    footer: { 
                        text: "Klik tombol di bawah untuk menyalin nomor e-wallet" 
                    },
                    nativeFlowMessage: {
                        buttons: [
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Dana","copy_code":"${global.dana}"}`
                            },
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy OVO","copy_code":"${global.ovo}"}`
                            },
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Gopay","copy_code":"${global.gopay}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "deposit": {
const args = text.split(" ");
const amount = parseInt(args[0]);

if (!amount) return m.reply("Masukkan jumlah deposit!\n\nContoh: .deposit 10000\n\nMinimal deposit: Rp 1.000");

if (amount < 1000) return m.reply("❌ Minimal deposit Rp 1.000!");

m.reply("⏳ Sedang membuat deposit...");

try {
    const API_KEY = "2e53df6f22f7fb92ef9665c23d68255d";
    const BASE_URL = "https://obvntepwymuspiyxmeiu.supabase.co/functions/v1";
    
    const response = await fetch(`${BASE_URL}/api-deposit-create`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        },
        body: JSON.stringify({
            amount: amount
        })
    });
    
    const result = await response.json();
    
    if (!result.success) return m.reply("❌ Gagal membuat deposit!");
    
    const deposit = result.deposit;
    const fee = deposit.fee || 340;
    const expiredTime = new Date(deposit.expired_at).toLocaleString('id-ID');
    
    const caption = `*DEPOSIT QRIS*

💰 Jumlah: Rp ${amount.toLocaleString('id-ID')}
💳 Fee: Rp ${fee.toLocaleString('id-ID')}
📊 Total: Rp ${deposit.total_amount.toLocaleString('id-ID')}

🆔 Order ID: ${deposit.order_id}
⏰ Expired: ${expiredTime}

Scan QR Code di atas untuk melakukan pembayaran.`;

    // Generate QR Code dari qr_string menggunakan library QR
    const QRCode = require('qrcode');
    const qrBuffer = await QRCode.toBuffer(deposit.qr_string, {
        width: 500,
        margin: 2
    });
    
    await sock.sendMessage(m.chat, {
        image: qrBuffer,
        caption: caption
    }, { quoted: m });
    
    // Auto check status deposit setiap 5 detik
    m.reply("🔄 Menunggu pembayaran...\n\nBot akan otomatis mengecek status pembayaran Anda.");
    
    let checkCount = 0;
    const maxCheck = 36; // 3 menit (36 x 5 detik)
    
    const checkInterval = setInterval(async () => {
        try {
            const checkResponse = await fetch(`${BASE_URL}/api-deposit-status`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key": API_KEY
                },
                body: JSON.stringify({
                    order_id: deposit.order_id
                })
            });
            
            const checkResult = await checkResponse.json();
            
            if (checkResult.deposit && checkResult.deposit.status === "success") {
                clearInterval(checkInterval);
                
                // Tambahkan saldo ke database uang
                if (!uang[m.sender]) uang[m.sender] = 0;
                uang[m.sender] += amount;
                fs.writeFileSync('./Database/Uang.json', JSON.stringify(uang, null, 2));
                
                m.reply(`✅ *PEMBAYARAN BERHASIL!*

💰 Deposit: Rp ${amount.toLocaleString('id-ID')}
💵 Saldo Anda: $${uang[m.sender]}

Terima kasih! Saldo sudah ditambahkan ke akun Anda.`);
            }
            
            checkCount++;
            if (checkCount >= maxCheck) {
                clearInterval(checkInterval);
                m.reply("⏰ Waktu pembayaran habis!\n\nSilakan buat deposit baru jika ingin melanjutkan.");
            }
        } catch (error) {
            console.log("Error checking deposit:", error);
        }
    }, 5000);
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat membuat deposit!");
}
}
break        
        
case "fb": {
if (!text) return m.reply("Masukkan URL Facebook!\n\nContoh: .fb https://www.facebook.com/share/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh video Facebook...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://www.velyn.mom/api/downloader/facebook?apikey=velynapis&url=${url}`);
    const json = await res.json();
    
    if (json.status !== 200) return m.reply("❌ Gagal mengunduh video Facebook!");
    
    const newEnergy = energy[m.sender] || 0;
    
    await sock.sendMessage(m.chat, {
        video: { url: json.data.downloadUrl },
        caption: `*FACEBOOK DOWNLOADER*\n\n${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`,
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video Facebook!");
}
}
break

// Spotify Downloader
case "spotify": {
if (!text) return m.reply("Masukkan URL Spotify!\n\nContoh: .spotify https://open.spotify.com/track/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🎵 Sedang mengunduh audio Spotify...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://www.velyn.mom/api/downloader/spotify?apikey=velynapis&url=${url}`);
    const json = await res.json();
    
    if (json.status !== 200) return m.reply("❌ Gagal mengunduh audio Spotify!");
    
    const data = json.data;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*SPOTIFY DOWNLOADER*

🎵 Title: ${data.title}
👤 Artist: ${data.artists}
⏱️ Duration: ${Math.floor(data.duration / 1000 / 60)}:${Math.floor((data.duration / 1000) % 60)}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    await sock.sendMessage(m.chat, {
        audio: { url: data.url },
        mimetype: 'audio/mpeg',
        contextInfo: {
            externalAdReply: {
                title: data.title,
                body: data.artists,
                thumbnailUrl: data.thumbnail,
                sourceUrl: text,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh audio Spotify!");
}
}
break

// XNXX Downloader (18+)
case "boxep": {
if (!text) return m.reply("Masukkan URL XNXX!\n\nContoh: .boxep https://www.xnxx.com/video-xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 2) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 2 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 2;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh video...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/xnxx?url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh video!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*VIDEO DOWNLOADER (18+)*

📝 Title: ${data.title}
⏱️ Duration: ${Math.floor(data.duration / 60)}:${data.duration % 60}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    await sock.sendMessage(m.chat, {
        video: { url: data.download.high },
        caption: caption
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video!");
}
}
break

// Instagram Downloader
case "ig": {
if (!text) return m.reply("Masukkan URL Instagram!\n\nContoh: .ig https://www.instagram.com/reel/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh dari Instagram...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/instagram?url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh dari Instagram!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*INSTAGRAM DOWNLOADER*

👤 ${data.profile.full_name} (@${data.profile.username})
📝 ${data.caption.text}

📊 Statistics:
❤️ Likes: ${data.statistics.like_count || 0}
💬 Comments: ${data.statistics.comment_count}
👁️ Views: ${data.statistics.ig_play_count?.toLocaleString() || 0}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    for (let i = 0; i < data.data.length; i++) {
        const item = data.data[i];
        if (item.type === 'video') {
            await sock.sendMessage(m.chat, {
                video: { url: item.url },
                caption: i === 0 ? caption : ''
            }, { quoted: m });
        } else {
            await sock.sendMessage(m.chat, {
                image: { url: item.url },
                caption: i === 0 ? caption : ''
            }, { quoted: m });
        }
    }
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh dari Instagram!");
}
}
break

// Pinterest Downloader
case "pindl": {
if (!text) return m.reply("Masukkan URL Pinterest!\n\nContoh: .pindl https://pinterest.com/pin/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh dari Pinterest...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/pinterest?url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh dari Pinterest!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*PINTEREST DOWNLOADER*

📝 Title: ${data.title}
👤 Uploader: ${data.uploader.full_name} (@${data.uploader.username})
📅 Date: ${data.created_at}

📊 Statistics:
💾 Saved: ${data.statistics.saved}
💬 Comments: ${data.statistics.comment}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    const mediaUrl = data.media_urls.find(m => m.quality === 'original')?.url || data.media_urls[0].url;
    
    await sock.sendMessage(m.chat, {
        image: { url: mediaUrl },
        caption: caption
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh dari Pinterest!");
}
}
break

// YouTube Play Video
case "play": {
if (!text) return m.reply("Masukkan judul lagu/video!\n\nContoh: .play happy nation");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔍 Sedang mencari video...");

try {
    const query = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/play/video?query=${query}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Video tidak ditemukan!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*YOUTUBE PLAY*

🎵 Title: ${data.metadata.title}
👤 Channel: ${data.metadata.author.name}
⏱️ Duration: ${data.metadata.duration.timestamp}
👁️ Views: ${data.metadata.views.toLocaleString()}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    await sock.sendMessage(m.chat, {
        video: { url: data.download.url },
        caption: caption,
        contextInfo: {
            externalAdReply: {
                title: data.metadata.title,
                body: data.metadata.author.name,
                thumbnailUrl: data.metadata.thumbnail,
                sourceUrl: data.metadata.url,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mencari video!");
}
}
break

// YouTube Play Audio
case "song": {
if (!text) return m.reply("Masukkan judul lagu!\n\nContoh: .song happy nation");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔍 Sedang mencari audio...");

try {
    const query = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/play/audio?query=${query}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Audio tidak ditemukan!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    await sock.sendMessage(m.chat, {
        audio: { url: data.download.url },
        mimetype: 'audio/mpeg',
        contextInfo: {
            externalAdReply: {
                title: data.metadata.title,
                body: data.metadata.author.name,
                thumbnailUrl: data.metadata.thumbnail,
                sourceUrl: data.metadata.url,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
    if (!isPremium) {
        m.reply(`✅ Audio berhasil dikirim!\n\n⚡ Energy: ${currentEnergy} → ${newEnergy}`);
    }
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mencari audio!");
}
}
break

// SFile Downloader
case "sfiledl": {
if (!text) return m.reply("Masukkan URL SFile!\n\nContoh: .sfiledl https://sfile.mobi/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh file...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://apiz.rafzsoffc.cloud/download/sfile?apikey=zlynzeeapi&url=${url}`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh file!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*SFILE DOWNLOADER*

📁 Filename: ${data.filename}
📊 Size: ${data.size}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    await sock.sendMessage(m.chat, {
        document: { url: data.direct_url },
        fileName: data.filename,
        caption: caption
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh file!");
}
}
break

// Videy Downloader
case "videy": {
if (!text) return m.reply("Masukkan URL Videy!\n\nContoh: .videy https://videy.co/v/?id=xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🔄 Sedang mengunduh video Videy...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://www.velyn.mom/api/downloader/videy?apikey=velynapis&url=${url}`);
    const json = await res.json();
    
    if (json.status !== 200) return m.reply("❌ Gagal mengunduh video Videy!");
    
    const newEnergy = energy[m.sender] || 0;
    
    await sock.sendMessage(m.chat, {
        video: { url: json.data.url },
        caption: `*VIDEY DOWNLOADER*\n\n${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video Videy!");
}
}
break

// YouTube MP3
case "ytmp3": {
if (!text) return m.reply("Masukkan URL YouTube!\n\nContoh: .ytmp3 https://youtu.be/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🎵 Sedang mengunduh audio YouTube...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/youtube/audio?url=${url}&quality=128`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh audio YouTube!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    await sock.sendMessage(m.chat, {
        audio: { url: data.download.url },
        mimetype: 'audio/mpeg',
        contextInfo: {
            externalAdReply: {
                title: data.metadata.title,
                body: data.metadata.author.name,
                thumbnailUrl: data.metadata.thumbnail,
                sourceUrl: data.metadata.url,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
    if (!isPremium) {
        m.reply(`✅ Audio berhasil dikirim!\n\n⚡ Energy: ${currentEnergy} → ${newEnergy}`);
    }
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh audio YouTube!");
}
}
break

// YouTube MP4
case "ytmp4": {
if (!text) return m.reply("Masukkan URL YouTube!\n\nContoh: .ytmp4 https://youtu.be/xxx");

if (!energy[m.sender]) energy[m.sender] = 0;
const currentEnergy = energy[m.sender];

if (!isPremium) {
    if (currentEnergy < 1) return m.reply(`⚠️ Energy tidak cukup!\n\n⚡ Energy: ${currentEnergy}\n💎 Dibutuhkan: 1 Energy\n\n✨ Upgrade ke Premium untuk unlimited akses!`);
    energy[m.sender] -= 1;
    fs.writeFileSync('./Database/Energy.json', JSON.stringify(energy, null, 2));
}

m.reply("🎥 Sedang mengunduh video YouTube...");

try {
    const url = encodeURIComponent(text);
    const res = await fetch(`https://api.vreden.my.id/api/v1/download/youtube/video?url=${url}&quality=360`);
    const json = await res.json();
    
    if (!json.status) return m.reply("❌ Gagal mengunduh video YouTube!");
    
    const data = json.result;
    const newEnergy = energy[m.sender] || 0;
    
    const caption = `*YOUTUBE DOWNLOADER*

🎵 Title: ${data.metadata.title}
👤 Channel: ${data.metadata.author.name}
⏱️ Duration: ${data.metadata.duration.timestamp}
👁️ Views: ${data.metadata.views.toLocaleString()}
📅 ${data.metadata.ago}

${!isPremium ? `⚡ Energy: ${currentEnergy} → ${newEnergy}` : '✨ Premium User'}`;

    await sock.sendMessage(m.chat, {
        video: { url: data.download.url },
        caption: caption,
        contextInfo: {
            externalAdReply: {
                title: data.metadata.title,
                body: data.metadata.author.name,
                thumbnailUrl: data.metadata.thumbnail,
                sourceUrl: data.metadata.url,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mengunduh video YouTube!");
}
}
break

case "yts": {
if (!text) return m.reply("Masukkan query pencarian!\n\nContoh: .yts happy nation");

m.reply("🔍 Sedang mencari...");

try {
    const query = encodeURIComponent(text);
    const res = await fetch(`https://www.velyn.mom/api/search/play?apikey=velynapis&query=${query}`);
    const json = await res.json();
    
    if (json.status !== 200) return m.reply("❌ Pencarian gagal!");
    
    const data = json.data.searchResult;
    const videoUrl = `https://youtube.com/watch?v=${data.title.match(/\((.*?)\)/)?.[1] || ''}`;
    
    const caption = `*YOUTUBE SEARCH*

📝 Title: ${data.title}
👤 Uploader: ${data.uploader}
⏱️ Duration: ${Math.floor(data.duration / 60)}:${data.duration % 60}
👁️ Views: ${data.viewCount.toLocaleString()}
📅 ${data.uploadDate}

Pilih format download di bawah:`;

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({ 
                            image: { url: data.thumbnail } 
                        }, { upload: sock.waUploadToServer }))
                    },
                    body: { text: caption },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{"display_text":"🎵 Download Audio","id":".ytmp3 ${videoUrl}"}`
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{"display_text":"🎥 Download Video","id":".ytmp4 ${videoUrl}"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"📺 Watch on YouTube","url":"${videoUrl}","merchant_url":"${videoUrl}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });
    
    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    
} catch (error) {
    console.log(error);
    m.reply("❌ Terjadi kesalahan saat mencari!");
}
}
break
        
case "cekidch":
case "idch": {
    if (!text) return m.reply(`*Contoh :* ${cmd} link channel`); 
    if (!text.includes("https://whatsapp.com/channel/")) {
        return m.reply("Link channel tidak valid");
    }

    let result = text.split("https://whatsapp.com/channel/")[1];
    let res = await sock.newsletterMetadata("invite", result);
    let teks = `*Channel ID Ditemukan ✅*\n\n- ${res.id}`;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Channel ID","copy_code":"${res.id}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "done":
case "don":
case "proses":
case "ps": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(`*Contoh :* ${cmd} nama barang`);

    const status = /done|don/.test(command) ? "Transaksi Done ✅" : "Dana Telah Diterima ✅";

    const teks = `${status}

📦 Pembelian: ${text}
🗓️ Tanggal: ${global.tanggal(Date.now())}

📢 Cek Testimoni Pembeli:
${global.linkChannel || "-"}

📣 Gabung Grup Share & Promosi:
${global.linkGrup || "-"}`;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"Channel Testimoni","url":"${global.linkChannel}"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"Grup Marketplace","url":"${global.linkGrup}"}`
                            }
                        ]
                    }, 
                    contextInfo: {
                     isForwarded: true
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "tourl": {
    if (!/image|video|audio|application/.test(mime)) 
        return m.reply(`Media tidak ditemukan!\nKetik *${cmd}* dengan reply/kirim media`)

    const FormData = require('form-data');
    const { fromBuffer } = require('file-type');    

    async function dt(buffer) {
        const fetchModule = await import('node-fetch');
        const fetch = fetchModule.default;
        let { ext } = await fromBuffer(buffer);
        let bodyForm = new FormData();
        bodyForm.append("fileToUpload", buffer, "file." + ext);
        bodyForm.append("reqtype", "fileupload");
        let res = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: bodyForm,
        });
        let data = await res.text();
        return data;
    }

    let aa = m.quoted ? await m.quoted.download() : await m.download();
    let dd = await dt(aa);

    // bikin button copy url
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: `✅ Media berhasil diupload!\n\nURL: ${dd}` },
                    nativeFlowMessage: {
                        buttons: [
                            { 
                                name: "cta_copy", 
                                buttonParamsJson: `{"display_text":"Copy URL","copy_code":"${dd}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "tourl2": {
    if (!/image/.test(mime)) 
        return m.reply(`Media tidak ditemukan!\nKetik *${cmd}* dengan reply/kirim foto`)
    try {
        const { ImageUploadService } = require('node-upload-images');
        let mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        const service = new ImageUploadService('pixhost.to');
        let buffer = fs.readFileSync(mediaPath);
        let { directLink } = await service.uploadFromBinary(buffer, 'skyzo.png');
        await fs.unlinkSync(mediaPath);

        // button copy url
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `✅ Foto berhasil diupload!\n\nURL: ${directLink}` },
                        nativeFlowMessage: {
                            buttons: [
                                { 
                                    name: "cta_copy", 
                                    buttonParamsJson: `{"display_text":"Copy URL","copy_code":"${directLink}"}`
                                }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Tourl Error:", err);
        m.reply("Terjadi kesalahan saat mengubah media menjadi URL.");
    }
}
break;

//###############################//

case "backupsc":
case "bck":
case "backup": {
    if (m.sender.split("@")[0] !== global.owner)
        return m.reply(mess.owner);
    try {        
        const tmpDir = "./Tmp";
        if (fs.existsSync(tmpDir)) {
            const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".js"));
            for (let file of files) {
                fs.unlinkSync(`${tmpDir}/${file}`);
            }
        }
        await m.reply("Processing Backup Script . .");        
        const name = `Backup-Script-Pushkontak`; 
        const exclude = ["node_modules", "skyzopedia", "session", "package-lock.json", "yarn.lock", ".npm", ".cache"];
        const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && f !== "");

        if (!filesToZip.length) return m.reply("Tidak ada file yang dapat di-backup.");

        execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);

        await sock.sendMessage(m.sender, {
            document: fs.readFileSync(`./${name}.zip`),
            fileName: `${name}.zip`,
            mimetype: "application/zip"
        }, { quoted: m });

        fs.unlinkSync(`./${name}.zip`);

        if (m.chat !== m.sender) m.reply("Script bot berhasil dikirim ke private chat.");
    } catch (err) {
        console.error("Backup Error:", err);
        m.reply("Terjadi kesalahan saat melakukan backup.");
    }
}
break;

//###############################//

case "kick":
case "kik": {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isOwner && !m.isAdmin) return m.reply(mess.admin);
    if (!m.isBotAdmin) return m.reply(mess.botadmin);

    let target;

    if (m.mentionedJid?.[0]) {
        target = m.mentionedJid[0];
    } else if (m.quoted?.sender) {
        target = m.quoted.sender;
    } else if (text) {
        const cleaned = text.replace(/[^0-9]/g, "");
        if (cleaned) target = cleaned + "@s.whatsapp.net";
    }

    if (!target) return m.reply(`*Contoh :* .kick @tag/6283XXX`);

    try {
        await sock.groupParticipantsUpdate(m.chat, [target], "remove");
        return sock.sendMessage(m.chat, {
            text: `✅ Berhasil mengeluarkan @${target.split("@")[0]}`,
            mentions: [target]
        }, { quoted: m });
    } catch (err) {
        console.error("Kick error:", err);
        return m.reply("Gagal mengeluarkan anggota. Coba lagi atau cek hak akses bot.");
    }
}
break;

//###############################//

case "closegc":
case "close":
case "opengc":
case "open": {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isOwner && !m.isAdmin) return m.reply(mess.admin);
    if (!m.isBotAdmin) return m.reply(mess.botadmin);

    try {
        const cmd = command.toLowerCase();

        if (cmd === "open" || cmd === "opengc") {
            await sock.groupSettingUpdate(m.chat, 'not_announcement');
            return m.reply("Grup berhasil dibuka! Sekarang semua anggota dapat mengirim pesan.");
        }

        if (cmd === "close" || cmd === "closegc") {
            await sock.groupSettingUpdate(m.chat, 'announcement');
            return m.reply("Grup berhasil ditutup! Sekarang hanya admin yang dapat mengirim pesan.");
        }

    } catch (error) {
        console.error("Error updating group settings:", error);
        return m.reply("Terjadi kesalahan saat mencoba mengubah pengaturan grup.");
    }
}
break;

//###############################//

case "ht":
case "hidetag": {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(`*Contoh :* ${cmd} pesannya`);
    try {
        if (!m.metadata || !m.metadata.participants) return m.reply("Gagal mendapatkan daftar anggota grup. Coba lagi.");
        const members = m.metadata.participants.map(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid);
        await sock.sendMessage(m.chat, {
            text: text,
            mentions: members
        }, {
            quoted: null
        });
    } catch (error) {
        console.error("Error sending hidetag message:", error);
        return m.reply("Terjadi kesalahan saat mencoba mengirim pesan hidetag.");
    }
}
break;

//###############################//

case "welcome": {
    if (!isOwner) return m.reply(mess.owner)
    if (!/on|off/.test(text)) {
        let teks = `
*⚙️ Bot Settings Welcome*
- Status: ${global.db.settings.welcome ? "*aktif (✅)*" : "*tidak aktif (❌)*"}

Pilih Salah Satu Opsi Untuk Mengatur Welcome Message!
`
        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: teks },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Aktifkan Welcome","id":".welcome on"}` },
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Matikan Welcome","id":".welcome off"}` }
                            ]
                        },
                        contextInfo: { mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"] }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m })
        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    if (text === "on") {
        global.db.settings.welcome = true
        return m.reply(`*✅ Berhasil Menyalakan Welcome*\n\n*⚙️ Bot Settings Welcome*
- Status: ${global.db.settings.welcome ? "*aktif (✅)*" : "*tidak aktif (❌)*"}`)
    }

    if (text === "off") {
        global.db.settings.welcome = false
        return m.reply(`*✅ Berhasil Mematikan Welcome*\n\n*⚙️ Bot Settings Welcome*
- Status: ${global.db.settings.welcome ? "*aktif (✅)*" : "*tidak aktif (❌)*"}`)
    }
}
break

//###############################//

case "antilink": {
    if (!isOwner) return m.reply(mess.owner)
    if (!m.isGroup) return m.reply(mess.group)
    if (!text) {
        let teks = `
*⚙️ Grup Settings Antilink*

- Status: ${global.db.groups[m.chat].antilink ? "*aktif (✅)*" : "*tidak aktif (❌)*"}
- ID Grup: ${m.chat}
- Grup Name: ${m.metadata.subject}

Pilih Salah Satu Opsi Settings Antilink Untuk Grup Ini!
`
        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: teks },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Aktifkan Antilink","id":".antilink on"}` },
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Matikan Antilink","id":".antilink off"}` }
                            ]
                        },
                        contextInfo: { mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"] }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m })
        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    let group = global.db.groups[m.chat]
    if (text === "on") {
        group.antilink = true
        group.antilink2 = false
        return m.reply(`*✅ Berhasil Menyalakan Antilink*\n\n*⚙️ Grup Settings Antilink*\n- Status: *aktif (✅)*\n- ID Grup: ${m.chat}\n- Grup Name: ${m.metadata.subject}`)
    }

    if (text === "off") {
        group.antilink = false
        return m.reply(`*✅ Berhasil Mematikan Antilink*\n\n*⚙️ Grup Settings Antilink*\n- Status: *tidak aktif (❌)*\n- ID Grup: ${m.chat}\n- Grup Name: ${m.metadata.subject}`)
    }
}
break

//###############################//

case "antilink2": {
    if (!isOwner) return m.reply(mess.owner)
    if (!m.isGroup) return m.reply(mess.group)
    if (!text) {
        let teks = `
*⚙️ Grup Settings Antilink V2*
- Status: ${global.db.groups[m.chat].antilink2 ? "*aktif (✅)*" : "*tidak aktif (❌)*"}
- ID Grup: ${m.chat}
- Grup Name: ${m.metadata.subject}

Pilih Salah Satu Opsi Settings Antilink V2 Untuk Grup Ini!
`
        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: teks },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Aktifkan Antilink V2","id":".antilink2 on"}` },
                                { name: "quick_reply", buttonParamsJson: `{"display_text":"Matikan Antilink V2","id":".antilink2 off"}` }
                            ]
                        },
                        contextInfo: { mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"] }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m })
        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    let group = global.db.groups[m.chat]
    if (text === "on") {
        group.antilink2 = true
        group.antilink = false
        return m.reply(`*✅ Berhasil Menyalakan Antilink V2*\n\n*⚙️ Grup Settings Antilink V2*\n- Status: *aktif (✅)*\n- ID Grup: ${m.chat}\n- Grup Name: ${m.metadata.subject}`)
    }

    if (text === "off") {
        group.antilink2 = false
        return m.reply(`*✅ Berhasil Mematikan Antilink V2*\n\n*⚙️ Grup Settings Antilink V2*\n- Status: *tidak aktif (❌)*\n- ID Grup: ${m.chat}\n- Grup Name: ${m.metadata.subject}`)
    }
}
break

//###############################//

case "jpmch": {
    if (!isOwner) return m.reply(mess.owner)
    if (!text) return m.reply(`*Contoh :* ${cmd} pesannya & bisa dengan foto juga`)

    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }
    
    const Channel = await sock.newsletterFetchAllParticipating()
    const channelList = Object.keys(Channel)
    if (!channelList || channelList.length < 1) return m.reply("Channel tidak ditemukan")
    let successCount = 0
    const messageType = mediaPath ? "teks & foto" : "teks"
    const senderChat = m.chat

    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text }
        : { text }
    global.messageJpm = messageContent

    await m.reply(`Memproses JPM ${messageType} ke ${channelList.length} Channel WhatsApp.`)
    global.statusjpm = true

    for (const chId of channelList) {
    if (global.stopjpm) {
        delete global.stopjpm
        delete global.statusjpm
        break
        }
        try {
            await sock.sendMessage(chId, global.messageJpm)
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke channel ${chId}:`, err)
        }
        await sleep(global.JedaJpm)
    }

    if (mediaPath) await fs.unlinkSync(mediaPath)    
    delete global.statusjpm
    await m.reply(`JPM Channel Telah Selsai ✅\nBerhasil dikirim ke ${successCount} Channel WhatsApp.`)
}
break

//###############################//

case "jasher": case "jpm": case "jaser": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh :* ${cmd} pesannya & bisa dengan foto juga`)
    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }
    const allGroups = await sock.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    let messageContent = await generateWAMessageFromContent(m.sender, { 
extendedTextMessage: { 
text: text 
}}, { userJid: m.sender, quoted: FakeChannel });
    
    if (mediaPath) {
    const aa = await prepareWAMessageMedia({ image: await fs.readFileSync(mediaPath) }, { upload: sock.waUploadToServer })
    aa.imageMessage.caption = text
    messageContent = await generateWAMessageFromContent(m.sender, {
    ...aaa
    }, { userJid: m.sender, quoted: FakeChannel });
    }

    global.messageJpm = messageContent
    const senderChat = m.chat
    await m.reply(`Memproses ${mediaPath ? "JPM teks & foto" : "JPM teks"} ke ${groupIds.length} grup chat`)
    global.statusjpm = true
    
    for (const groupId of groupIds) {
        if (db.settings.bljpm.includes(groupId)) continue
        if (global.stopjpm) {
        delete global.stopjpm
        delete global.statusjpm
        break
        }
        try {
            await sock.relayMessage(groupId, global.messageJpm.message, { messageId: global.messageJpm.key.id });
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }
        await sleep(global.JedaJpm)
    }

    if (mediaPath) await fs.unlinkSync(mediaPath)
    delete global.statusjpm
    await sock.sendMessage(senderChat, {
        text: `JPM ${mediaPath ? "teks & foto" : "teks"} berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })
}
break

//###############################//

case "jpmht": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh :* ${cmd} pesannya & bisa dengan foto juga`)
    let mediaPath
    const mimeType = mime
    if (/image/.test(mimeType)) {
        mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    }
    const allGroups = await sock.groupFetchAllParticipating()
    const groupIds = Object.keys(allGroups)
    let successCount = 0
    const messageContent = mediaPath
        ? { image: await fs.readFileSync(mediaPath), caption: text }
        : { text }
    global.messageJpm = messageContent
    const senderChat = m.chat
    await m.reply(`Memproses ${mediaPath ? "JPM teks & foto" : "JPM teks"} hidetag ke ${groupIds.length} grup chat`)
    global.statusjpm = true
    
    for (const groupId of groupIds) {
        if (db.settings.bljpm.includes(groupId)) continue
        if (global.stopjpm) {
        delete global.stopjpm
        delete global.statusjpm
        break
        }
        messageContent.mentions = allGroups[groupId].participants.map(e => e.id)
        try {
            await sock.sendMessage(groupId, global.messageJpm, { quoted: FakeChannel })
            successCount++
        } catch (err) {
            console.error(`Gagal kirim ke grup ${groupId}:`, err)
        }
        await sleep(global.JedaJpm)
    }

    if (mediaPath) await fs.unlinkSync(mediaPath)
    delete global.statusjpm
    await sock.sendMessage(senderChat, {
        text: `JPM ${mediaPath ? "teks & foto" : "teks"} hidetag berhasil dikirim ke ${successCount} grup.`,
    }, { quoted: m })
}
break

//###############################//

case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return m.reply("Kirim foto dengan caption .sticker")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
var media = await sock.downloadAndSaveMediaMessage(qmsg)
await sock.sendStimg(m.chat, media, m, {packname: "Xskycode."})
}
break

//###############################//

case "brat": {
if (!text) return m.reply(`*Contoh :* ${cmd} Hallo Aku Skyzopedia!`)
var media = await getBuffer(`https://api.siputzx.my.id/api/m/brat?text=${text}&isAnimated=false&delay=500`)
await sock.sendStimg(m.chat, media, m, {packname: "Xskycode."})
}
break

//###############################//

case "public":
case "self": {
    if (!isOwner) return m.reply(mess.owner);
    let path = require.resolve("./settings.js");
    let data = fs.readFileSync(path, "utf-8");

    if (command === "public") {
        global.mode_public = true;
        sock.public = global.mode_public
        let newData = data.replace(/global\.mode_public\s*=\s*(true|false)/, "global.mode_public = true");
        fs.writeFileSync(path, newData, "utf-8");
        return m.reply("✅ Mode berhasil diubah menjadi *Public*");
    }

    if (command === "self") {
        global.mode_public = false;
        sock.public = global.mode_public
        let newData = data.replace(/global\.mode_public\s*=\s*(true|false)/, "global.mode_public = false");
        fs.writeFileSync(path, newData, "utf-8");
        return m.reply("✅ Mode berhasil diubah menjadi *Self*");
    }
}
break;

//###############################//

case "setjeda": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(`*Contoh :*\n${cmd} push 5000\n${cmd} jpm 6000\n\nKeterangan format waktu:\n1 detik = 1000\n\nJeda waktu saat ini:\nJeda Pushkontak > ${global.JedaPushkontak}\nJeda JPM > ${global.JedaJpm}`);

    let args = text.split(" ");
    if (args.length < 2) return m.reply(`*Contoh :*\n${cmd} push 5000\n${cmd} jpm 6000\n\nKeterangan format waktu:\n1 detik = 1000\n\nJeda waktu saat ini:\nJeda Pushkontak > ${global.JedaPushkontak}\nJeda JPM > ${global.JedaJpm}`);

    let target = args[0].toLowerCase(); // push / jpm
    let value = args[1];

    if (isNaN(value)) return m.reply("Harus berupa angka!");
    let jeda = parseInt(value);

    let fs = require("fs");
    let path = require.resolve("./settings.js");
    let data = fs.readFileSync(path, "utf-8");

    if (target === "push") {
        let newData = data.replace(/global\.JedaPushkontak\s*=\s*\d+/, `global.JedaPushkontak = ${jeda}`);
        fs.writeFileSync(path, newData, "utf-8");
        global.JedaPushkontak = jeda;
        return m.reply(`✅ Berhasil mengubah *Jeda Push Kontak* menjadi *${jeda}* ms`);
    } 
    
    if (target === "jpm") {
        let newData = data.replace(/global\.JedaJpm\s*=\s*\d+/, `global.JedaJpm = ${jeda}`);
        fs.writeFileSync(path, newData, "utf-8");
        global.JedaJpm = jeda;
        return m.reply(`✅ Berhasil mengubah *Jeda JPM* menjadi *${jeda}* ms`);
    }

    return m.reply(`Pilihan tidak valid!\nGunakan: *push* atau *jpm*`);
}
break;

//###############################//

case "pushkontak": case "puskontak": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh :* ${cmd} pesannya`)
global.textpushkontak = text
let rows = []
const a = await sock.groupFetchAllParticipating()
global.dataAllGrup = a
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.pushkontak-response ${u.id}`
})
}
await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup Pushkontak\n`
}, { quoted: m })
}
break

//###############################//

case "pushkontak-response": {
  if (!isOwner) return m.reply(mess.owner)
  if (!global.textpushkontak || !global.dataAllGrup) return m.reply(`Data teks pushkontak tidak ditemukan!\nSilahkan ketik *.pushkontak* pesannya`);
  const gc = global.dataAllGrup
  const teks = global.textpushkontak
  const jidawal = m.chat
  const data = await gc[text]
  const halls = data.participants
    .filter(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
    .map(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
    .filter(id => id !== botNumber && id.split("@")[0] !== global.owner); 

  await m.reply(`🚀 Memulai pushkontak ke dalam grup ${data.subject} dengan total member ${halls.length}`);
  
 global.statuspush = true
 let count = 0
 let msg = await generateWAMessageFromContent(m.sender, { 
extendedTextMessage: { 
text: global.textpushkontak 
}}, { userJid: m.sender, quoted: FakeChannel });
 
  for (const mem of halls) {
    if (global.stoppush) {
    delete global.stoppush
    delete global.statuspush
    break
    }
await sock.relayMessage(mem, msg.message, { messageId: msg.key.id });
    await global.sleep(global.JedaPushkontak);
    count += 1
  }
  
  delete global.statuspush
  delete global.textpushkontak
  await m.reply(`✅ Sukses pushkontak!\nPesan berhasil dikirim ke *${count}* member.`, jidawal)
}
break

//###############################//

case "pushkontak2": case "puskontak2": {
if (!isOwner) return m.reply(mess.owner)
if (!text || !text.includes("|")) return m.reply(`Masukan pesan & nama kontak\n*Contoh :* ${cmd} pesan|namakontak`)
global.textpushkontak = text.split("|")[0]
let rows = []
const a = await sock.groupFetchAllParticipating()
global.dataAllGrup = a
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.pushkontak-response2 ${u.id}|${text.split("|")[1]}`
})
}
await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup PushkontakV2\n`
}, { quoted: m })
}
break

//###############################//

case "pushkontak-response2": {
  if (!isOwner) return m.reply(mess.owner)
  if (!global.textpushkontak || !global.dataAllGrup) return m.reply(`Data teks pushkontak tidak ditemukan!\nSilahkan ketik *.pushkontak2* pesannya|namakontak`);
  const teks = global.textpushkontak
  const jidawal = m.chat
  const data = global.dataAllGrup[text.split("|")[0]]
  const halls = data.participants
    .filter(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
    .map(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
    .filter(id => id !== botNumber && id.split("@")[0] !== global.owner); 

  await m.reply(`🚀 Memulai pushkontak autosave kontak ke dalam grup ${data.subject} dengan total member ${halls.length}`);
  
  global.statuspush = true
 let count = 0
 let msg = await generateWAMessageFromContent(m.sender, { 
extendedTextMessage: { text: global.textpushkontak }}, { userJid: m.sender, quoted: FakeChannel });
 
  for (const mem of halls) {
    if (global.stoppush) {
    delete global.stoppush
    delete global.statuspush
    break
    }    
    const contactAction = {
        "fullName": `${text.split("|")[1]} #${mem.split("@")[0]}`,
        "lidJid": mem, 
        "saveOnPrimaryAddressbook": true
    };
await sock.relayMessage(mem, msg.message, { messageId: msg.key.id });
    await sock.addOrEditContact(mem, contactAction);
    await global.sleep(global.JedaPushkontak);
    count += 1
  }
  
  delete global.statuspush
  delete global.textpushkontak
  await m.reply(`✅ Sukses pushkontak!\nTotal kontak berhasil disimpan *${count}*`, jidawal)
}
break

//###############################//

case "savenomor":
case "sv":
case "save": {
    if (!isOwner) return m.reply(mess.owner)

    let nomor, nama

    if (m.isGroup) {
        if (!text) return m.reply(`*Contoh penggunaan di grup:*\n${cmd} @tag|nama\natau reply target dengan:\n${cmd} nama`)

        // Jika ada tag
        if (m.mentionedJid[0]) {
            nomor = m.mentionedJid[0]
            nama = text.split("|")[1]?.trim()
            if (!nama) return m.reply(`Harap tulis nama setelah "|"\n*Contoh:* ${cmd} @tag|nama`)
        } 
        // Jika reply
        else if (m.quoted) {
            nomor = m.quoted.sender
            nama = text.trim()
        } 
        // Jika input manual nomor
        else if (/^\d+$/.test(text.split("|")[0])) {
            nomor = text.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
            nama = text.split("|")[1]?.trim()
            if (!nama) return m.reply(`Harap tulis nama setelah "|"\n*Contoh:* ${cmd} 628xxxx|nama`)
        } 
        else {
            return m.reply(`*Contoh penggunaan di grup:*\n${cmd} @tag|nama\natau reply target dengan:\n${cmd} nama`)
        }
    } else {
        // Private chat hanya nama
        if (!text) return m.reply(`*Contoh penggunaan di private:*\n${cmd} nama`)
        nomor = m.chat
        nama = text.trim()
    }

    const contactAction = {
        "fullName": nama,
        "lidJid": nomor,
        "saveOnPrimaryAddressbook": true
    };

    await sock.addOrEditContact(nomor, contactAction);

    return m.reply(`✅ Berhasil menyimpan kontak

- Nomor: ${nomor.split("@")[0]}
- Nama: ${nama}`)
}
break

//###############################//

case "savekontak": case "svkontak": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(`Masukan namakontak\n*Contoh :* ${cmd} Xskycode`)
global.namakontak = text
let rows = []
const a = await sock.groupFetchAllParticipating()
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.savekontak-response ${u.id}`
})
}
await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup Savekontak\n`
}, { quoted: m })
}
break

//###############################//

case "savekontak-response": {
  if (!isOwner) return m.reply(mess.owner)
  if (!global.namakontak) return m.reply(`Data nama savekontak tidak ditemukan!\nSilahkan ketik *.savekontak* namakontak`);
  try {
    const res = await sock.groupMetadata(text)
    const halls = res.participants
      .filter(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
      .map(v => v.id.includes("@s.whatsapp.net") ? v.id : v.jid)
      .filter(id => id !== botNumber && id.split("@")[0] !== global.owner)

    if (!halls.length) return m.reply("Tidak ada kontak yang bisa disimpan.")
    let names = text
    const existingContacts = JSON.parse(fs.readFileSync('./storage/contacts.json', 'utf8') || '[]')
    const newContacts = [...new Set([...existingContacts, ...halls])]

    fs.writeFileSync('./storage/contacts.json', JSON.stringify(newContacts, null, 2))

    // Buat file .vcf
    const vcardContent = newContacts.map(contact => {
      const phone = contact.split("@")[0]
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:${global.namakontak} - ${phone}`,
        `TEL;type=CELL;type=VOICE;waid=${phone}:+${phone}`,
        "END:VCARD",
        ""
      ].join("\n")
    }).join("")

    fs.writeFileSync("./storage/contacts.vcf", vcardContent, "utf8")

    // Kirim ke private chat
    if (m.chat !== m.sender) {
      await m.reply(`Berhasil membuat file kontak dari grup ${res.subject}\n\nFile kontak telah dikirim ke private chat\nTotal ${halls.length} kontak`)
    }

    await sock.sendMessage(
      m.sender,
      {
        document: fs.readFileSync("./storage/contacts.vcf"),
        fileName: "contacts.vcf",
        caption: `File kontak berhasil dibuat ✅\nTotal ${halls.length} kontak`,
        mimetype: "text/vcard",
      },
      { quoted: m }
    )
    
    delete global.namakontak

    fs.writeFileSync("./storage/contacts.json", "[]")
    fs.writeFileSync("./storage/contacts.vcf", "")

  } catch (err) {
    m.reply("Terjadi kesalahan saat menyimpan kontak:\n" + err.toString())
  }
}
break

//###############################//

case "stopjpm": {
if (!isOwner) return m.reply(mess.owner)
if (!global.statusjpm) return m.reply("Jpm sedang tidak berjalan!")
global.stopjpm = true
return m.reply("Berhasil menghentikan jpm ✅")
}
break

//###############################//

case "stoppushkontak": case "stoppush": case "stoppus": {
if (!isOwner) return m.reply(mess.owner)
if (!global.statuspush) return m.reply("Pushkontak sedang tidak berjalan!")
global.stoppush = true
return m.reply("Berhasil menghentikan pushkontak ✅")
}
break

//###############################//

case "subdo":
case "subdomain": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text.includes("|")) return m.reply(`*Contoh penggunaan :*
ketik ${cmd} hostname|ipvps`);

    const obj = Object.keys(subdomain);
    if (obj.length < 1) return m.reply("Tidak ada domain yang tersedia.");

    const hostname = text.split("|")[0].toLowerCase();
    const ip = text.split("|")[1];
    const rows = obj.map((domain, index) => ({
        title: `🌐 ${domain}`,
        description: `Result: https://${hostname}.${domain}`,
        id: `.subdomain-response ${index + 1} ${hostname.trim()}|${ip}`
    }));

    await sock.sendMessage(m.chat, {
        buttons: [
            {
                buttonId: 'action',
                buttonText: { displayText: 'ini pesan interactiveMeta' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'Pilih Domain',
                        sections: [
                            {
                                title: `© Powered By ${namaOwner}`,
                                rows: rows
                            }
                        ]
                    })
                }
            }
        ],
        headerType: 1,
        viewOnce: true,
        text: `\nPilih Domain Server Yang Tersedia\nTotal Domain: ${obj.length}\n`
    }, { quoted: m });
}
break;

//###############################//

case "subdomain-response": { 
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return;

    if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!");
    const dom = Object.keys(subdomain);
    const domainIndex = Number(args[0]) - 1;
    if (domainIndex >= dom.length || domainIndex < 0) return m.reply("Domain tidak ditemukan!");

    if (!args[1] || !args[1].includes("|")) return m.reply("Hostname/IP Tidak ditemukan!");

    let tldnya = dom[domainIndex];
    const [host, ip] = args[1].split("|").map(str => str.trim());

    async function subDomain1(host, ip) {
        return new Promise((resolve) => {
            axios.post(
                `https://api.cloudflare.com/client/v4/zones/${subdomain[tldnya].zone}/dns_records`,
                {
                    type: "A",
                    name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                    content: ip.replace(/[^0-9.]/gi, ""),
                    ttl: 3600,
                    priority: 10,
                    proxied: false,
                },
                {
                    headers: {
                        Authorization: `Bearer ${subdomain[tldnya].apitoken}`,
                        "Content-Type": "application/json",
                    },
                }
            ).then(response => {
                let res = response.data;
                if (res.success) {
                    resolve({ success: true, name: res.result?.name, ip: res.result?.content });
                } else {
                    resolve({ success: false, error: "Gagal membuat subdomain." });
                }
            }).catch(error => {
                let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan!";
                resolve({ success: false, error: errorMsg });
            });
        });
    }

    const domnode = `node${getRandom("")}.${host}`;
    let panelDomain = "";
    let nodeDomain = "";

    for (let i = 0; i < 2; i++) {
        let subHost = i === 0 ? host.toLowerCase() : domnode;
        try {
            let result = await subDomain1(subHost, ip);
            if (result.success) {
                if (i === 0) panelDomain = result.name;
                else nodeDomain = result.name;
            } else {
                return m.reply(result.error);
            }
        } catch (err) {
            return m.reply("Error: " + err.message);
        }
    }

    let teks = `
*✅ Subdomain Berhasil Dibuat*

- IP: ${ip}
- Panel: ${panelDomain}
- Node: ${nodeDomain}
`;

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Subdomain Panel","copy_code":"${panelDomain}"}`
                            },
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Subdomain Node","copy_code":"${nodeDomain}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//###############################//

case "installpanel": {
    if (!isOwner) return m.reply(mess.owner)
    if (!text) return m.reply("\nFormat salah!\n\n*Contoh penggunaan :*\nketik .instalpanel ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    let vii = text.split("|");
    if (vii.length < 5) return m.reply("\nFormat salah!\n\n*Contoh penggunaan :*\nketik .instalpanel ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*");
    
    const ssh2 = require("ssh2");
    const ress = new ssh2.Client();
    const connSettings = {
        host: vii[0],
        port: '22',
        username: 'root',
        password: vii[1]
    };
    
    const jids = m.chat
    const pass = "admin001";
    let passwordPanel = pass;
    const domainpanel = vii[2];
    const domainnode = vii[3];
    const ramserver = vii[4];
    const deletemysql = `\n`;
    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
    
    async function instalWings() {
    ress.exec(commandPanel, async (err, stream) => {
        if (err) {
            console.error('Wings installation error:', err);
            m.reply(`Gagal memulai instalasi Wings: ${err.message}`);
            return ress.end();
        }
        
        stream.on('close', async (code, signal) => {
            await InstallNodes()            
        }).on('data', async (data) => {
            const dataStr = data.toString();
            console.log('Wings Install: ' + dataStr);
            
            if (dataStr.includes('Input 0-6')) {
                stream.write('1\n');
            }
            else if (dataStr.includes('(y/N)')) {
                stream.write('y\n');
            }
            else if (dataStr.includes('Enter the panel address (blank for any address)')) {
                stream.write(`${domainpanel}\n`);
            }
            else if (dataStr.includes('Database host username (pterodactyluser)')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Database host password')) {
                stream.write('admin\n');
            }
            else if (dataStr.includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
                stream.write(`${domainnode}\n`);
            }
            else if (dataStr.includes('Enter email address for Let\'s Encrypt')) {
                stream.write('admin@gmail.com\n');
            }
        }).stderr.on('data', async (data) => {
            console.error('Wings Install Error: ' + data);
            m.reply(`Error pada instalasi Wings:\n${data}`);
        });
    });
}

    async function InstallNodes() {
        ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                
    let teks = `
*Install Panel Telah Berhasil ✅*

*Berikut Detail Akun Panel Kamu 📦*

👤 Username : \`${usernamePanel}\`
🔐 Password : \`${passwordPanel}\`
🌐 ${domainpanel}

Silahkan setting allocation & ambil token node di node yang sudah dibuat oleh bot.

*Cara menjalankan wings :*
\`.startwings ipvps|pwvps|tokennode\`
    `;

    let msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Username","copy_code":"${usernamePanel}"}`
                            },
                            { 
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Password","copy_code":"${passwordPanel}"}`
                            },
                            { 
                                name: "cta_url",
                                buttonParamsJson: `{"display_text":"Login Panel","url":"${domainpanel}"}`
                            }
                        ]
                    }, 
                    contextInfo: {
                    isForwarded: true
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
                if (data.toString().includes("Masukkan nama lokasi: ")) {
                    stream.write('Singapore\n');
                }
                if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                    stream.write('Node By Skyzo\n');
                }
                if (data.toString().includes("Masukkan domain: ")) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes("Masukkan nama node: ")) {
                    stream.write('Skyzopedia\n');
                }
                if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                    stream.write(`${ramserver}\n`);
                }
                if (data.toString().includes("Masukkan Locid: ")) {
                    stream.write('1\n');
                }
            }).stderr.on('data', async (data) => {
                console.log('Stderr : ' + data);
                m.reply(`Error pada instalasi Wings: ${data}`);
            });
        });
    }

    async function instalPanel() {
        ress.exec(commandPanel, (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalWings();
            }).on('data', async (data) => {
                if (data.toString().includes('Input 0-6')) {
                    stream.write('0\n');
                } 
                if (data.toString().includes('(y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Database name (panel)')) {
                    stream.write('\n');
                }
                if (data.toString().includes('Database username (pterodactyl)')) {
                    stream.write('admin\n');
                }
                if (data.toString().includes('Password (press enter to use randomly generated password)')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
                    stream.write('Asia/Jakarta\n');
                } 
                if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Email address for the initial admin account')) {
                    stream.write('admin@gmail.com\n');
                } 
                if (data.toString().includes('Username for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('First name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Last name for the initial admin account')) {
                    stream.write('admin\n');
                } 
                if (data.toString().includes('Password for the initial admin account')) {
                    stream.write(`${passwordPanel}\n`);
                } 
                if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
                    stream.write(`${domainpanel}\n`);
                } 
                if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
                    stream.write('y\n')
                } 
                if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
                    stream.write('1\n');
                } 
                if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('(yes/no)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Still assume SSL? (y/N)')) {
                    stream.write('y\n');
                } 
                if (data.toString().includes('Please read the Terms of Service')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('(A)gree/(C)ancel:')) {
                    stream.write('A\n');
                } 
                console.log('Logger: ' + data.toString());
            }).stderr.on('data', (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('STDERR: ' + data);
            });
        });
    }

    ress.on('ready', async () => {
        await m.reply(`*Memproses install server panel 🚀*\n\n` +
                     `*IP Address:* ${vii[0]}\n` +
                     `*Domain Panel:* ${domainpanel}\n\n` +
                     `Mohon tunggu 10-20 menit hingga proses install selesai`);
        
        ress.exec(deletemysql, async (err, stream) => {
            if (err) throw err;
            
            stream.on('close', async (code, signal) => {
                await instalPanel();
            }).on('data', async (data) => {
                await stream.write('\t');
                await stream.write('\n');
                await console.log(data.toString());
            }).stderr.on('data', async (data) => {
                m.reply(`Error Terjadi kesalahan :\n${data}`);
                console.log('Stderr : ' + data);
            });
        });
    });

    ress.on('error', (err) => {
        console.error('SSH Connection Error:', err);
        m.reply(`Gagal terhubung ke server: ${err.message}`);
    });

    ress.connect(connSettings);
}
break

//###############################//

case "startwings":
case "configurewings": {
    if (!isOwner) return m.reply(mess.owner)
    let t = text.split('|');
    if (t.length < 3) return m.reply("\nFormat salah!\n\n*Contoh penggunaan :*\nketik .startwings ipvps|pwvps|token_wings");

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;

    const ress = new ssh2.Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) {
                m.reply('Gagal menjalankan perintah di VPS');
                ress.end();
                return;
            }

            stream.on('close', async (code, signal) => {
                await m.reply("Berhasil menjalankan wings node panel pterodactyl ✅");
                ress.end();
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
            }).stderr.on('data', (data) => {
                console.log("STDERR:", data.toString());
                // Opsi jika perlu input interaktif
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                m.reply('Terjadi error saat eksekusi:\n' + data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err.message);
        m.reply('Gagal terhubung ke VPS: IP atau password salah.');
    }).connect(connSettings);
}
break;

//###############################//

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {
    if (!isOwner && !isReseller) {
        return m.reply(`Fitur ini untuk di dalam grup reseller panel`);
    }
    if (!text) return m.reply(`*Contoh :* ${cmd} username,6283XXX`)

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return m.reply(`*Contoh :* ${cmd} username,6283XXX`)
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await sock.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = global.capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: global.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (orang !== m.chat) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun terkirim ke nomor ${nomor.split("@")[0]}`)
        }

let teks = `
*Behasil membuat panel ✅*

📡 Server ID: ${server.id}
👤 Username: \`${user.username}\`
🔐 Password: \`${password}\`
🗓️ Tanggal Aktivasi: ${global.tanggal(Date.now())}

*Spesifikasi server panel*
- RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
- Disk: ${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}
- CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}
- Panel: ${global.domain}

*Rules pembelian panel*  
- Masa aktif 30 hari  
- Data bersifat pribadi, mohon disimpan dengan aman  
- Garansi berlaku 15 hari (1x replace)  
- Klaim garansi wajib menyertakan *bukti chat pembelian*
`

let msg = await generateWAMessageFromContent(orang, {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                body: { text: teks },
                nativeFlowMessage: {
                    buttons: [
                        { 
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Username","copy_code":"${user.username}"}`
                        },
                        { 
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Password","copy_code":"${password}"}`
                        },
                        { 
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Open Panel","url":"${global.domain}"}`
                        }
                    ]
                }
            }
        }
    }
}, {});

await sock.relayMessage(orang, msg.message, { messageId: msg.key.id });
    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break

//###############################//

case "delpanel": {
    if (!isOwner && !isReseller) {
        return m.reply(mess.owner);
    }
    const rows = []
    rows.push({
title: `Hapus Semua`,
description: `Hapus semua server panel`, 
id: `.delpanel-all`
})            
    try {
        const response = await fetch(`${domain}/api/application/servers`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`,
            },
        });

        const result = await response.json();
        const servers = result.data;

        if (!servers || servers.length === 0) {
            return m.reply("Tidak ada server panel!");
        }

        let messageText = `\n*Total server panel :* ${servers.length}\n`

        for (const server of servers) {
            const s = server.attributes;

            const resStatus = await fetch(`${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${capikey}`,
                },
            });

            const statusData = await resStatus.json();

            const ram = s.limits.memory === 0
                ? "Unlimited"
                : s.limits.memory >= 1024
                ? `${Math.floor(s.limits.memory / 1024)} GB`
                : `${s.limits.memory} MB`;

            const disk = s.limits.disk === 0
                ? "Unlimited"
                : s.limits.disk >= 1024
                ? `${Math.floor(s.limits.disk / 1024)} GB`
                : `${s.limits.disk} MB`;

            const cpu = s.limits.cpu === 0
                ? "Unlimited"
                : `${s.limits.cpu}%`;
            rows.push({
title: `${s.name} || ID:${s.id}`,
description: `Ram ${ram} || Disk ${disk} || CPU ${cpu}`, 
id: `.delpanel-response ${s.id}`
})            
        }                  
        await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Server Panel Yang Ingin Dihapus\n`
}, { quoted: m })

    } catch (err) {
        console.error("Error listing panel servers:", err);
        m.reply("Terjadi kesalahan saat mengambil data server.");
    }
}
break;

//###############################//

case "delpanel-response": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return 
    
    try {
        const serverResponse = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            }
        });
        const serverData = await serverResponse.json();
        const servers = serverData.data;
        
        let serverName;
        let serverSection;
        let serverFound = false;
        
        for (const server of servers) {
            const serverAttr = server.attributes;
            
            if (Number(text) === serverAttr.id) {
                serverSection = serverAttr.name.toLowerCase();
                serverName = serverAttr.name;
                serverFound = true;
                
                const deleteServerResponse = await fetch(domain + `/api/application/servers/${serverAttr.id}`, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                
                if (!deleteServerResponse.ok) {
                    const errorData = await deleteServerResponse.json();
                    console.error("Gagal menghapus server:", errorData);
                }
                
                break;
            }
        }
        
        if (!serverFound) {
            return m.reply("Gagal menghapus server!\nID server tidak ditemukan");
        }
        
        const userResponse = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            }
        });
        const userData = await userResponse.json();
        const users = userData.data;
        
        for (const user of users) {
            const userAttr = user.attributes;
            
            if (userAttr.first_name.toLowerCase() === serverSection) {
                const deleteUserResponse = await fetch(domain + `/api/application/users/${userAttr.id}`, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                
                if (!deleteUserResponse.ok) {
                    const errorData = await deleteUserResponse.json();
                    console.error("Gagal menghapus user:", errorData);
                }
                
                break;
            }
        }
        
        await m.reply(`*Barhasil Menghapus Sever Panel ✅*\n- ID: ${text}\n- Nama Server: ${capital(serverName)}`);
        
    } catch (error) {
        console.error("Error dalam proses delpanel:", error);
        await m.reply("Terjadi kesalahan saat memproses permintaan");
    }
}
break;

//###############################//

case "delpanel-all": {
if (!isOwner) return m.reply(mess.owner)
await m.reply(`Memproses penghapusan semua user & server panel yang bukan admin`)
try {
const PTERO_URL = global.domain
// Ganti dengan URL panel Pterodactyl
const API_KEY = global.apikey// API Key dengan akses admin

// Konfigurasi headers
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

// Fungsi untuk mendapatkan semua user
async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    
    return [];
  }
}

// Fungsi untuk mendapatkan semua server
async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

// Fungsi untuk menghapus server berdasarkan UUID
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}

// Fungsi untuk menghapus user berdasarkan ID
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}

// Fungsi utama untuk menghapus semua user & server yang bukan admin
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0

  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }

    const userID = user.attributes.id;
    const userEmail = user.attributes.email;

    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);

    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);

    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }

    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await m.reply(`Berhasil menghapus *${totalSrv} user & server* panel yang bukan admin ✅`)
}

// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return m.reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

//###############################//

case "listpanel":
case "listserver": {
    if (!isOwner && !isReseller) {
        return m.reply(`Fitur ini hanya untuk di dalam grup reseller panel`);
    }

    try {
        const response = await fetch(`${domain}/api/application/servers`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`,
            },
        });

        const result = await response.json();
        const servers = result.data;

        if (!servers || servers.length === 0) {
            return m.reply("Tidak ada server panel!");
        }

        let messageText = `\n*Total server panel :* ${servers.length}\n`

        for (const server of servers) {
            const s = server.attributes;

            const resStatus = await fetch(`${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${capikey}`,
                },
            });

            const statusData = await resStatus.json();

            const ram = s.limits.memory === 0
                ? "Unlimited"
                : s.limits.memory >= 1024
                ? `${Math.floor(s.limits.memory / 1024)} GB`
                : `${s.limits.memory} MB`;

            const disk = s.limits.disk === 0
                ? "Unlimited"
                : s.limits.disk >= 1024
                ? `${Math.floor(s.limits.disk / 1024)} GB`
                : `${s.limits.disk} MB`;

            const cpu = s.limits.cpu === 0
                ? "Unlimited"
                : `${s.limits.cpu}%`;

            messageText += `
- ID : *${s.id}*
- Nama Server : *${s.name}*
- Ram : *${ram}*
- Disk : *${disk}*
- CPU : *${cpu}*
- Created : *${s.created_at.split("T")[0]}*\n`;
        }                  
        await m.reply(messageText)

    } catch (err) {
        console.error("Error listing panel servers:", err);
        m.reply("Terjadi kesalahan saat mengambil data server.");
    }
}
break;

//###############################//

case "cadmin": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(`Masukan username & nomor (opsional)\n*contoh:* ${cmd} skyzopedia,628XXX`)
    let nomor, usernem;
    const tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek;
        if (!users || !nom) return m.reply(`Masukan username & nomor (opsional)\n*contoh:* ${cmd} skyzopedia,628XXX`)

        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat;
    }

    const onWa = await sock.onWhatsApp(nomor.split("@")[0]);
    if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");

    const username = usernem.toLowerCase();
    const email = `${username}@gmail.com`;
    const name = global.capital(args[0]);
    const password = `${username}001`;

    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: name,
                last_name: "Admin",
                root_admin: true,
                language: "en",
                password
            })
        });

        const data = await res.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        const user = data.attributes;
        const orang = nomor;

        if (nomor !== m.chat) {
            await m.reply(`Berhasil membuat akun admin panel ✅\nData akun terkirim ke nomor ${nomor.split("@")[0]}`);
        }

const teks = `
*Berikut membuat admin panel ✅*

📡 Server ID: ${user.id}
👤 Username: \`${user.username}\`
🔐 Password: \`${password}\`
🗓️ Tanggal Aktivasi: ${global.tanggal(Date.now())}
*🌐* ${global.domain}

*Rules pembelian admin panel*  
- Masa aktif 30 hari  
- Data bersifat pribadi, mohon disimpan dengan aman  
- Garansi berlaku 15 hari (1x replace)  
- Klaim garansi wajib menyertakan *bukti chat pembelian*
`;

let msg = generateWAMessageFromContent(orang, {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                body: { text: teks },
                nativeFlowMessage: {
                    buttons: [
                        { 
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Username","copy_code":"${user.username}"}`
                        },
                        { 
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Password","copy_code":"${password}"}`
                        },
                        { 
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Open Panel","url":"${global.domain}"}`
                        }
                    ]
                }
            }
        }
    }
}, {});

await sock.relayMessage(orang, msg.message, { messageId: msg.key.id });
    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat membuat akun admin panel.");
    }
}
break;

//###############################//

case "deladmin": {
    if (!isOwner) return m.reply(mess.owner);
    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });
        const rows = []
        const data = await res.json();
        const users = data.data;

        const adminUsers = users.filter(u => u.attributes.root_admin === true);
        if (adminUsers.length < 1) return m.reply("Tidak ada admin panel.");

        let teks = `\n*Total admin panel :* ${adminUsers.length}\n`
        adminUsers.forEach((admin, idx) => {
            teks += `
- ID : *${admin.attributes.id}*
- Nama : *${admin.attributes.first_name}*
- Created : ${admin.attributes.created_at.split("T")[0]}
`;
rows.push({
title: `${admin.attributes.first_name} || ID:${admin.attributes.id}`,
description: `Created At: ${admin.attributes.created_at.split("T")[0]}`, 
id: `.deladmin-response ${admin.attributes.id}`
})            
        });

        await sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Admin Panel Yang Ingin Dihapus\n`
}, { quoted: m })

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat mengambil data admin.");
    }
}
break;

//###############################//

case "deladmin-response": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return 
    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        const data = await res.json();
        const users = data.data;

        let targetAdmin = users.find(
            (e) => e.attributes.id == args[0] && e.attributes.root_admin === true
        );

        if (!targetAdmin) {
            return m.reply("Gagal menghapus akun!\nID user tidak ditemukan");
        }

        const idadmin = targetAdmin.attributes.id;
        const username = targetAdmin.attributes.username;

        const delRes = await fetch(`${domain}/api/application/users/${idadmin}`, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        if (!delRes.ok) {
            const errData = await delRes.json();
            return m.reply(`Gagal menghapus akun admin!\n${JSON.stringify(errData.errors[0], null, 2)}`);
        }

        await m.reply(`*Berhasil Menghapus Admin Panel ✅*\n- ID: ${text}\n- Nama User: ${global.capital(username)}`);

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat menghapus akun admin.");
    }
}
break;

//###############################//

case "listadmin": {
    if (!isOwner) return m.reply(mess.owner);

    try {
        const res = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            }
        });

        const data = await res.json();
        const users = data.data;

        const adminUsers = users.filter(u => u.attributes.root_admin === true);
        if (adminUsers.length < 1) return m.reply("Tidak ada admin panel.");

        let teks = `\n*Total admin panel :* ${adminUsers.length}\n`
        adminUsers.forEach((admin, idx) => {
            teks += `
- ID : *${admin.attributes.id}*
- Nama : *${admin.attributes.first_name}*
- Created : ${admin.attributes.created_at.split("T")[0]}
`;
        });

        await m.reply(teks)

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat mengambil data admin.");
    }
}
break;

//###############################//

case "addseller": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text && !m.quoted) return m.reply(`*contoh:* ${cmd} 6283XXX`);

    const input = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    const input2 = input.split("@")[0];

    if (input2 === global.owner || global.db.settings.reseller.includes(input) || input === botNumber)
        return m.reply(`Nomor ${input2} sudah menjadi reseller!`);

    global.db.settings.reseller.push(input);
    m.reply(`Berhasil menambah reseller ✅`);
}
break;

//###############################//

case "listseller": {
    const list = global.db.settings.reseller;
    if (!list || list.length < 1) return m.reply("Tidak ada user reseller");

    let teks = `Daftar reseller:\n`;
    for (let i of list) {
        const num = i.split("@")[0];
        teks += `\n• ${num}\n  Tag: @${num}\n`;
    }

    sock.sendMessage(m.chat, { text: teks, mentions: list }, { quoted: m });
}
break;

//###############################//

case "delseller": {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.quoted && !text) return m.reply(`*Contoh :* ${cmd} 6283XXX`);

    const input = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber)
        return m.reply(`Tidak bisa menghapus owner!`);

    const list = global.db.settings.reseller;
    if (!list.includes(input))
        return m.reply(`Nomor ${input2} bukan reseller!`);

    list.splice(list.indexOf(input), 1);
    m.reply(`Berhasil menghapus reseller ✅`);
}
break;

//###############################//

case "own": case "owner": {
await sock.sendContact(m.chat, [global.owner], global.namaOwner, "Developer Bot", m)
}
break

//###############################//

case "addowner": case "addown": {
    if (!isOwner) return m.reply(mess.owner);

    const input = m.quoted 
        ? m.quoted.sender 
        : m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" 
                : null;

    if (!input) return m.reply(`*Contoh penggunaan :*\n${cmd} 6285XXX`);

    const jid = input.split("@")[0];
    const botNumber = sock.user.id.split(":")[0] + "@s.whatsapp.net";

    if (jid == global.owner || input == botNumber) 
        return m.reply(`Nomor ${jid} sudah menjadi ownerbot.`);

    if (global.db.settings.developer.includes(input)) 
        return m.reply(`Nomor ${jid} sudah menjadi ownerbot.`);

    global.db.settings.developer.push(input);
    return m.reply(`Berhasil menambah owner ✅\n- ${jid}`);
}
break;

//###############################//

case "delowner": case "delown": {
    if (!isOwner) return m.reply(mess.owner);

    const input = m.quoted 
        ? m.quoted.sender 
        : m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" 
                : null;

    if (!input) return m.reply(`*Contoh penggunaan :*\n${cmd} 6285XXX`);

    if (input.toLowerCase() === "all") {
        global.db.settings.developer = [];
        return m.reply("Berhasil menghapus semua owner ✅");
    }

    if (!global.db.settings.developer.includes(input)) 
        return m.reply("Nomor tidak ditemukan!");

    global.db.settings.developer = global.db.settings.developer.filter(i => i !== input);
    return m.reply(`Berhasil menghapus owner ✅\n- ${input.split("@")[0]}`);
}
break;

//###############################//

case "listowner": case "listown": {
    const Own = global.db.settings.developer;
    if (!Own || Own.length < 1) return m.reply("Tidak ada owner tambahan.");

    let teks = "Daftar owner tambahan:\n";
    for (let i of Own) {
        const num = i.split("@")[0];
        teks += `\n- Number: ${num}\n- Tag: @${num}\n`;
    }
    return sock.sendMessage(m.chat, { text: teks, mentions: Own }, { quoted: m });
}
break;

//###############################//

case "resetdb": case "rstdb": {
if (!isOwner) return m.reply(mess.owner)
global.db = {}
return m.reply("Berhasil mereset database ✅")
}
break

//###############################//

default:
if (m.text.toLowerCase().startsWith("xx")) {
    if (m.sender.split("@")[0] !== global.owner) return 

    try {
        const result = await eval(`(async () => { ${text} })()`);
        const output = typeof result !== "string" ? util.inspect(result) : result;
        return sock.sendMessage(m.chat, { text: util.format(output) }, { quoted: m });
    } catch (err) {
        return sock.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
    }
}

//###############################//

if (m.text.toLowerCase().startsWith("x")) {
    if (m.sender.split("@")[0] !== global.owner) return 

    try {
        let result = await eval(text);
        if (typeof result !== "string") result = util.inspect(result);
        return sock.sendMessage(m.chat, { text: util.format(result) }, { quoted: m });
    } catch (err) {
        return sock.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
    }
}

//###############################//

if (m.text.startsWith('$')) {
    if (!isOwner) return;
    
    exec(m.text.slice(2), (err, stdout) => {
        if (err) {
            return sock.sendMessage(m.chat, { text: err.toString() }, { quoted: m });
        }
        if (stdout) {
            return sock.sendMessage(m.chat, { text: util.format(stdout) }, { quoted: m });
        }
    });
}

}

} catch (err) {
console.log(err)
await sock.sendMessage(global.owner+"@s.whatsapp.net", {text: err.toString()}, {quoted: m ? m : null })
}}

//###############################//

process.on("uncaughtException", (err) => {
console.error("Caught exception:", err);
});

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.blue(">> Update File:"), chalk.black.bgWhite(__filename));
    delete require.cache[file];
    require(file);
});