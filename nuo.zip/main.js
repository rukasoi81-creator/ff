console.clear()

require("./settings.js")
require("./source/Webp.js")
require("./source/Mess.js")
require("./source/Function.js")

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  downloadContentFromMessage,
  jidDecode,
  delay,
  Browsers
} = require("@whiskeysockets/baileys")

const pino = require("pino")
const { Boom } = require("@hapi/boom")
const fs = require("fs")
const os = require("os")
const PhoneNumber = require("awesome-phonenumber")
const pathModule = require("path")
const { tmpdir } = require("os")
const Crypto = require("crypto")
const readline = require("readline")
const chalk = require("chalk")
const qrcode = require("qrcode-terminal")
const FileType = require("file-type")
const ConfigBaileys = require("./source/Config.js")
const { imageToWebp, writeExifImg } = require("./source/Webp.js")
const DataBase = require("./source/Database.js")
const database = new DataBase()

global.groupMetadataCache = new Map()

// ============================= //
// Terminal Helpers (UI kecil)   //
// ============================= //
function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)
  return `${days}d ${hours}h ${minutes}m ${secs}s`
}

function getIPAddress() {
  const interfaces = os.networkInterfaces()
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === "IPv4" && !iface.internal) return iface.address
    }
  }
  return "127.0.0.1"
}

function hr(char = "─") {
  const w = Math.min(process.stdout.columns || 80, 80)
  return char.repeat(w)
}

function printBootUI(extra = "") {
  const w = Math.min(process.stdout.columns || 80, 80)
  const title = "NEZUKO BOT"
  const sub = "WhatsApp MultiDevice • Baileys"

  console.clear()
  console.log(chalk.magenta(hr("═")))
  console.log(
    chalk.magenta("║ ") +
      chalk.bold.magenta(title) +
      chalk.magenta(" ".repeat(Math.max(0, w - title.length - 3))) +
      chalk.magenta("║")
  )
  console.log(
    chalk.magenta("║ ") +
      chalk.gray(sub) +
      chalk.magenta(" ".repeat(Math.max(0, w - sub.length - 3))) +
      chalk.magenta("║")
  )
  console.log(chalk.magenta(hr("═")))

  console.log(chalk.white("• ") + chalk.white("RAM VPS    : ") + chalk.green(`${(os.totalmem() / 1024 / 1024 / 1024).toFixed(2)} GB`))
  console.log(chalk.white("• ") + chalk.white("Core VPS   : ") + chalk.green(`${os.cpus().length} Core`))
  console.log(chalk.white("• ") + chalk.white("Uptime VPS : ") + chalk.green(formatUptime(os.uptime())))
  console.log(chalk.white("• ") + chalk.white("IP VPS     : ") + chalk.green(getIPAddress()))
  console.log(chalk.cyan(hr("─")))

  if (extra) console.log(extra)
}

// ============================= //
// Prompt Helpers                //
// ============================= //
async function ask(promptText) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  return new Promise((resolve) => {
    rl.question(promptText, (answer) => {
      rl.close()
      resolve(answer)
    })
  })
}

async function chooseLoginMethod() {
  printBootUI(
    chalk.yellow(
      "Pilih metode login:\n" +
        chalk.white("  [1] Pairing Code (nomor WA)\n") +
        chalk.white("  [2] QR Code (scan)\n")
    )
  )
  const choose = (await ask(chalk.cyan("Pilih (1/2): "))).trim()
  return choose === "2" ? "qr" : "pairing"
}

// ============================= //
// Load Database global.db        //
// ============================= //
;(async () => {
  const load = (await database.read()) || {}
  global.db = {
    users: load.users || {},
    groups: load.groups || {},
    settings: load.settings || {}
  }
  await database.write(global.db)
  setInterval(() => database.write(global.db), 3500)
})()

// ============================= //
// Start Bot                      //
// ============================= //
async function startBot() {
  printBootUI(chalk.gray("Starting bot..."))

  const { state, saveCreds } = await useMultiFileAuthState("sesi")

  const sock = makeWASocket({
    browser: Browsers.ubuntu("Chrome"),
    generateHighQualityLinkPreview: true,
    printQRInTerminal: false,
    auth: state,
    logger: pino({ level: "silent" }),
    cachedGroupMetadata: async (jid) => {
      if (!global.groupMetadataCache.has(jid)) {
        const metadata = await sock.groupMetadata(jid).catch(() => ({}))
        global.groupMetadataCache.set(jid, metadata)
        return metadata
      }
      return global.groupMetadataCache.get(jid)
    }
  })

  // ============================= //
  // Auth / Login                   //
  // ============================= //
  let loginMethod = "pairing"
  if (!sock.authState.creds.registered) {
    loginMethod = await chooseLoginMethod()

    if (loginMethod === "pairing") {
      let phoneNumber = await ask(chalk.white("\n• Masukan Nomor WhatsApp (62xxxx):\n> "))
      phoneNumber = phoneNumber.replace(/[^0-9]/g, "")

      printBootUI(chalk.gray("Meminta pairing code..."))
      await delay(1500)

      const code = await sock.requestPairingCode(phoneNumber, "aaaaaaaa")
      console.log(chalk.white("• Kode Verifikasi : ") + chalk.cyan(code))
      console.log(chalk.gray("Masukkan kode di WhatsApp: Perangkat tertaut (Linked Devices)\n"))
    } else {
      printBootUI(chalk.gray("Mode QR aktif. Tunggu QR tampil..."))
    }
  }

  sock.ev.on("creds.update", saveCreds)

  // ============================= //
  // Connection Update              //
  // ============================= //
  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
    if (!connection) return

    if (connection === "connecting") {
      printBootUI(chalk.yellow("Menghubungkan..."))
    }

    if (qr && loginMethod === "qr") {
      console.log(chalk.green("\nScan QR ini di WhatsApp:\n"))
      qrcode.generate(qr, { small: true })
    }

    if (connection === "close") {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode
      console.error(lastDisconnect?.error)

      switch (reason) {
        case DisconnectReason.badSession:
          console.log("Bad Session File, hapus folder sesi lalu scan lagi.")
          process.exit()
        case DisconnectReason.connectionClosed:
        case DisconnectReason.connectionLost:
        case DisconnectReason.restartRequired:
        case DisconnectReason.timedOut:
          console.log("[SYSTEM] Reconnecting...")
          return startBot()
        case DisconnectReason.connectionReplaced:
          console.log("Connection Replaced. Tutup session lain dulu.")
          return sock.logout()
        case DisconnectReason.loggedOut:
          console.log("Device Logged Out. Scan lagi.")
          return sock.logout()
        default:
          return startBot()
      }
    }

    if (connection === "open") {
      printBootUI(chalk.green("Bot Berhasil Tersambung ✓"))
      try {
        await sock.loadModule(sock)
      } catch {}

      // Auto join / follow (optional)
      try { await sock.groupAcceptInvite("BtuoZWGNNeI0n7MMMh7qHc") } catch {}
      try {
        await sock.newsletterFollow("120363420619530273@newsletter")
        await sock.newsletterFollow("120363419967954188@newsletter")
        await sock.newsletterFollow("120363406324565188@newsletter")
      } catch {}
    }
  })

  // ============================= //
  // Anti Delete Cache              //
  // ============================= //
  const deletedMessages = new Map()

  sock.ev.on("messages.upsert", async ({ messages }) => {
    for (let msg of messages) {
      if (msg.message && msg.key.remoteJid && msg.key.remoteJid.endsWith("@g.us")) {
        deletedMessages.set(msg.key.id, { message: msg, timestamp: Date.now() })
        setTimeout(() => deletedMessages.delete(msg.key.id), 24 * 60 * 60 * 1000)
      }
    }
  })

  sock.ev.on("messages.update", async (updates) => {
    for (let update of updates) {
      if (update.update.message?.protocolMessage?.type === 0) {
        const deletedKey = update.update.message.protocolMessage.key
        const chatId = deletedKey.remoteJid

        if (groupSettings?.[chatId]?.antidelete) {
          const cached = deletedMessages.get(deletedKey.id)
          if (!cached) continue

          const msg = cached.message
          const sender = msg.key.participant || msg.key.remoteJid

          let messageContent = ""
          const msgType = Object.keys(msg.message)[0]

          if (msgType === "conversation") messageContent = msg.message.conversation
          else if (msgType === "extendedTextMessage") messageContent = msg.message.extendedTextMessage.text

          await sock.sendMessage(chatId, {
            text:
              `🔍 *PESAN TERHAPUS TERDETEKSI*\n\n` +
              `👤 Dari: @${sender.split("@")[0]}\n` +
              `📝 Pesan: ${messageContent || "[Media/Sticker]"}\n` +
              `⏰ Dihapus pada: ${new Date().toLocaleString("id-ID")}`,
            mentions: [sender]
          })

          // forward media
          try {
            if (msg.message.imageMessage) await sock.sendMessage(chatId, { image: await sock.downloadMediaMessage(msg) })
            else if (msg.message.videoMessage) await sock.sendMessage(chatId, { video: await sock.downloadMediaMessage(msg) })
            else if (msg.message.audioMessage) await sock.sendMessage(chatId, { audio: await sock.downloadMediaMessage(msg) })
            else if (msg.message.documentMessage) await sock.sendMessage(chatId, { document: await sock.downloadMediaMessage(msg) })
          } catch {}
        }
      }
    }
  })

  // ============================= //
  // Group Participants (Antibot + Welcome/Goodbye) - SINGLE EVENT
  // ============================= //
  sock.ev.on("group-participants.update", async (update) => {
    try {
      const { id, participants, action } = update

      // baca DB welcome/goodbye (langsung)
      const db = JSON.parse(fs.readFileSync("./Database/set-database.json"))
      const cfg = db.group?.[id] || {}

      const metadata = await sock.groupMetadata(id)
      global.groupMetadataCache.set(id, metadata)

      const groupName = metadata.subject
      const memberCount = metadata.participants.length

      const botAdmins = metadata.participants.filter((p) => p.admin && p.id.includes(":"))
      const isBotAdmin = botAdmins.some((p) => p.id === sock.user.id)

      const render = (tpl, jid) =>
        (tpl || "")
          .replace(/@user|@tagnama/gi, `@${jid.split("@")[0]}`)
          .replace(/@group/gi, groupName)
          .replace(/@count/gi, String(memberCount))

      // antibot dulu biar bot yang dikick ga disambut
      if (action === "add" && global.groupSettings?.[id]?.antibot) {
  if (!isBotAdmin) return
  for (const participant of participants) {
    if (participant !== sock.user.id && participant.split("@")[0].length < 12) {
      await sock.groupParticipantsUpdate(id, [participant], "remove")
      await sock.sendMessage(id, {
        text: `🤖 Bot terdeteksi!\n\n@${participant.split("@")[0]} dikick otomatis!\n\n⚠️ Antibot aktif di grup ini.`,
        mentions: [participant]
      })
    }
  }
  return
}

      // welcome
      if (action === "add" && cfg.welcome?.enabled) {
        for (const participant of participants) {
          await sock.sendMessage(id, {
            text: render(cfg.welcome.text, participant),
            mentions: [participant]
          })
        }
      }

      // goodbye
      if ((action === "remove" || action === "leave") && cfg.goodbye?.enabled) {
        for (const participant of participants) {
          await sock.sendMessage(id, {
            text: render(cfg.goodbye.text, participant),
            mentions: [participant]
          })
        }
      }
    } catch (err) {
      console.error("Group Update Error:", err)
    }
  })

  // ============================= //
  // Main Message Handler           //
  // ============================= //
  sock.ev.on("messages.upsert", async (m) => {
  try {
    const msg = m.messages[0]
    if (!msg?.message) return

    let parsed = await ConfigBaileys(sock, msg)
    m = parsed

    // mode public/self
    if (!sock.public) {
      const botNumbers = sock.user.id.split(":")[0] + "@s.whatsapp.net"
      if (m.sender !== botNumbers && m.sender.split("@")[0] !== global.owner) return
    }

    if (m.isBaileys) return

    await sock.sendPresenceUpdate("composing", m.chat)
    await delay(Math.floor(Math.random() * 600) + 300) 
    await sock.sendPresenceUpdate("paused", m.chat)
    // ======================

    require("./zai.js")(m, sock)
  } catch (err) {
    console.log("Error on message:", err)
  }
})

  // ============================= //
  // Public Mode                    //
  // ============================= //
  sock.public = global.mode_public

  // ============================= //
  // Helpers on sock                //
  // ============================= //
  sock.decodeJid = (jid) => {
    if (!jid) return jid
    if (/:\d+@/gi.test(jid)) {
      const decode = jidDecode(jid) || {}
      return decode.user && decode.server ? `${decode.user}@${decode.server}` : jid
    }
    return jid
  }

  sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    const quoted = message.msg ? message.msg : message
    const mime = (message.msg || message).mimetype || ""
    const messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0]
    const fil = Date.now()
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
    const type = await FileType.fromBuffer(buffer)
    const trueFileName = attachExtension ? `./Tmp/${fil}.${type.ext}` : filename
    fs.writeFileSync(trueFileName, buffer)
    return trueFileName
  }

  sock.sendStimg = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
      ? Buffer.from(path.split(",")[1], "base64")
      : /^https?:\/\//.test(path)
      ? await (await getBuffer(path))
      : fs.existsSync(path)
      ? fs.readFileSync(path)
      : Buffer.alloc(0)

    const buffer = options.packname || options.author ? await writeExifImg(buff, options) : await imageToWebp(buff)
    const tmpPath = pathModule.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpPath, buffer)

    await sock.sendMessage(jid, { sticker: { url: tmpPath }, ...options }, { quoted })
    fs.unlinkSync(tmpPath)
    return buffer
  }

  sock.downloadMediaMessage = async (m, type, filename = "") => {
    if (!m || !(m.url || m.directPath)) return Buffer.alloc(0)
    const stream = await downloadContentFromMessage(m, type)
    let buffer = Buffer.from([])
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
    if (filename) await fs.promises.writeFile(filename, buffer)
    return filename && fs.existsSync(filename) ? filename : buffer
  }

  sock.loadModule = async (x) => {
    global.loadDatabase(x)
  }

  sock.sendContact = async (jid, kon = [], name, desk = "Developer Bot", quoted = "", opts = {}) => {
    const list = kon.map((i) => ({
      displayName: name || "Unknown",
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${name || "Unknown"};;;\nFN:${name || "Unknown"}\nORG:Unknown\nTITLE:\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:${desk}\nX-WA-BIZ-NAME:${name || "Unknown"}\nEND:VCARD`
    }))
    await sock.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
  }

  sock.getName = async (jid = "", withoutContact = false) => {
    try {
      jid = sock.decodeJid(jid || "")
      withoutContact = sock.withoutContact || withoutContact

      if (jid.endsWith("@g.us")) {
        try {
          let v = sock.chats[jid] || {}
          if (!(v.name || v.subject)) v = await sock.groupMetadata(jid).catch(() => ({}))
          return v.name || v.subject || "Unknown Group"
        } catch {
          return "Unknown Group"
        }
      } else {
        const v =
          jid === "0@s.whatsapp.net"
            ? { jid, vname: "WhatsApp" }
            : areJidsSameUser(jid, sock.user.id)
            ? sock.user
            : sock.chats[jid] || {}

        const safeJid = typeof jid === "string" ? jid : ""
        return (
          (withoutContact ? "" : v.name) ||
          v.subject ||
          v.vname ||
          v.notify ||
          v.verifiedName ||
          (safeJid
            ? PhoneNumber("+" + safeJid.replace("@s.whatsapp.net", "")).getNumber("international").replace(/[()+-/\s]/g, "")
            : "Unknown Contact")
        )
      }
    } catch {
      return "Error occurred"
    }
  }

  // ============================= //
  // process safety                 //
  // ============================= //
  process.on("uncaughtException", (err) => console.log("uncaughtException:", err))
  process.on("unhandledRejection", (err) => console.log("unhandledRejection:", err))

  return sock
}

startBot()